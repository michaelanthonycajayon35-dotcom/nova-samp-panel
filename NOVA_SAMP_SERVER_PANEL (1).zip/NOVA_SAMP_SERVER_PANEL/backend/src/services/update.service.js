'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Impormasyon tungkol sa bersyon ng panel (manual ang update: git pull / bagong release).
const os = require('os');
const { VERSION } = require('../config/environment');

function info() {
  return {
    name: 'NOVA SAMP Server Panel',
    author: 'CAJAYON',
    version: VERSION,
    node: process.version,
    platform: `${os.type()} ${os.arch()}`,
    pid: process.pid,
    uptimeSec: Math.floor(process.uptime()),
  };
}

module.exports = { info };
