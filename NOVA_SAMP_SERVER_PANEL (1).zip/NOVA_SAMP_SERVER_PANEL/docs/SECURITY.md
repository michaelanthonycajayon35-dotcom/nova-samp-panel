# Security

Ang panel na ito ay may kakayahang magpatakbo ng programa, mag-edit ng file at magpadala ng RCON — **seryosohin ang seguridad**.

## Ginagawa na ng panel
- Password: scrypt hash. Login: rate limit + lockout (8 maling subok = 10 minutong lock)
- Token: JWT (HS256), may expiry; nabubura ang lahat ng session kapag pinalitan ang password / role
- Random na unang password at kailangang palitan pag-login
- File Manager: nakakulong sa folder ng server (bawal `..`, absolute path, at symlink escape)
- Import: proteksyon laban sa zip-slip, symlink, at "zip bomb" limit
- Download: maikling-buhay (60s) na signed link
- Roles: viewer / moderator / admin; Files at Users ay admin lang
- Hindi lumalabas ang RCON password sa API

## Gawin mo
1. **Gumamit ng HTTPS** (nginx + certbot, o Cloudflare). Kung HTTP lang, makikita ng nasa network ang password mo.
2. Huwag i-expose ang port ng panel kung hindi kailangan; i-limit sa IP mo gamit ang firewall kung kaya.
3. Malakas na password, at huwag ibigay ang `admin` role kung hindi kailangan.
4. Huwag patakbuhin ang panel bilang `root` (ang `install.sh` ay gumagamit ng user mo).
5. Palitan ang default na RCON password; huwag gumamit ng `changeme`.
6. I-backup ang `storage/` at **huwag i-commit** ang `.env` o `storage/` sa GitHub.

## Alam na limitasyon
- Ang mga server na ipinapatakbo ng panel ay tumatakbo gamit ang parehong user ng panel. Huwag mag-import ng server mula sa hindi mo pinagkakatiwalaan (executable ang laman nito).
- Ang in-memory rate limit ay nare-reset kapag nag-restart ang panel.
