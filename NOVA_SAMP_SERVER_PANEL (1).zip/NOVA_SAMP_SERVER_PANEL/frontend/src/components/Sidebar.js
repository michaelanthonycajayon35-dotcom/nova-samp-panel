// NOVA SAMP SERVER PANEL - by CAJAYON | Sidebar: bottom nav sa phone, sidebar sa desktop
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { hasRole } from '../scripts/auth.js';
import { navigate } from '../scripts/navigation.js';
import { openMenu } from './Modal.js';

const ITEMS = [
  { path: '/', label: 'Dashboard', icon: 'dashboard', match: (p) => p === '/' },
  { path: '/servers', label: 'Servers', icon: 'server', match: (p) => p.startsWith('/servers') },
  { path: '/console', label: 'Console', icon: 'terminal', match: (p) => p === '/console' },
  { path: '/players', label: 'Players', icon: 'users', match: (p) => p === '/players' },
  { path: '/rcon', label: 'RCON', icon: 'shield', secondary: true, role: 'moderator', match: (p) => p === '/rcon' },
  { path: '/files', label: 'Files', icon: 'folder', secondary: true, role: 'admin', match: (p) => p === '/files' },
  { path: '/backups', label: 'Backups', icon: 'backup', secondary: true, role: 'moderator', match: (p) => p === '/backups' },
  { path: '/users', label: 'Users', icon: 'user', secondary: true, role: 'admin', match: (p) => p === '/users' },
  { path: '/settings', label: 'Settings', icon: 'settings', secondary: true, match: (p) => p === '/settings' },
];

export function Sidebar({ panelName, onLogout }) {
  const visible = ITEMS.filter((i) => !i.role || hasRole(i.role));
  const buttons = new Map();
  const nav = h('nav', { class: 'nav', 'aria-label': 'Pangunahing menu' },
    h('div', { class: 'nav-brand' }, h('img', { src: 'public/assets/logo-icon.png', alt: '' }), h('span', null, panelName)));
  for (const it of visible) {
    const b = h('button', { class: `nav-item${it.secondary ? ' secondary' : ''}`, onclick: () => navigate(it.path) }, icon(it.icon), h('span', null, it.label));
    buttons.set(it, b);
    nav.append(b);
  }
  const secondary = visible.filter((i) => i.secondary);
  const more = h('button', { class: 'nav-item nav-more', onclick: () => openMenu('Menu', [
    ...secondary.map((i) => ({ label: i.label, icon: i.icon, onClick: () => navigate(i.path) })),
    { label: 'Mag-logout', icon: 'logout', danger: true, onClick: onLogout },
  ]) }, icon('menu'), h('span', null, 'More'));
  nav.append(more, h('div', { class: 'nav-sep' }),
    h('button', { class: 'nav-item nav-logout', onclick: onLogout }, icon('logout'), h('span', null, 'Mag-logout')));

  nav.update = (path) => {
    for (const [it, b] of buttons) b.classList.toggle('active', it.match(path));
    more.classList.toggle('active', secondary.some((i) => i.match(path)));
  };
  return nav;
}
