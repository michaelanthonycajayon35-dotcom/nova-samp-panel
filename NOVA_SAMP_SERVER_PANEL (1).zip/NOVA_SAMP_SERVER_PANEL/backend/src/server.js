'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const env = require('./config/environment');
const logger = require('./utils/logger');
const { createApp } = require('./app');
const registerRoutes = require('./routes');
const users = require('./controllers/users.controller');
const monitoring = require('./services/monitoring.service');
const backups = require('./services/backup.service');
const processService = require('./services/process.service');

function buildServer() {
  users.seedAdmin();
  return createApp(registerRoutes);
}

function main() {
  const server = buildServer();
  monitoring.start();
  backups.startScheduler();
  server.listen(env.PORT, env.HOST, () => {
    logger.info(`NOVA SAMP Server Panel v${env.VERSION} tumatakbo sa http://${env.HOST === '0.0.0.0' ? 'localhost' : env.HOST}:${env.PORT}`);
  });
  server.on('error', (e) => {
    logger.error(e.code === 'EADDRINUSE' ? `Gamit na ang port ${env.PORT}. Palitan ang PORT sa .env` : e);
    process.exit(1);
  });

  let closing = false;
  const shutdown = async (sig) => {
    if (closing) return;
    closing = true;
    logger.info(`${sig}: pinapatay ang mga server at isinasara ang panel...`);
    server.close();
    await processService.stopAll();
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('unhandledRejection', (e) => logger.error('unhandledRejection', e));
  process.on('uncaughtException', (e) => logger.error('uncaughtException', e));
}

if (require.main === module) main();

module.exports = { buildServer };
