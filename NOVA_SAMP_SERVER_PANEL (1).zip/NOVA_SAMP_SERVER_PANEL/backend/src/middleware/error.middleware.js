'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const logger = require('../utils/logger');

function handleError(err, ctx) {
  const status = err && err.status ? err.status : 500;
  if (status >= 500) logger.error(`${ctx.req.method} ${ctx.req.url}`, err);
  if (ctx.res.headersSent) { try { ctx.res.end(); } catch { /* ignore */ } return; }
  const message = status >= 500 && !(err && err.status) ? 'May error sa server.' : err.message;
  ctx.send(status, { error: message, ...(err && err.extra ? err.extra : {}) });
}

module.exports = { handleError };
