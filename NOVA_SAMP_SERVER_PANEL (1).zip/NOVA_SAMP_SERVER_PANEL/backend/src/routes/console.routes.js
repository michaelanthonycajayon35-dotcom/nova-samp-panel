'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const c = require('../controllers/console.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');

module.exports = (router) => {
  router.get('/api/servers/:id/console', authenticate, requireRole('viewer'), c.read);
  router.get('/api/servers/:id/console/log', authenticate, requireRole('viewer'), c.log);
  router.post('/api/servers/:id/console/command', authenticate, requireRole('moderator'), c.command);
  router.post('/api/servers/:id/console/clear', authenticate, requireRole('moderator'), c.clear);
};
