'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { boot, mockSamp } = require('./support');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

test('servers, query, rcon, players, process', async (t) => {
  const app = await boot();
  const mock = await mockSamp('secret');
  t.after(async () => { await mock.close(); await app.close(); });
  const { api } = app;
  const token = await app.login();
  let server;

  await t.test('gumawa ng server mula sa template', async () => {
    const r = await api('POST', '/api/servers', { token, body: { name: 'Test RP', port: mock.port, host: '127.0.0.1', rconPassword: 'secret' } });
    assert.equal(r.status, 200);
    server = r.json.server;
    assert.equal(server.hasRcon, true);
    assert.ok(!('rconPassword' in server), 'hindi dapat lumabas ang rcon password');
    const cfg = fs.readFileSync(path.join(server.path, 'server.cfg'), 'utf8');
    assert.match(cfg, new RegExp(`port ${mock.port}`));
    assert.match(cfg, /rcon_password secret/);
    assert.match(cfg, /hostname Test RP/);
  });

  await t.test('validation at duplicate', async () => {
    assert.equal((await api('POST', '/api/servers', { token, body: { name: 'ab' } })).status, 400);
    assert.equal((await api('POST', '/api/servers', { token, body: { name: 'Valid Name', port: 99999 } })).status, 400);
    assert.equal((await api('POST', '/api/servers', { token, body: { name: 'Dup', port: mock.port, host: '127.0.0.1' } })).status, 409);
  });

  await t.test('open.mp template ay valid JSON', async () => {
    const r = await api('POST', '/api/servers', { token, body: { name: 'OMP "Quoted"', type: 'openmp', port: 7790 } });
    assert.equal(r.status, 200);
    const cfg = JSON.parse(fs.readFileSync(path.join(r.json.server.path, 'config.json'), 'utf8'));
    assert.equal(cfg.network.port, 7790);
    assert.equal(cfg.name, 'OMP "Quoted"');
    await api('DELETE', `/api/servers/${r.json.server.id}?deleteFiles=true`, { token });
  });

  await t.test('query info', async () => {
    const r = await api('GET', `/api/servers/${server.id}`, { token });
    assert.equal(r.json.query.online, true);
    assert.equal(r.json.query.hostname, 'Mock Server');
    assert.equal(r.json.query.players, 2);
    assert.equal(r.json.query.maxPlayers, 50);
    assert.equal(r.json.executableFound, false);
  });

  await t.test('dashboard', async () => {
    const r = await api('GET', '/api/dashboard', { token });
    assert.equal(r.status, 200);
    assert.equal(r.json.totals.servers, 1);
    assert.equal(r.json.totals.online, 1);
    assert.equal(r.json.totals.players, 2);
    assert.ok(r.json.system.memory.total > 0);
  });

  await t.test('players', async () => {
    const r = await api('GET', `/api/servers/${server.id}/players`, { token });
    assert.deepEqual(r.json.players.map((p) => p.name), ['Juan', 'Maria']);
    assert.equal(r.json.players[1].id, 3);
    assert.equal(r.json.players[1].ping, 80);
  });

  await t.test('rcon', async () => {
    let r = await api('POST', `/api/servers/${server.id}/rcon`, { token, body: { command: 'cmdlist' } });
    assert.deepEqual(r.json.lines, ['Console Commands:', '  kick, ban, say']);
    r = await api('POST', `/api/servers/${server.id}/rcon`, { token, body: { command: 'echo hi\nexit' } });
    assert.equal(r.status, 400, 'bawal ang bagong linya');
    r = await api('POST', `/api/servers/${server.id}/players/3/kick`, { token });
    assert.equal(r.status, 200);
    assert.ok(mock.received.includes('kick 3'));
    r = await api('POST', `/api/servers/${server.id}/players/abc/kick`, { token });
    assert.equal(r.status, 400);
    r = await api('POST', `/api/servers/${server.id}/say`, { token, body: { message: 'Hello' } });
    assert.ok(mock.received.includes('say Hello'));
  });

  await t.test('maling rcon password', async () => {
    await api('PATCH', `/api/servers/${server.id}`, { token, body: { rconPassword: 'mali' } });
    const r = await api('POST', `/api/servers/${server.id}/rcon`, { token, body: { command: 'cmdlist' } });
    assert.deepEqual(r.json.lines, ['Invalid RCON password.']);
    await api('PATCH', `/api/servers/${server.id}`, { token, body: { rconPassword: 'secret' } });
  });

  await t.test('start na walang executable ay may malinaw na error', async () => {
    const r = await api('POST', `/api/servers/${server.id}/start`, { token });
    assert.equal(r.status, 400);
    assert.match(r.json.error, /samp03svr/);
  });

  await t.test('start / console / stop gamit ang pekeng executable', async () => {
    if (process.platform === 'win32') return;
    const exe = path.join(server.path, 'samp03svr');
    fs.writeFileSync(exe, '#!/bin/sh\necho "Server started"\nwhile read line; do echo "got: $line"; done\n');
    fs.chmodSync(exe, 0o755);
    let r = await api('POST', `/api/servers/${server.id}/start`, { token });
    assert.equal(r.status, 200);
    assert.equal(r.json.server.process.running, true);
    assert.equal((await api('POST', `/api/servers/${server.id}/start`, { token })).status, 409);
    await api('POST', `/api/servers/${server.id}/console/command`, { token, body: { command: 'hello' } });
    await sleep(300);
    r = await api('GET', `/api/servers/${server.id}/console`, { token });
    const texts = r.json.lines.map((l) => l.text);
    assert.ok(texts.includes('Server started'), texts.join('|'));
    assert.ok(texts.includes('got: hello'));
    const since = await api('GET', `/api/servers/${server.id}/console?since=${r.json.last}`, { token });
    assert.equal(since.json.lines.length, 0);
    r = await api('POST', `/api/servers/${server.id}/stop`, { token });
    assert.equal(r.json.server.process.running, false);
  });

  await t.test('config editor sini-sync ang port', async () => {
    const got = await api('GET', `/api/servers/${server.id}/config`, { token });
    assert.equal(got.json.file, 'server.cfg');
    const next = got.json.content.replace(/^port .*/m, 'port 7801');
    const r = await api('PUT', `/api/servers/${server.id}/config`, { token, body: { content: next } });
    assert.equal(r.status, 200);
    const d = await api('GET', '/api/servers', { token });
    assert.equal(d.json.servers[0].port, 7801);
    assert.ok(fs.existsSync(path.join(server.path, 'server.cfg.bak')));
  });

  await t.test('delete server kasama ang files', async () => {
    const r = await api('DELETE', `/api/servers/${server.id}?deleteFiles=true`, { token });
    assert.equal(r.status, 200);
    assert.equal(fs.existsSync(server.path), false);
    assert.equal((await api('GET', `/api/servers/${server.id}`, { token })).status, 404);
  });
});
