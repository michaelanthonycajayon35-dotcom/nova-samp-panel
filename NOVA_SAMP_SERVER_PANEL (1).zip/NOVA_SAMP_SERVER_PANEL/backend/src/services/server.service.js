'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const fs = require('fs');
const path = require('path');
const db = require('../config/database');
const { SERVERS_DIR, BACKUPS_DIR, TEMPLATES_DIR } = require('../config/environment');
const v = require('../utils/validation');
const { HttpError, newId, randomPassword, slug, nowIso } = require('../utils/helpers');
const processService = require('./process.service');
const consoleService = require('./console.service');

const DEFAULT_EXE = { samp: process.platform === 'win32' ? 'samp-server' : 'samp03svr', openmp: 'omp-server' };
const TYPES = Object.keys(DEFAULT_EXE);

const publicServer = (s) => {
  const { rconPassword, ...rest } = s;
  return { ...rest, hasRcon: Boolean(rconPassword) };
};

const list = () => db.servers;

function get(id) {
  const s = db.servers.find((x) => x.id === id);
  if (!s) throw new HttpError(404, 'Walang ganyang server.');
  return s;
}

function executableName(value, fallback) {
  const name = value === undefined || value === '' ? fallback : v.oneLine(value, 'executable', 60);
  if (!/^[A-Za-z0-9._-]+$/.test(name)) throw new HttpError(400, 'Hindi valid ang pangalan ng executable.');
  return name;
}

function copyTemplate(type, dest, vars) {
  const src = path.join(TEMPLATES_DIR, type);
  if (fs.existsSync(src)) fs.cpSync(src, dest, { recursive: true, filter: (p) => path.basename(p) !== '.gitkeep' });
  for (const file of ['server.cfg', 'config.json']) {
    const p = path.join(dest, file);
    if (!fs.existsSync(p)) continue;
    let text = fs.readFileSync(p, 'utf8');
    text = text
      .replace(/\{\{NAME_JSON\}\}/g, JSON.stringify(vars.name).slice(1, -1))
      .replace(/\{\{NAME\}\}/g, vars.name)
      .replace(/\{\{PORT\}\}/g, String(vars.port))
      .replace(/\{\{RCON_PASSWORD\}\}/g, vars.rconPassword);
    fs.writeFileSync(p, text);
  }
}

function create(input) {
  const name = v.oneLine(input.name, 'name', 40);
  if (name.length < 3) throw new HttpError(400, '"name" ay dapat 3-40 na character.');
  const type = input.type === undefined ? 'samp' : input.type;
  if (!TYPES.includes(type)) throw new HttpError(400, 'Ang type ay "samp" o "openmp".');
  const host = input.host ? v.host(input.host) : '127.0.0.1';
  const port = input.port === undefined || input.port === '' ? 7777 : v.port(input.port);
  if (db.servers.some((s) => s.host === host && s.port === port)) {
    throw new HttpError(409, `May server na sa ${host}:${port}.`);
  }
  const rconPassword = input.rconPassword ? v.oneLine(input.rconPassword, 'rconPassword', 64) : randomPassword(16);
  const id = newId();

  let dir;
  let fresh = true;
  if (input.path) {
    dir = path.resolve(String(input.path));
    let st;
    try { st = fs.statSync(dir); } catch { throw new HttpError(400, 'Walang folder sa path na ibinigay mo.'); }
    if (!st.isDirectory()) throw new HttpError(400, 'Hindi folder ang path na ibinigay mo.');
    fresh = false;
  } else {
    dir = path.join(SERVERS_DIR, `${id}-${slug(name)}`);
    fs.mkdirSync(dir, { recursive: true });
    copyTemplate(type, dir, { name, port, rconPassword });
  }

  const server = {
    id, name, type, host, port, rconPassword, path: dir,
    executable: executableName(input.executable, DEFAULT_EXE[type]),
    autoRestart: v.bool(input.autoRestart),
    managedFolder: fresh,
    createdAt: nowIso(),
  };
  db.servers.push(server);
  db.save();
  return server;
}

function update(id, input) {
  const s = get(id);
  if (input.name !== undefined) {
    const name = v.oneLine(input.name, 'name', 40);
    if (name.length < 3) throw new HttpError(400, '"name" ay dapat 3-40 na character.');
    s.name = name;
  }
  const nextHost = input.host !== undefined ? v.host(input.host) : s.host;
  const nextPort = input.port !== undefined ? v.port(input.port) : s.port;
  if (db.servers.some((o) => o.id !== id && o.host === nextHost && o.port === nextPort)) {
    throw new HttpError(409, `May server na sa ${nextHost}:${nextPort}.`);
  }
  s.host = nextHost;
  s.port = nextPort;
  if (input.rconPassword) s.rconPassword = v.oneLine(input.rconPassword, 'rconPassword', 64);
  if (input.executable !== undefined) s.executable = executableName(input.executable, DEFAULT_EXE[s.type]);
  if (input.autoRestart !== undefined) s.autoRestart = v.bool(input.autoRestart);
  db.save();
  return s;
}

async function remove(id, deleteFiles) {
  const s = get(id);
  if (processService.isRunning(id)) await processService.stop(s);
  db.servers.splice(db.servers.indexOf(s), 1);
  db.save();
  consoleService.drop(id);
  if (deleteFiles) {
    const inside = path.resolve(s.path).startsWith(path.resolve(SERVERS_DIR) + path.sep);
    if (inside) fs.rmSync(s.path, { recursive: true, force: true });
    fs.rmSync(path.join(BACKUPS_DIR, id), { recursive: true, force: true });
  }
  return { deletedFiles: Boolean(deleteFiles && s.managedFolder) };
}

// I-register ang server na galing sa na-extract na archive (import).
function registerImported(input, dir) {
  const exists = (n) => fs.existsSync(path.join(dir, n)) || fs.existsSync(path.join(dir, n + '.exe'));
  let type = input.type;
  if (!type) type = exists('omp-server') || (fs.existsSync(path.join(dir, 'config.json')) && !fs.existsSync(path.join(dir, 'server.cfg'))) ? 'openmp' : 'samp';
  if (!TYPES.includes(type)) throw new HttpError(400, 'Ang type ay "samp" o "openmp".');
  const candidates = type === 'openmp' ? ['omp-server'] : ['samp03svr', 'samp-server'];
  const executable = candidates.find(exists) || DEFAULT_EXE[type];

  const cfgName = type === 'openmp' ? 'config.json' : 'server.cfg';
  const cfgPath = path.join(dir, cfgName);
  let content = '';
  try { content = fs.readFileSync(cfgPath, 'utf8'); } catch { /* walang config */ }

  const host = input.host ? v.host(input.host) : '127.0.0.1';
  if (input.port !== undefined && input.port !== '') {
    const port = v.port(input.port);
    if (content) { // isulat ang bagong port sa config mismo
      if (type === 'openmp') {
        try { const j = JSON.parse(content); j.network = { ...(j.network || {}), port }; content = JSON.stringify(j, null, 2); } catch { /* hayaan */ }
      } else if (/^\s*port\s+\d+/m.test(content)) content = content.replace(/^(\s*)port\s+\d+/m, `$1port ${port}`);
      else content += `\nport ${port}\n`;
      fs.writeFileSync(cfgPath, content);
    }
  }
  const parsed = parseConfig(type, content);
  const port = input.port !== undefined && input.port !== '' ? v.port(input.port) : (parsed.port || 7777);
  const owner = db.servers.find((s) => s.host === host && s.port === port);
  if (owner) throw new HttpError(409, `May server na ("${owner.name}") sa ${host}:${port}. Maglagay ng ibang port sa import form.`);

  const server = {
    id: input.id || newId(), name: v.oneLine(input.name, 'name', 40), type, host, port,
    rconPassword: parsed.rcon || '', path: dir, executable, autoRestart: false, managedFolder: true, createdAt: nowIso(),
  };
  if (server.name.length < 3) throw new HttpError(400, '"name" ay dapat 3-40 na character.');
  db.servers.push(server);
  db.save();
  return { server, found: { executable: fs.existsSync(path.join(dir, executable)) || fs.existsSync(path.join(dir, executable + '.exe')), config: Boolean(content) } };
}

function configFile(server) {
  return server.type === 'openmp' ? 'config.json' : 'server.cfg';
}

function readConfig(server) {
  const file = path.join(server.path, configFile(server));
  let content = '';
  try { content = fs.readFileSync(file, 'utf8'); } catch { /* wala pa */ }
  return { file: configFile(server), content };
}

// Kunin ang port at rcon password sa laman ng config file.
function parseConfig(type, content) {
  const out = { port: null, rcon: null };
  try {
    if (type === 'openmp') {
      const j = JSON.parse(content);
      if (j.network && Number.isInteger(j.network.port)) out.port = j.network.port;
      if (j.rcon && typeof j.rcon.password === 'string' && j.rcon.password) out.rcon = j.rcon.password;
    } else {
      const p = /^\s*port\s+(\d+)/m.exec(content);
      const r = /^\s*rcon_password\s+(\S+)/m.exec(content);
      if (p && Number(p[1]) >= 1 && Number(p[1]) <= 65535) out.port = Number(p[1]);
      if (r) out.rcon = r[1];
    }
  } catch { /* hindi valid ang config; ok lang */ }
  return out;
}

// Pagkatapos i-save ang config, i-sync ang port at rcon password sa panel.
function syncFromConfig(server, content) {
  const c = parseConfig(server.type, content);
  if (c.port) server.port = c.port;
  if (c.rcon) server.rconPassword = c.rcon;
  db.save();
}

function saveConfig(server, content) {
  if (typeof content !== 'string' || content.length > 200_000) throw new HttpError(400, 'Masyadong malaki o mali ang config.');
  if (server.type === 'openmp') {
    try { JSON.parse(content); } catch (e) { throw new HttpError(400, `Hindi valid na JSON: ${e.message}`); }
  }
  const file = path.join(server.path, configFile(server));
  if (fs.existsSync(file)) fs.copyFileSync(file, file + '.bak');
  fs.writeFileSync(file, content);
  syncFromConfig(server, content);
  return { file: configFile(server), restartNeeded: processService.isRunning(server.id) };
}

module.exports = { list, get, create, update, remove, publicServer, readConfig, saveConfig, registerImported, parseConfig, TYPES };
