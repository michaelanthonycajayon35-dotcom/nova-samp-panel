Ilagay dito (gamit ang File Manager ng panel) ang:
  - samp03svr (Linux) o samp-server.exe (Windows)
  - mga .amx sa gamemodes/ at filterscripts/
  - mga plugin sa plugins/
Tapos pindutin ang Start sa panel.
