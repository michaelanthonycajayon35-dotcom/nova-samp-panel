#!/usr/bin/env bash
# NOVA SAMP SERVER PANEL - by CAJAYON
# Pang-Linux (Debian/Ubuntu) na VPS o PC. Ginagawang service ang panel para tuloy-tuloy at auto-start sa reboot.
#   sudo bash deployment/install.sh
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then echo "Patakbuhin gamit ang sudo: sudo bash deployment/install.sh"; exit 1; fi

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_USER="${SUDO_USER:-root}"

echo "==> Chine-check ang Node.js (kailangan 20 o mas bago)"
if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  echo "Walang Node.js 20+. Mag-install gamit ang NodeSource:"
  echo "  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt-get install -y nodejs"
  exit 1
fi

echo "==> Ini-install ang tar at 32-bit libraries (para sa samp03svr)"
if command -v apt-get >/dev/null 2>&1; then
  dpkg --add-architecture i386 || true
  apt-get update -y
  apt-get install -y tar libc6:i386 libstdc++6:i386 || echo "(Hindi na-install ang i386 libs. Kung open.mp lang ang gamit mo, ok lang ito.)"
fi

if [ ! -f "$APP_DIR/.env" ]; then
  cp "$APP_DIR/.env.example" "$APP_DIR/.env"
  echo "==> Gumawa ng .env (random ang admin password; makikita sa: journalctl -u nova-panel)"
fi
mkdir -p "$APP_DIR/storage"
chown -R "$RUN_USER" "$APP_DIR/storage" "$APP_DIR/.env"

echo "==> Gumagawa ng systemd service"
cat > /etc/systemd/system/nova-panel.service <<UNIT
[Unit]
Description=NOVA SAMP Server Panel
After=network.target

[Service]
Type=simple
User=$RUN_USER
WorkingDirectory=$APP_DIR
ExecStart=$(command -v node) backend/src/server.js
Restart=always
RestartSec=3
# Kapag nag-restart ang panel, hihinto rin ang mga server na pinatakbo nito (sinasara nang maayos)
KillMode=mixed
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now nova-panel
sleep 2
systemctl --no-pager status nova-panel | head -n 8 || true

PORT="$(grep -E '^PORT=' "$APP_DIR/.env" | cut -d= -f2 || true)"; PORT="${PORT:-3000}"
echo
echo "Tapos na! Buksan ang  http://IP-NG-SERVER-MO:${PORT}"
echo "Para makita ang unang admin password:  journalctl -u nova-panel | grep -A4 'UNANG ADMIN'"
echo "Buksan din ang firewall: TCP ${PORT} (panel) at UDP 7777 (SA-MP server)."
