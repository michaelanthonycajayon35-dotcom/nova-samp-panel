'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const c = require('../controllers/auth.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { limiter } = require('../middleware/rate-limit.middleware');

module.exports = (router) => {
  router.post('/api/auth/login', limiter({ windowMs: 60_000, max: 20, name: 'login' }), c.login);
  router.get('/api/auth/me', authenticate, c.me);
  router.post('/api/auth/password', authenticate, c.changePassword);
};
