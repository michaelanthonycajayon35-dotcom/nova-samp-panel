'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const c = require('../controllers/users.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');

const admin = requireRole('admin');

module.exports = (router) => {
  router.get('/api/users', authenticate, admin, c.list);
  router.post('/api/users', authenticate, admin, c.create);
  router.patch('/api/users/:id', authenticate, admin, c.update);
  router.delete('/api/users/:id', authenticate, admin, c.remove);
};
