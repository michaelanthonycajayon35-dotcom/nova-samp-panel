// NOVA SAMP SERVER PANEL - by CAJAYON | Server Details
import { h, poll, copyText } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api } from '../scripts/api.js';
import { hasRole } from '../scripts/auth.js';
import { navigate } from '../scripts/navigation.js';
import { notify } from '../scripts/notifications.js';
import { refreshServers, setCurrent } from '../scripts/state.js';
import { bytes, duration, typeLabel } from '../scripts/format.js';
import { StatusChip } from '../components/ServerCard.js';
import { Banner } from '../components/Notification.js';
import { openSheet, sheetActions } from '../components/Modal.js';
import { confirmDialog } from '../components/ConfirmDialog.js';

export async function mount(root, { params }) {
  const id = params.id;
  const base = `/api/servers/${id}`;
  setCurrent(id);
  const live = h('div', { class: 'stack' });
  const statics = h('div', { class: 'stack' });
  root.replaceChildren(live, statics);

  let data = null;
  let busy = false;

  const kv = (k, v) => h('div', null, h('div', { class: 'k' }, k), h('div', { class: 'v' }, v));

  async function act(kind) {
    if (busy) return;
    const names = { start: 'Start', stop: 'Stop', restart: 'Restart' };
    if (kind !== 'start') {
      const ok = await confirmDialog({
        title: `${names[kind]} ang server?`, danger: kind === 'stop',
        message: kind === 'stop' ? 'Madidiskonekta ang lahat ng players.' : 'Madidiskonekta sandali ang lahat ng players.', confirmText: names[kind],
      });
      if (!ok) return;
    }
    busy = true;
    paintLive();
    try {
      await api.post(`${base}/${kind}`);
      notify.ok(kind === 'stop' ? 'Pinahinto ang server.' : 'Gumagana na ang server.');
    } catch (e) { notify.error(e.message); }
    busy = false;
    await refresh();
  }

  function paintLive() {
    if (!data) return;
    const { server: s, query: q, executableFound } = data;
    const p = s.process;
    const running = p.running;
    const items = [
      h('div', { class: 'row between' },
        h('div', { class: 'row grow', style: { minWidth: 0 } },
          h('button', { class: 'btn icon sm ghost', 'aria-label': 'Balik', onclick: () => navigate('/servers') }, icon('chevronLeft')),
          h('div', { class: 'grow', style: { minWidth: 0 } }, h('h1', { class: 'ellipsis' }, s.name),
            h('button', { class: 'chip', style: { marginTop: '4px', cursor: 'pointer' }, onclick: async () => { notify[(await copyText(`${s.host}:${s.port}`)) ? 'ok' : 'error']('Na-copy ang address.'); } },
              icon('copy', 12), `${s.host}:${s.port}`)))
        , StatusChip({ ...s, query: q })),
    ];
    if (hasRole('moderator')) {
      items.push(h('div', { class: 'actions' },
        h('button', { class: 'btn ok', disabled: busy || running, onclick: () => act('start') }, icon('play', 18), 'Start'),
        h('button', { class: 'btn danger', disabled: busy || !running, onclick: () => act('stop') }, icon('stop', 18), 'Stop'),
        h('button', { class: 'btn', disabled: busy || !running, onclick: () => act('restart') }, icon('restart', 18), 'Restart')));
    }
    if (!executableFound && !running && !q.online) {
      items.push(Banner('warn', h('b', null, `Walang "${s.executable}" sa folder ng server.`), h('div', { class: 'muted' },
        'I-upload ang server files (executable, gamemodes, plugins) gamit ang Files. Kung tumatakbo na ang server sa ibang paraan, gagana pa rin ang monitoring at RCON.'),
      hasRole('admin') ? h('button', { class: 'btn sm', style: { marginTop: '10px' }, onclick: () => navigate('/files') }, icon('folder', 16), 'Buksan ang Files') : null));
    } else if (running && !q.online) {
      items.push(Banner('info', 'Tumatakbo ang proseso pero hindi pa sumasagot sa query. Maghintay sandali, o tingnan ang Console kung may error.'));
    } else if (!running && q.online) {
      items.push(Banner('info', 'Online ang server pero hindi ito pinapatakbo ng panel (external). Gagana ang RCON at monitoring, pero hindi ang Start/Stop.'));
    }
    items.push(h('div', { class: 'kv' },
      kv('Players', `${q.players ?? 0} / ${q.maxPlayers ?? 0}`), kv('Ping', q.online ? `${q.ping} ms` : '-'),
      kv('Gamemode', q.gamemode || '-'), kv('Language', q.language || '-'),
      kv('Uptime', running ? duration(p.uptimeSec) : '-'), kv('Memory', p.memoryBytes ? bytes(p.memoryBytes) : '-'),
      kv('Uri', typeLabel(s.type)), kv('PID', p.pid || '-')));
    items.push(h('div', { class: 'shortcuts' },
      shortcut('terminal', 'Console', '/console'),
      hasRole('moderator') ? shortcut('shield', 'RCON', '/rcon') : null,
      shortcut('users', 'Players', '/players'),
      hasRole('admin') ? shortcut('folder', 'Files', '/files') : null,
      hasRole('moderator') ? shortcut('backup', 'Backups', '/backups') : null));
    live.replaceChildren(...items.filter(Boolean));
  }

  const shortcut = (ic, label, path) => h('button', { class: 'shortcut', onclick: () => navigate(path) }, icon(ic), label);

  async function refresh() {
    data = await api.get(base);
    paintLive();
  }

  function openConfigEditor() {
    openSheet({
      title: 'Server config', full: true,
      content: (close) => {
        const ta = h('textarea', { class: 'input editor', spellcheck: 'false', autocapitalize: 'off', wrap: 'off' }, '');
        const fileLabel = h('span', { class: 'chip' }, '...');
        const save = h('button', { class: 'btn primary', onclick: async () => {
          save.classList.add('loading');
          try {
            const r = await api.put(`${base}/config`, { content: ta.value });
            notify.ok(r.restartNeeded ? 'Na-save. I-restart ang server para ma-apply.' : 'Na-save ang config.');
            await refreshServers();
            close();
            refresh();
          } catch (e) { notify.error(e.message); } finally { save.classList.remove('loading'); }
        } }, icon('check', 18), 'I-save');
        api.get(`${base}/config`).then((r) => { ta.value = r.content; fileLabel.textContent = r.file; }).catch((e) => { notify.error(e.message); close(); });
        return h('div', { style: { display: 'flex', flexDirection: 'column', flex: '1', minHeight: '0', gap: '10px' } },
          h('div', { class: 'row' }, fileLabel, h('span', { class: 'muted', style: { fontSize: '0.78rem' } }, 'Ang port at RCON password ay awtomatikong ina-sync sa panel.')),
          ta, sheetActions(h('button', { class: 'btn', onclick: () => close() }, 'Cancel'), save));
      },
    });
  }

  async function buildStatics() {
    if (!hasRole('admin')) { statics.replaceChildren(); return; }
    const s = data.server;
    const f = {
      name: h('input', { class: 'input', value: s.name, maxlength: '40' }),
      host: h('input', { class: 'input', value: s.host, autocapitalize: 'off' }),
      port: h('input', { class: 'input', value: String(s.port), inputmode: 'numeric' }),
      rcon: h('input', { class: 'input', placeholder: s.hasRcon ? '•••••••• (iwanang blangko kung hindi papalitan)' : 'Ilagay ang RCON password', autocapitalize: 'off', autocomplete: 'off' }),
      exe: h('input', { class: 'input', value: s.executable, autocapitalize: 'off' }),
      auto: h('input', { type: 'checkbox', checked: Boolean(s.autoRestart) }),
    };
    const saveBtn = h('button', { class: 'btn primary', onclick: async () => {
      saveBtn.classList.add('loading');
      try {
        const body = { name: f.name.value, host: f.host.value, port: f.port.value, executable: f.exe.value, autoRestart: f.auto.checked };
        if (f.rcon.value) body.rconPassword = f.rcon.value;
        await api.patch(base, body);
        f.rcon.value = '';
        notify.ok('Na-save ang settings.');
        await refreshServers();
        await refresh();
      } catch (e) { notify.error(e.message); } finally { saveBtn.classList.remove('loading'); }
    } }, 'I-save ang settings');
    const del = async () => {
      let alsoFiles = false;
      const ok = await new Promise((resolveOk) => {
        let answer = false;
        openSheet({
          title: 'Burahin ang server?', onClose: () => resolveOk(answer),
          content: (close) => {
            const cb = h('input', { type: 'checkbox' });
            return h('div', null,
              h('p', { class: 'muted' }, `Buburahin ang "${s.name}" sa panel. Titigil din ito kung tumatakbo.`),
              h('label', { class: 'switch' }, h('span', null, 'Burahin din ang mga file at backup nito'), cb),
              sheetActions(h('button', { class: 'btn', onclick: () => close() }, 'Cancel'),
                h('button', { class: 'btn danger', onclick: () => { answer = true; alsoFiles = cb.checked; close(); } }, 'Burahin')));
          },
        });
      });
      if (!ok) return;
      try {
        await api.del(`${base}?deleteFiles=${alsoFiles}`);
        notify.ok('Nabura ang server.');
        await refreshServers();
        navigate('/servers');
      } catch (e) { notify.error(e.message); }
    };
    statics.replaceChildren(
      h('div', { class: 'section-title' }, h('h2', null, 'Config')),
      h('button', { class: 'card clickable row between', onclick: openConfigEditor, style: { color: 'inherit', textAlign: 'left' } },
        h('div', { class: 'row' }, icon('edit'), h('div', null, h('b', null, s.type === 'openmp' ? 'I-edit ang config.json' : 'I-edit ang server.cfg'), h('div', { class: 'muted', style: { fontSize: '0.8rem' } }, 'Hostname, maxplayers, gamemode, plugins...'))), icon('chevronRight')),
      h('div', { class: 'section-title' }, h('h2', null, 'Settings')),
      h('div', { class: 'card form-grid' },
        h('div', { class: 'field' }, h('label', null, 'Pangalan'), f.name),
        h('div', { class: 'form-grid two' }, h('div', { class: 'field' }, h('label', null, 'Host / IP'), f.host), h('div', { class: 'field' }, h('label', null, 'Port'), f.port)),
        h('div', { class: 'field' }, h('label', null, 'RCON password'), f.rcon),
        h('div', { class: 'field' }, h('label', null, 'Executable'), f.exe),
        h('label', { class: 'switch' }, h('span', null, h('b', null, 'Auto-restart'), h('div', { class: 'muted', style: { fontSize: '0.78rem' } }, 'Awtomatikong buksan ulit kapag nag-crash')), f.auto),
        saveBtn),
      h('div', { class: 'section-title' }, h('h2', null, 'Danger zone')),
      h('button', { class: 'btn danger block', onclick: del }, icon('trash', 18), 'Burahin ang server'));
  }

  await refresh();
  await buildStatics();
  return poll(async () => { if (!busy) await refresh(); }, 4000);
}
