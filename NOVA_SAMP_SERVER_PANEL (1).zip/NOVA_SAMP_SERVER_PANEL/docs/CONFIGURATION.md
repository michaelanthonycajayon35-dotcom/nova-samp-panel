# Configuration (`.env`)

| Variable | Default | Paliwanag |
|---|---|---|
| `PORT` | `3000` | Port ng panel |
| `HOST` | `0.0.0.0` | `127.0.0.1` kung nasa likod ng nginx |
| `ADMIN_USER` / `ADMIN_PASSWORD` | `admin` / *(random)* | Unang admin. Ginagawa lang kapag wala pang user. Kung walang password, random at ipapakita sa console; papalitan pag-login |
| `JWT_SECRET` | *(auto)* | Kung wala, gagawa at ise-save sa `storage/database/jwt.secret` |
| `JWT_EXPIRES_HOURS` | `12` | Tagal ng login |
| `CORS_ORIGINS` | `*` | Bearer token ang gamit (walang cookie) kaya ligtas ang `*`. Maaaring ilista ang partikular na origin |
| `MAX_UPLOAD_MB` | `50` | Max na laki ng upload sa File Manager |
| `MAX_IMPORT_MB` | `500` | Max na laki ng archive sa Import |
| `TRUST_PROXY` | `false` | `true` kung nasa likod ng nginx/Cloudflare |
| `STORAGE_DIR` | `storage` | Saan ilalagay ang database, servers, backups, logs |

## Mga role
| Role | Kaya |
|---|---|
| viewer | Dashboard, players, console (tingin lang) |
| moderator | + Start/Stop/Restart, RCON, kick/ban/announce, console command, gumawa ng backup |
| admin | + Files, config editor, import/gumawa/burahin ang server, restore/download backup, users, settings |

## Mga setting sa app
Settings → pangalan ng panel, ilang backup ang itatabi, auto-backup (6h … lingguhan).

## Paano naka-store ang data
`storage/database/nova.json` (users, servers, settings, audit). Ang mga password ng user ay naka-hash (scrypt). Ang RCON password ng server ay naka-store nang plain-text sa file na ito (kailangan ito para makapag-RCON) — kaya protektado ang folder (`chmod 600`).
