# NOVA SAMP Server Panel

Mobile-first na control panel para sa **SA-MP** at **open.mp** server. By **CAJAYON**.
Gumagana sa browser at pwedeng gawing **APK** (Android) gamit ang GitHub Actions — libre.

## Mga feature
- **Dashboard** — CPU / RAM / disk ng makina, live na players ng bawat server, huling aktibidad
- **Servers** — gumawa ng bago o **i-import ang dati mong server (zip / tar.gz)**; auto-detect ang uri, executable, port at RCON
- **Start / Stop / Restart** (may auto-restart kapag nag-crash)
- **Live Console** + `server_log.txt` viewer
- **RCON** — quick commands, history, babala sa delikadong command
- **Players** — listahan (ID, score, ping), kick / ban / announce
- **File Manager** — upload (may progress), edit (.cfg/.pwn/...), rename, delete, download
- **Backups** — manual at awtomatiko, restore (may safety backup), retention
- **Users & roles** — `viewer` / `moderator` / `admin`
- Walang external na dependency ang backend (Node.js lang) — walang `npm install` na kailangan para tumakbo

## Mabilis na simula
```bash
# kailangan: Node.js 20 o mas bago
cp .env.example .env        # optional
node backend/src/server.js  # o: npm start
```
Buksan ang `http://localhost:3000`. Sa unang takbo, may **admin account na gagawin** at ipapakita ang password sa console (papalitan mo ito pag-login).

Para sa VPS na tuloy-tuloy (24/7, auto-start): `sudo bash deployment/install.sh` — tingnan ang [docs/INSTALLATION.md](docs/INSTALLATION.md).

## Paano mag-import ng server
1. I-zip ang **buong folder** ng server mo (`samp03svr`, `server.cfg`, `gamemodes/`, `plugins/`, ...).
2. Sa app: **Servers → Import** → piliin ang zip → **I-import**.
3. Buksan ang server → **Start**.

> Sa Linux VPS, 32-bit ang `samp03svr`. Kailangan: `sudo apt install libc6:i386 libstdc++6:i386` (ginagawa ito ng `install.sh`).

## Gawing APK (GitHub Actions)
1. I-upload ang buong folder na ito sa GitHub repo mo (`git init`, `git add .`, `git commit`, `git push`).
2. Pumunta sa tab na **Actions** → **Build APK** → hintayin (mga 5–10 min) → i-download ang **NOVA-SAMP-Panel-apk**.
   - Mas madali sa phone: mag-push ng tag (`git tag v1.0.0 && git push --tags`) at lalabas ang APK sa **Releases**.
3. I-install sa phone (payagan ang "Install unknown apps").
4. Sa login ng app, ilagay ang **Server URL** (hal. `http://IP-NG-VPS:3000`), username at password.

Ang APK ay "bintana" lang papunta sa panel na tumatakbo sa VPS/PC mo. Hindi tumatakbo sa loob ng phone ang SA-MP server.

## Libreng hosting?
Basahin ang [docs/HOSTING.md](docs/HOSTING.md) — tapat na paliwanag kung ano ang totoong libre at ano ang may limitasyon.

## Istruktura
```
backend/     Node.js API (walang dependency) + tests
frontend/    Static web app (walang build step) — ito rin ang laman ng APK
server_templates/   Template ng bagong SA-MP / open.mp server
deployment/  install.sh (systemd), Dockerfile, docker-compose, nginx
docs/        Gabay: installation, configuration, API, security, backup, troubleshooting, hosting
storage/     Database, mga server, backups, logs (hindi naka-commit sa git)
```

## Test
`npm test` — 38 na test (auth, roles, servers, RCON/query gamit ang pekeng SA-MP server, files, backups, import).

## License
MIT — tingnan ang [LICENSE](LICENSE).
