'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const c = require('../controllers/dashboard.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');

module.exports = (router) => {
  router.get('/api/dashboard', authenticate, requireRole('viewer'), c.overview);
};
