# Troubleshooting

**"Hindi maabot ang panel server" sa APK**
- Tama ba ang Server URL (kasama ang `http://` at port)? Subukan sa browser ng phone muna.
- Bukas ba ang TCP 3000 sa firewall / security list ng VPS?

**Start → "Hindi ma-start ... ENOENT" (Linux)**
Kulang ang 32-bit libraries: `sudo dpkg --add-architecture i386 && sudo apt update && sudo apt install -y libc6:i386 libstdc++6:i386`

**Start → "Walang samp03svr sa folder"**
I-upload ang `samp03svr` (Linux) o `samp-server.exe` (Windows) sa folder ng server (Files), o i-import ang buong server zip. Para sa open.mp: `omp-server`.

**Nag-exit agad ang server**
Tingnan ang Console. Karaniwan: maling `server.cfg`, kulang na `.amx`, o `rcon_password changeme` (hindi ito tinatanggap ng SA-MP).

**Offline sa panel pero tumatakbo ang server**
- Tama ba ang host/port sa Server Details? (dapat tugma sa `port` sa `server.cfg`)
- Dapat `query 1` sa `server.cfg`.

**RCON: "Invalid RCON password"** — iba ang password sa panel kumpara sa `server.cfg`. I-save ulit ang config sa editor para ma-sync, o ilagay sa Settings ng server.

**RCON: walang sagot** — normal sa ilang command (hal. `gmx`). Kung wala talagang sagot, tingnan kung nakabukas ang UDP port sa firewall.

**Players: walang lumalabas** — ang SA-MP ay hindi nagbibigay ng player list kapag lampas 100 ang players.

**Import: "May server na sa host:port"** — magbigay ng ibang port sa import form (isusulat nito sa `server.cfg`).

**Windows** — gumagana ang panel; ang backup/import ay gumagamit ng `tar` (kasama sa Windows 10+).

**Nag-restart ang panel at namatay ang mga server** — sinasara ng panel ang mga server na pinatakbo nito kapag humihinto. Gamitin ang `systemd` (auto-start) at i-on ang Auto-restart.

## Logs
`storage/logs/panel.log` at `journalctl -u nova-panel`.
