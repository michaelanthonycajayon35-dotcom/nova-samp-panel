'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Start / stop / restart ng samp03svr o omp-server.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const db = require('../config/database');
const consoleService = require('./console.service');
const logger = require('../utils/logger');
const { HttpError, sleep } = require('../utils/helpers');

const running = new Map(); // serverId -> { child, startedAt, stopping, exited }
const crashLog = new Map(); // serverId -> [timestamps]

function exePath(server) {
  const names = process.platform === 'win32' ? [server.executable, server.executable + '.exe'] : [server.executable];
  for (const n of names) {
    const p = path.join(server.path, n);
    try { if (fs.statSync(p).isFile()) return p; } catch { /* next */ }
  }
  return null;
}

function isRunning(id) { return running.has(id); }

function memoryOf(pid) {
  try {
    const m = /VmRSS:\s+(\d+)\s+kB/.exec(fs.readFileSync(`/proc/${pid}/status`, 'utf8'));
    return m ? Number(m[1]) * 1024 : null;
  } catch { return null; }
}

function status(id) {
  const e = running.get(id);
  if (!e) return { running: false, pid: null, startedAt: null, uptimeSec: 0, memoryBytes: null };
  return {
    running: true,
    pid: e.child.pid,
    startedAt: new Date(e.startedAt).toISOString(),
    uptimeSec: Math.floor((Date.now() - e.startedAt) / 1000),
    memoryBytes: memoryOf(e.child.pid),
  };
}

async function start(server) {
  if (running.has(server.id)) throw new HttpError(409, 'Tumatakbo na ang server.');
  const exe = exePath(server);
  if (!exe) {
    throw new HttpError(400, `Walang "${server.executable}" sa folder ng server. I-upload ito sa File Manager (kasama ang gamemodes at plugins), o gamitin ang RCON kung tumatakbo na ito sa labas.`);
  }
  try { fs.chmodSync(exe, 0o755); } catch { /* ok lang */ }

  let spawnError = null;
  const child = spawn(exe, [], { cwd: server.path, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  const entry = { child, startedAt: Date.now(), stopping: false, exited: null };
  entry.exited = new Promise((resolve) => { entry.resolveExit = resolve; });
  running.set(server.id, entry);

  consoleService.append(server.id, `[panel] Sinisimulan ang ${server.executable}...`);
  child.stdout.on('data', (d) => consoleService.append(server.id, d.toString('utf8')));
  child.stderr.on('data', (d) => consoleService.append(server.id, d.toString('utf8')));
  child.stdin.on('error', () => { /* sarado na ang stdin */ });
  child.on('error', (err) => {
    spawnError = err;
    consoleService.append(server.id, `[panel] Hindi ma-start: ${err.message}`);
    if (running.get(server.id) === entry) running.delete(server.id);
    entry.resolveExit();
  });
  child.on('exit', (code, signal) => {
    if (running.get(server.id) === entry) running.delete(server.id);
    consoleService.append(server.id, `[panel] Huminto ang server (code=${code}, signal=${signal || '-'}).`);
    entry.resolveExit();
    maybeAutoRestart(server.id, entry);
  });

  await sleep(500);
  if (spawnError) {
    const hint = spawnError.code === 'ENOENT' && process.platform === 'linux'
      ? ' Malamang kulang ang 32-bit libraries (ang samp03svr ay 32-bit). Sa Debian/Ubuntu: sudo dpkg --add-architecture i386 && sudo apt update && sudo apt install -y libc6:i386 libstdc++6:i386'
      : '';
    throw new HttpError(500, `Hindi ma-start ang server: ${spawnError.message}.${hint}`);
  }
  if (!running.has(server.id)) {
    throw new HttpError(500, 'Nag-exit agad ang server. Tingnan ang Console para sa dahilan.');
  }
  logger.info(`Server ${server.name} (${server.id}) started, pid ${child.pid}`);
  return status(server.id);
}

function maybeAutoRestart(id, entry) {
  const server = db.servers.find((s) => s.id === id);
  if (!server || !server.autoRestart || entry.stopping) return;
  if (Date.now() - entry.startedAt < 5000) return; // iwas crash loop
  const now = Date.now();
  const recent = (crashLog.get(id) || []).filter((t) => now - t < 5 * 60_000);
  recent.push(now);
  crashLog.set(id, recent);
  if (recent.length > 5) {
    consoleService.append(id, '[panel] Masyadong maraming crash. Hindi na ito auto-restart.');
    return;
  }
  consoleService.append(id, '[panel] Auto-restart sa 3 segundo...');
  setTimeout(() => {
    const s = db.servers.find((x) => x.id === id);
    if (s && !running.has(id)) start(s).catch((e) => logger.error('Auto-restart failed:', e.message));
  }, 3000).unref();
}

async function stop(server) {
  const entry = running.get(server.id);
  if (!entry) throw new HttpError(409, 'Hindi tumatakbo ang server (sa panel).');
  entry.stopping = true;
  consoleService.append(server.id, '[panel] Pinapahinto ang server...');
  try { entry.child.kill('SIGTERM'); } catch { /* ignore */ }
  const timeout = sleep(8000).then(() => 'timeout');
  const result = await Promise.race([entry.exited.then(() => 'exited'), timeout]);
  if (result === 'timeout') {
    try { entry.child.kill('SIGKILL'); } catch { /* ignore */ }
    await Promise.race([entry.exited, sleep(2000)]);
  }
  running.delete(server.id);
  return status(server.id);
}

async function restart(server) {
  if (running.has(server.id)) await stop(server);
  return start(server);
}

function sendInput(id, command) {
  const entry = running.get(id);
  if (!entry) throw new HttpError(409, 'Hindi pinapatakbo ng panel ang server na ito. Gamitin ang RCON.');
  entry.child.stdin.write(command + '\n');
  consoleService.append(id, `> ${command}`);
}

async function stopAll() {
  const jobs = [];
  for (const [id] of running) {
    const server = db.servers.find((s) => s.id === id);
    if (server) jobs.push(stop(server).catch(() => {}));
  }
  await Promise.all(jobs);
}

module.exports = { start, stop, restart, status, isRunning, sendInput, stopAll, exePath };
