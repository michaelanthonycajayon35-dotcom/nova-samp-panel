# Installation

## Requirements
- Node.js **20 o mas bago** (`node -v`)
- `tar` (nasa Linux/macOS/Windows 10+ na)
- Linux VPS: `libc6:i386 libstdc++6:i386` para sa `samp03svr` (32-bit)

## A. Mabilis (kahit anong OS)
```bash
cp .env.example .env
node backend/src/server.js
```
Buksan ang `http://localhost:3000`. Makikita sa console ang unang admin username/password.

## B. Linux VPS (24/7, auto-start)
```bash
sudo bash deployment/install.sh
journalctl -u nova-panel | grep -A4 "UNANG ADMIN"     # makita ang password
sudo systemctl status nova-panel
sudo systemctl restart nova-panel
```
Buksan ang firewall: **TCP 3000** (panel) at **UDP 7777** (SA-MP; o ang port ng server mo).
```bash
sudo ufw allow 3000/tcp && sudo ufw allow 7777/udp
```

## C. Docker (Linux)
```bash
cd deployment && docker compose up -d --build
docker logs nova-samp-panel | grep -A4 "UNANG ADMIN"
```

## D. HTTPS (inirerekomenda kung may domain)
Gamitin ang `deployment/nginx.conf` + `sudo certbot --nginx -d panel.iyongdomain.com`, at i-set ang `TRUST_PROXY=true` sa `.env`. Pagkatapos, `https://panel.iyongdomain.com` na ang Server URL sa APK.

## Pag-update
Palitan ang mga file (huwag galawin ang `storage/` at `.env`) at i-restart ang panel.
