'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const fs = require('fs');
const path = require('path');
const { LOG_DIR, QUIET } = require('../config/environment');

const FILE = path.join(LOG_DIR, 'panel.log');
const MAX_BYTES = 5 * 1024 * 1024;

function write(level, args) {
  const msg = args.map((a) => (a instanceof Error ? (a.stack || a.message) : typeof a === 'string' ? a : JSON.stringify(a))).join(' ');
  const line = `${new Date().toISOString()} [${level}] ${msg}`;
  if (!QUIET) (level === 'ERROR' ? console.error : console.log)(line);
  try {
    if (fs.existsSync(FILE) && fs.statSync(FILE).size > MAX_BYTES) fs.renameSync(FILE, FILE + '.1');
    fs.appendFileSync(FILE, line + '\n');
  } catch { /* hindi dapat ma-crash dahil sa log */ }
}

module.exports = {
  info: (...a) => write('INFO', a),
  warn: (...a) => write('WARN', a),
  error: (...a) => write('ERROR', a),
};
