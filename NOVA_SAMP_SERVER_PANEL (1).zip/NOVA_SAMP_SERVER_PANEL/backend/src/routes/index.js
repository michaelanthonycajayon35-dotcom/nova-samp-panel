'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
module.exports = (router) => {
  for (const name of ['system', 'auth', 'dashboard', 'servers', 'console', 'rcon', 'players', 'files', 'backups', 'users', 'settings']) {
    require(`./${name}.routes`)(router);
  }
};
