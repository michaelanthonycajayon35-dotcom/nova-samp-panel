// NOVA SAMP SERVER PANEL - by CAJAYON | Players
import { h, poll } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api } from '../scripts/api.js';
import { hasRole } from '../scripts/auth.js';
import { notify } from '../scripts/notifications.js';
import { ensureServers, current } from '../scripts/state.js';
import { PageHead, NoServer, Empty } from '../components/Layout.js';
import { openMenu } from '../components/Modal.js';
import { confirmDialog, promptDialog } from '../components/ConfirmDialog.js';

const pingTone = (p) => (p == null ? '' : p < 80 ? 'ok' : p < 160 ? 'warn' : 'danger');

export async function mount(root) {
  await ensureServers();
  const s = current();
  if (!s) { root.replaceChildren(PageHead('Players'), NoServer()); return; }
  const base = `/api/servers/${s.id}`;
  const canMod = hasRole('moderator');
  let players = [];
  let ok = true;

  const search = h('input', { class: 'input', type: 'search', placeholder: 'Maghanap ng player...', autocapitalize: 'off' });
  const listBox = h('div', { class: 'card flat' });
  const count = h('span', { class: 'chip primary' }, '0');
  search.addEventListener('input', paint);

  async function moderate(kind, p) {
    const okc = await confirmDialog({ title: `${kind === 'kick' ? 'I-kick' : 'I-ban'} si ${p.name}?`, message: `Player ID: ${p.id}`, danger: true, confirmText: kind === 'kick' ? 'Kick' : 'Ban' });
    if (!okc) return;
    try { await api.post(`${base}/players/${p.id}/${kind}`); notify.ok(`${kind === 'kick' ? 'Na-kick' : 'Na-ban'} si ${p.name}.`); setTimeout(refresh, 600); } catch (e) { notify.error(e.message); }
  }

  async function broadcast() {
    const msg = await promptDialog({ title: 'Mag-announce sa lahat', label: 'Mensahe', placeholder: 'Hal. Server restart in 5 minutes!', confirmText: 'Ipadala' });
    if (!msg) return;
    try { await api.post(`${base}/say`, { message: msg }); notify.ok('Naipadala ang announcement.'); } catch (e) { notify.error(e.message); }
  }

  function paint() {
    const q = search.value.trim().toLowerCase();
    const shown = players.filter((p) => !q || p.name.toLowerCase().includes(q) || String(p.id) === q);
    count.textContent = String(players.length);
    listBox.replaceChildren();
    if (!ok) { listBox.append(Empty({ icon: 'warning', title: 'Hindi maabot ang server', text: 'Offline ang server, o mali ang host/port. Tingnan ang Server Details.' })); return; }
    if (!shown.length) { listBox.append(Empty({ icon: 'users', title: players.length ? 'Walang tugma' : 'Walang naglalaro', text: players.length ? 'Subukan ang ibang pangalan.' : 'Walang player na naka-online ngayon.' })); return; }
    for (const p of shown) {
      const row = h('div', { class: `list-item${canMod && p.id != null ? ' clickable' : ''}`,
        onclick: canMod && p.id != null ? () => openMenu(`${p.name} (ID ${p.id})`, [
          { label: 'I-kick', icon: 'logout', onClick: () => moderate('kick', p) },
          { label: 'I-ban', icon: 'ban', danger: true, onClick: () => moderate('ban', p) },
        ]) : null },
      h('div', { class: 'avatar' }, p.id == null ? '?' : String(p.id)),
      h('div', { class: 'grow' }, h('div', { class: 'title ellipsis' }, p.name), h('div', { class: 'meta' }, `Score: ${p.score}`)),
      p.ping != null ? h('span', { class: `chip ${pingTone(p.ping)}` }, `${p.ping} ms`) : null,
      canMod && p.id != null ? icon('chevronRight', 16) : null);
      listBox.append(row);
    }
  }

  async function refresh() {
    try { const r = await api.get(`${base}/players`); players = r.players; ok = r.ok; } catch (e) { ok = false; players = []; if (e.status === 401) return; }
    paint();
  }

  root.replaceChildren(
    PageHead('Players', s.name, count, canMod ? h('button', { class: 'btn sm', onclick: broadcast }, icon('message', 16), 'Announce') : null),
    h('div', { class: 'field', style: { marginBottom: '12px' } }, search), listBox);
  paint();
  return poll(refresh, 5000);
}
