'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { boot } = require('./support');

test('file manager at backups', async (t) => {
  const app = await boot();
  t.after(() => app.close());
  const { api } = app;
  const token = await app.login();
  const created = await api('POST', '/api/servers', { token, body: { name: 'Files Test', port: 7900 } });
  const server = created.json.server;
  const base = `/api/servers/${server.id}`;

  await t.test('list', async () => {
    const r = await api('GET', `${base}/files`, { token });
    assert.equal(r.status, 200);
    const names = r.json.entries.map((e) => e.name);
    assert.ok(names.includes('gamemodes') && names.includes('server.cfg'));
    assert.equal(r.json.entries[0].type, 'dir', 'folders muna');
    assert.equal(r.json.parent, null);
  });

  await t.test('sandbox: bawal lumabas sa folder ng server', async () => {
    for (const p of ['../', '../../etc', '..%2F..%2Fetc%2Fpasswd', '/etc', 'gamemodes/../../']) {
      const r = await api('GET', `${base}/files/read?path=${p}`, { token });
      assert.ok([400, 403, 404].includes(r.status), `${p} -> ${r.status}`);
      assert.ok(!/root:/.test(r.text));
    }
    fs.symlinkSync('/etc', path.join(server.path, 'escape'));
    const r = await api('GET', `${base}/files?path=escape`, { token });
    assert.equal(r.status, 403, 'symlink escape');
  });

  await t.test('write, read, rename, mkdir, delete', async () => {
    let r = await api('PUT', `${base}/files/write`, { token, body: { path: 'gamemodes/test.pwn', content: 'main() {}' } });
    assert.equal(r.status, 200);
    r = await api('GET', `${base}/files/read?path=gamemodes/test.pwn`, { token });
    assert.equal(r.json.content, 'main() {}');
    r = await api('POST', `${base}/files/rename`, { token, body: { path: 'gamemodes/test.pwn', name: 'main.pwn' } });
    assert.equal(r.json.path, 'gamemodes/main.pwn');
    assert.equal((await api('POST', `${base}/files/rename`, { token, body: { path: 'gamemodes/main.pwn', name: '../x' } })).status, 400);
    r = await api('POST', `${base}/files/mkdir`, { token, body: { path: 'scriptfiles', name: 'data' } });
    assert.equal(r.json.path, 'scriptfiles/data');
    r = await api('DELETE', `${base}/files?path=scriptfiles/data`, { token });
    assert.equal(r.status, 200);
    assert.equal((await api('DELETE', `${base}/files?path=`, { token })).status, 400, 'bawal burahin ang root');
  });

  await t.test('upload (raw) at download link', async () => {
    const data = Buffer.from([0, 1, 2, 3, 250, 251, 0, 9]);
    let r = await api('PUT', `${base}/files/upload?path=plugins&name=test.so`, { token, raw: data });
    assert.equal(r.status, 200);
    assert.equal(r.json.size, 8);
    assert.deepEqual(fs.readFileSync(path.join(server.path, 'plugins', 'test.so')), data);
    r = await api('GET', `${base}/files/read?path=plugins/test.so`, { token });
    assert.equal(r.status, 415, 'binary ay hindi ine-edit');
    r = await api('PUT', `${base}/files/upload?path=plugins&name=..%2Fevil.so`, { token, raw: data });
    assert.equal(r.status, 400);
    const link = await api('GET', `${base}/files/link?path=plugins/test.so`, { token });
    const dl = await fetch(app.base + link.json.url);
    assert.equal(dl.status, 200);
    assert.match(dl.headers.get('content-disposition'), /test\.so/);
    assert.deepEqual(Buffer.from(await dl.arrayBuffer()), data);
    assert.equal((await fetch(app.base + '/api/download?token=peke')).status, 401);
  });

  await t.test('files ay admin lang', async () => {
    await api('POST', '/api/users', { token, body: { username: 'mod1', password: 'moderator1', role: 'moderator' } });
    const mt = await app.login('mod1', 'moderator1');
    assert.equal((await api('GET', `${base}/files`, { token: mt })).status, 403);
    assert.equal((await api('GET', `${base}/config`, { token: mt })).status, 403);
  });

  await t.test('backup: create, list, restore, delete', async () => {
    const mt = await app.login('mod1', 'moderator1');
    let r = await api('POST', `${base}/backups`, { token: mt });
    assert.equal(r.status, 200);
    const name = r.json.backup.name;
    assert.match(name, /\.tar\.gz$/);
    assert.ok(r.json.backup.size > 0);
    assert.equal((await api('POST', `${base}/backups/${name}/restore`, { token: mt })).status, 403, 'restore ay admin lang');

    fs.writeFileSync(path.join(server.path, 'server.cfg'), 'SIRA');
    r = await api('POST', `${base}/backups/${name}/restore`, { token });
    assert.equal(r.status, 200);
    assert.match(fs.readFileSync(path.join(server.path, 'server.cfg'), 'utf8'), /rcon_password/);

    r = await api('GET', `${base}/backups`, { token });
    assert.ok(r.json.backups.length >= 2, 'may pre-restore backup');
    assert.ok(r.json.backups.some((b) => b.name.startsWith('pre-restore_')));

    const link = await api('GET', `${base}/backups/${name}/link`, { token });
    const dl = await fetch(app.base + link.json.url);
    assert.equal(dl.status, 200);
    assert.equal((await api('GET', `${base}/backups/..%2F..%2Fx.tar.gz/link`, { token })).status, 400);
    assert.equal((await api('DELETE', `${base}/backups/${name}`, { token })).status, 200);
  });
});
