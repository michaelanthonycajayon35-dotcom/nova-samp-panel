// NOVA SAMP SERVER PANEL - by CAJAYON | Users (admin lang)
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api } from '../scripts/api.js';
import { session } from '../scripts/auth.js';
import { notify } from '../scripts/notifications.js';
import { date } from '../scripts/format.js';
import { PageHead, Empty } from '../components/Layout.js';
import { Loading } from '../components/Loading.js';
import { openSheet, openMenu, sheetActions } from '../components/Modal.js';
import { confirmDialog, promptDialog } from '../components/ConfirmDialog.js';

const ROLE_INFO = {
  viewer: ['Viewer', 'Tingin lang: dashboard, players, console'],
  moderator: ['Moderator', 'Start/Stop, RCON, kick/ban, backup'],
  admin: ['Admin', 'Lahat: files, users, settings, servers'],
};
const tone = { viewer: '', moderator: 'info', admin: 'primary' };

export async function mount(root) {
  const box = h('div', { class: 'card flat' }, Loading());

  async function load() {
    try {
      const { users } = await api.get('/api/users');
      box.replaceChildren();
      for (const u of users) {
        const me = u.id === session.user.id;
        box.append(h('div', { class: 'list-item clickable', onclick: () => menu(u, me) },
          h('div', { class: 'avatar' }, u.username.slice(0, 1).toUpperCase()),
          h('div', { class: 'grow' }, h('div', { class: 'title ellipsis' }, u.username, me ? h('span', { class: 'muted' }, ' (ikaw)') : null), h('div', { class: 'meta' }, `Gawa: ${date(u.createdAt)}`)),
          u.disabled ? h('span', { class: 'chip danger' }, 'Disabled') : null,
          h('span', { class: `chip ${tone[u.role]}` }, ROLE_INFO[u.role][0]), icon('dots', 18)));
      }
    } catch (e) { box.replaceChildren(Empty({ icon: 'warning', title: 'Hindi ma-load', text: e.message })); }
  }

  const patch = async (u, body, okMsg) => {
    try { await api.patch(`/api/users/${u.id}`, body); notify.ok(okMsg); load(); } catch (e) { notify.error(e.message); }
  };

  function menu(u, me) {
    openMenu(u.username, [
      { label: 'Palitan ang role', icon: 'shield', onClick: () => roleSheet(u) },
      { label: 'I-reset ang password', icon: 'key', onClick: async () => {
        const pw = await promptDialog({ title: `Bagong password para kay ${u.username}`, label: 'Password (min. 8)', type: 'password', confirmText: 'I-save' });
        if (pw) patch(u, { password: pw }, 'Napalitan ang password.');
      } },
      me ? null : { label: u.disabled ? 'I-enable' : 'I-disable', icon: 'power', onClick: () => patch(u, { disabled: !u.disabled }, u.disabled ? 'Na-enable.' : 'Na-disable.') },
      me ? null : { label: 'Burahin', icon: 'trash', danger: true, onClick: async () => {
        const ok = await confirmDialog({ title: 'Burahin ang user?', message: u.username, danger: true, confirmText: 'Burahin' });
        if (!ok) return;
        try { await api.del(`/api/users/${u.id}`); notify.ok('Nabura.'); load(); } catch (e) { notify.error(e.message); }
      } },
    ]);
  }

  function roleSheet(u) {
    openSheet({ title: `Role ni ${u.username}`, content: (close) => h('div', null, Object.entries(ROLE_INFO).map(([r, [label, desc]]) =>
      h('button', { class: 'menu-item', onclick: () => { close(); if (r !== u.role) patch(u, { role: r }, 'Napalitan ang role.'); } },
        h('div', { class: 'grow' }, h('div', null, label), h('div', { class: 'muted', style: { fontSize: '0.78rem', fontWeight: '500' } }, desc)), r === u.role ? icon('check') : null))) });
  }

  function createForm() {
    openSheet({ title: 'Bagong user', content: (close) => {
      const username = h('input', { class: 'input', placeholder: 'username', autocapitalize: 'off', autocomplete: 'off' });
      const password = h('input', { class: 'input', type: 'text', placeholder: 'password (min. 8)', autocapitalize: 'off', autocomplete: 'off' });
      const role = h('select', { class: 'input' }, Object.entries(ROLE_INFO).map(([r, [label]]) => h('option', { value: r }, label)));
      const err = h('div', { class: 'banner danger hidden' });
      const btn = h('button', { class: 'btn primary', onclick: async () => {
        err.classList.add('hidden');
        btn.classList.add('loading');
        try { await api.post('/api/users', { username: username.value, password: password.value, role: role.value }); notify.ok('Nagawa ang user.'); close(); load(); } catch (e) { err.classList.remove('hidden'); err.textContent = e.message; } finally { btn.classList.remove('loading'); }
      } }, 'Gumawa');
      return h('div', { class: 'form-grid' },
        h('div', { class: 'field' }, h('label', null, 'Username'), username),
        h('div', { class: 'field' }, h('label', null, 'Password'), password),
        h('div', { class: 'field' }, h('label', null, 'Role'), role), err,
        sheetActions(h('button', { class: 'btn', onclick: () => close() }, 'Cancel'), btn));
    } });
  }

  root.replaceChildren(PageHead('Users', 'Sino ang pwedeng pumasok sa panel', h('button', { class: 'btn primary', onclick: createForm }, icon('plus'), 'Bago')), box);
  await load();
  return () => {};
}
