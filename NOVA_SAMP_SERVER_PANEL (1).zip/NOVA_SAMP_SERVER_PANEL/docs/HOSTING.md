# Libreng hosting para sa SA-MP server — ang totoo

**Walang totoong libre, walang limit, at 24/7 na hosting para sa game server.** Ang makina na tuloy-tuloy na tumatakbo ay may gastos (kuryente, bandwidth, hardware), at may magbabayad nito — ikaw, o ang kumpanyang nagbibigay ng "free tier" na may kondisyon. Ito ang mga totoong opsyon:

## 1. Sariling PC / laptop (talagang ₱0 sa hosting)
- Patakbuhin ang panel at server sa lumang PC/laptop na nakabukas 24/7. Kuryente at internet mo lang ang gastos.
- Para makapasok ang players, kailangan ng **port forward** sa router (UDP 7777 para sa server, TCP 3000 para sa panel) at kadalasan ay **public IP**. Maraming ISP sa Pilipinas ang CGNAT (walang public IP) — kung ganoon, gumamit ng libreng game-tunnel service (hal. playit.gg). I-check ang kanilang kasalukuyang limitasyon.
- Limitasyon: namamatay kapag nawalan ng kuryente/internet; nakadepende sa upload speed mo.

## 2. Oracle Cloud "Always Free" (libre pero may kondisyon)
Ayon sa [opisyal na docs ng Oracle](https://docs.oracle.com/en-us/iaas/Content/FreeTier/resourceref.htm) (nabasa noong Nov 2026):
- 2 × **AMD micro** VM (1/8 OCPU, 1 GB RAM bawat isa) — **x86**, kaya kaya nitong magpatakbo ng maliit na SA-MP server (`samp03svr`) at ng panel.
- **Ampere A1 (ARM)**: katumbas ng 2 OCPU / 12 GB — pero **ARM** ito, kaya hindi tatakbo nang diretso ang x86 na `samp03svr`.
- Maaaring bawiin ng Oracle ang "idle" na instance (CPU/network na mas mababa sa 20% sa loob ng 7 araw).
- Madalas may verification sa pag-sign up, at puwedeng magbago ang mga tuntunin. Basahin ang kanilang kasalukuyang terms bago umasa.
- Maliit lang ang 1 GB RAM: kaunting players at plugins lang.

## 3. Mga "libreng hosting" na HINDI para sa SA-MP
- Replit, Glitch, Render, Railway, Vercel, Netlify, Heroku-style na free plans: karaniwang walang **UDP** (kailangan ng SA-MP), nagse-"sleep", o may limitadong oras. Hindi gagana nang maayos.
- GitHub Actions / Codespaces: para sa build at pag-develop, bawal/hindi angkop na gawing 24/7 server.
- Sobrang murang "unlimited" na hosting: basahin ang terms; kadalasan bawal ang game server.

## 4. Murang bayad
Kung gusto mo ng walang problema, ang pinakamurang VPS (mga ilang daang piso kada buwan) ay mas maaasahan kaysa sa libre. Ang panel na ito ay gumagana sa kahit anong Linux/Windows na may Node.js 20+.

## Mga tip para tuloy-tuloy
- Gamitin ang `deployment/install.sh` (systemd): auto-start sa reboot at auto-restart kung mag-crash ang panel.
- I-on ang **Auto-restart** sa Server Details para buksan ulit ang SA-MP server kapag nag-crash.
- I-on ang **Auto-backup** sa Settings.
