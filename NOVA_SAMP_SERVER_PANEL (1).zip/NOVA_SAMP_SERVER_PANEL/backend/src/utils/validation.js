'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const { HttpError } = require('./helpers');

const ROLES = ['viewer', 'moderator', 'admin'];

function str(value, field, { min = 1, max = 200, optional = false } = {}) {
  if ((value === undefined || value === null || value === '') && optional) return undefined;
  if (typeof value !== 'string') throw new HttpError(400, `Kulang o mali ang "${field}".`);
  const v = value.trim();
  if (v.length < min || v.length > max) throw new HttpError(400, `"${field}" ay dapat ${min}-${max} na character.`);
  return v;
}

function port(value, field = 'port') {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1 || n > 65535) throw new HttpError(400, `Ang "${field}" ay dapat 1-65535.`);
  return n;
}

function host(value) {
  const v = str(value, 'host', { max: 253 });
  if (!/^[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?$/.test(v)) throw new HttpError(400, 'Hindi valid ang host/IP.');
  return v;
}

function username(value) {
  const v = str(value, 'username', { min: 3, max: 32 });
  if (!/^[a-zA-Z0-9_.-]+$/.test(v)) throw new HttpError(400, 'Username: letters, numbers, _ . - lang.');
  return v;
}

function password(value) {
  if (typeof value !== 'string' || value.length < 8 || value.length > 128) {
    throw new HttpError(400, 'Ang password ay dapat 8-128 na character.');
  }
  return value;
}

function role(value) {
  if (!ROLES.includes(value)) throw new HttpError(400, 'Mali ang role.');
  return value;
}

function bool(value) { return value === true || value === 'true' || value === 1; }

function oneLine(value, field, max = 200) {
  const v = str(value, field, { max });
  if (/[\r\n\0]/.test(v)) throw new HttpError(400, `"${field}" ay hindi pwedeng may bagong linya.`);
  return v;
}

module.exports = { ROLES, str, port, host, username, password, role, bool, oneLine };
