// NOVA SAMP SERVER PANEL - by CAJAYON | File Manager
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api } from '../scripts/api.js';
import { notify } from '../scripts/notifications.js';
import { ensureServers, current } from '../scripts/state.js';
import { bytes, date } from '../scripts/format.js';
import { PageHead, NoServer, Empty } from '../components/Layout.js';
import { Loading } from '../components/Loading.js';
import { openSheet, openMenu, sheetActions } from '../components/Modal.js';
import { confirmDialog, promptDialog } from '../components/ConfirmDialog.js';

const TEXT_EXT = /\.(cfg|txt|ini|json|pwn|inc|log|md|yml|yaml|conf|xml|csv|sh|bat|properties|sql|lua|js)$/i;

export async function mount(root, { query }) {
  await ensureServers();
  const s = current();
  if (!s) { root.replaceChildren(PageHead('Files'), NoServer()); return; }
  const base = `/api/servers/${s.id}`;
  let cwd = query.path || '';

  const crumbs = h('div', { class: 'crumbs' });
  const listBox = h('div', { class: 'card flat' });
  const progress = h('div', { class: 'bar hidden', style: { marginBottom: '12px' } }, h('i', { style: { width: '0%' } }));
  const picker = h('input', { type: 'file', multiple: true, class: 'hidden' });
  picker.addEventListener('change', async () => { await uploadFiles([...picker.files]); picker.value = ''; });

  const join = (name) => (cwd ? `${cwd}/${name}` : name);

  async function load(path = cwd) {
    listBox.replaceChildren(Loading());
    try {
      const r = await api.get(`${base}/files?path=${encodeURIComponent(path)}`);
      cwd = r.path;
      paintCrumbs();
      paintList(r);
    } catch (e) {
      notify.error(e.message);
      if (cwd) { cwd = ''; load(''); } else listBox.replaceChildren(Empty({ icon: 'warning', title: 'Hindi mabuksan ang folder', text: e.message }));
    }
  }

  function paintCrumbs() {
    const parts = cwd ? cwd.split('/') : [];
    crumbs.replaceChildren(h('button', { class: 'crumb', onclick: () => load('') }, icon('home', 16)));
    parts.forEach((p, i) => {
      crumbs.append(icon('chevronRight'), h('button', { class: 'crumb', onclick: () => load(parts.slice(0, i + 1).join('/')) }, p));
    });
  }

  function paintList(r) {
    listBox.replaceChildren();
    if (r.parent !== null) {
      listBox.append(h('div', { class: 'list-item clickable', onclick: () => load(r.parent) }, h('div', { class: 'avatar folder' }, icon('chevronLeft')), h('div', { class: 'grow title' }, '..')));
    }
    if (!r.entries.length) { listBox.append(Empty({ icon: 'folder', title: 'Walang laman', text: 'I-upload ang mga file gamit ang Upload button.' })); return; }
    for (const e of r.entries) {
      const isDir = e.type === 'dir';
      listBox.append(h('div', { class: 'list-item clickable', onclick: () => (isDir ? load(join(e.name)) : openFile(e)) },
        h('div', { class: `avatar${isDir ? ' folder' : ''}` }, icon(isDir ? 'folder' : 'file')),
        h('div', { class: 'grow' }, h('div', { class: 'title ellipsis' }, e.name), h('div', { class: 'meta' }, `${isDir ? 'Folder' : bytes(e.size)} · ${date(e.mtime)}`)),
        h('button', { class: 'btn icon sm ghost', 'aria-label': 'Mga option', onclick: (ev) => { ev.stopPropagation(); itemMenu(e); } }, icon('dots'))));
    }
  }

  function itemMenu(e) {
    const isDir = e.type === 'dir';
    openMenu(e.name, [
      !isDir && TEXT_EXT.test(e.name) ? { label: 'I-edit', icon: 'edit', onClick: () => editFile(e) } : null,
      !isDir ? { label: 'I-download', icon: 'download', onClick: () => download(e) } : null,
      { label: 'I-rename', icon: 'edit', onClick: () => renameItem(e) },
      { label: 'Burahin', icon: 'trash', danger: true, onClick: () => deleteItem(e) },
    ]);
  }

  function openFile(e) {
    if (TEXT_EXT.test(e.name) && e.size <= 1024 * 1024) editFile(e); else itemMenu(e);
  }

  function editFile(e) {
    const path = join(e.name);
    openSheet({
      title: e.name, full: true,
      content: (close) => {
        const ta = h('textarea', { class: 'input editor', spellcheck: 'false', autocapitalize: 'off', wrap: 'off' });
        const save = h('button', { class: 'btn primary', onclick: doSave }, icon('check', 18), 'I-save');
        async function doSave() {
          save.classList.add('loading');
          try { await api.put(`${base}/files/write`, { path, content: ta.value }); notify.ok('Na-save.'); close(); load(); } catch (er) { notify.error(er.message); } finally { save.classList.remove('loading'); }
        }
        ta.addEventListener('keydown', (ev) => { if ((ev.ctrlKey || ev.metaKey) && ev.key === 's') { ev.preventDefault(); doSave(); } });
        api.get(`${base}/files/read?path=${encodeURIComponent(path)}`).then((r) => { ta.value = r.content; }).catch((er) => { notify.error(er.message); close(); });
        return h('div', { style: { display: 'flex', flexDirection: 'column', flex: '1', minHeight: '0', gap: '10px' } }, ta, sheetActions(h('button', { class: 'btn', onclick: () => close() }, 'Cancel'), save));
      },
    });
  }

  async function download(e) {
    try {
      const r = await api.get(`${base}/files/link?path=${encodeURIComponent(join(e.name))}`);
      window.open(api.url(r.url), '_blank', 'noopener');
      notify.info('Sinisimulan ang download...');
    } catch (er) { notify.error(er.message); }
  }

  async function renameItem(e) {
    const name = await promptDialog({ title: 'I-rename', label: 'Bagong pangalan', value: e.name, confirmText: 'I-rename' });
    if (!name || name === e.name) return;
    try { await api.post(`${base}/files/rename`, { path: join(e.name), name }); notify.ok('Na-rename.'); load(); } catch (er) { notify.error(er.message); }
  }

  async function deleteItem(e) {
    const ok = await confirmDialog({ title: `Burahin ang ${e.type === 'dir' ? 'folder' : 'file'}?`, message: `"${e.name}" ay buburahin nang tuluyan.${e.type === 'dir' ? '\nKasama ang lahat ng laman nito.' : ''}`, danger: true, confirmText: 'Burahin' });
    if (!ok) return;
    try { await api.del(`${base}/files?path=${encodeURIComponent(join(e.name))}`); notify.ok('Nabura.'); load(); } catch (er) { notify.error(er.message); }
  }

  async function newFolder() {
    const name = await promptDialog({ title: 'Bagong folder', label: 'Pangalan', confirmText: 'Gumawa' });
    if (!name) return;
    try { await api.post(`${base}/files/mkdir`, { path: cwd, name }); load(); } catch (er) { notify.error(er.message); }
  }

  async function newFile() {
    const name = await promptDialog({ title: 'Bagong file', label: 'Pangalan (hal. hello.pwn)', confirmText: 'Gumawa' });
    if (!name) return;
    try { await api.put(`${base}/files/write`, { path: join(name), content: '' }); await load(); editFile({ name }); } catch (er) { notify.error(er.message); }
  }

  async function uploadFiles(files) {
    if (!files.length) return;
    progress.classList.remove('hidden');
    let done = 0;
    for (const f of files) {
      try {
        await api.upload(`${base}/files/upload?path=${encodeURIComponent(cwd)}&name=${encodeURIComponent(f.name)}`, f, (p) => {
          progress.firstChild.style.width = Math.round(((done + p) / files.length) * 100) + '%';
        });
        done++;
      } catch (er) { notify.error(`${f.name}: ${er.message}`); }
    }
    progress.classList.add('hidden');
    progress.firstChild.style.width = '0%';
    if (done) notify.ok(`Na-upload ang ${done} file.`);
    load();
  }

  root.replaceChildren(
    PageHead('Files', s.name),
    h('div', { class: 'row wrap', style: { marginBottom: '10px' } },
      h('button', { class: 'btn primary sm', onclick: () => picker.click() }, icon('upload', 16), 'Upload'),
      h('button', { class: 'btn sm', onclick: newFolder }, icon('folderPlus', 16), 'Folder'),
      h('button', { class: 'btn sm', onclick: newFile }, icon('filePlus', 16), 'File'),
      h('button', { class: 'btn sm icon', 'aria-label': 'I-refresh', onclick: () => load() }, icon('refresh', 16)), picker),
    progress, crumbs, listBox);
  await load();
  return () => {};
}
