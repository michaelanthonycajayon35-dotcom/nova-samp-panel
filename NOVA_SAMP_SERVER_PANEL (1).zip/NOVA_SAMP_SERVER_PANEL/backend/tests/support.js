'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Tulong para sa mga test: pansamantalang storage, tunay na HTTP server, at pekeng SA-MP UDP server.
const os = require('os');
const fs = require('fs');
const path = require('path');
const dgram = require('dgram');

async function boot() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-test-'));
  process.env.STORAGE_DIR = dir;
  process.env.ADMIN_PASSWORD = 'TestPass123';
  process.env.QUIET = 'true';
  const { buildServer } = require('../src/server');
  const server = buildServer();
  await new Promise((res) => server.listen(0, '127.0.0.1', res));
  const base = `http://127.0.0.1:${server.address().port}`;

  async function api(method, url, { token, body, raw, headers = {} } = {}) {
    const h = { ...headers };
    if (token) h.Authorization = `Bearer ${token}`;
    let payload;
    if (raw !== undefined) { payload = raw; h['Content-Type'] = 'application/octet-stream'; }
    else if (body !== undefined) { payload = JSON.stringify(body); h['Content-Type'] = 'application/json'; }
    const res = await fetch(base + url, { method, headers: h, body: payload });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* hindi json */ }
    return { status: res.status, json, text, headers: res.headers };
  }

  async function login(username = 'admin', password = 'TestPass123') {
    const r = await api('POST', '/api/auth/login', { body: { username, password } });
    return r.json && r.json.token;
  }

  async function close() {
    const ps = require('../src/services/process.service');
    await ps.stopAll();
    await new Promise((res) => server.close(res));
    fs.rmSync(dir, { recursive: true, force: true });
  }
  return { server, base, dir, api, login, close };
}

// Pekeng SA-MP server na sumasagot sa query (i, d) at RCON (x).
function mockSamp(rconPassword = 'secret') {
  const sock = dgram.createSocket('udp4');
  const received = [];
  const lstr = (s, lenBytes) => {
    const b = Buffer.from(s, 'latin1');
    const l = Buffer.alloc(lenBytes);
    if (lenBytes === 4) l.writeUInt32LE(b.length); else l.writeUInt8(b.length);
    return Buffer.concat([l, b]);
  };
  sock.on('message', (msg, rinfo) => {
    if (msg.length < 11 || msg.toString('ascii', 0, 4) !== 'SAMP') return;
    const head = msg.subarray(0, 11);
    const op = String.fromCharCode(msg[10]);
    let body = null;
    if (op === 'i') {
      const b = Buffer.alloc(5);
      b.writeUInt8(0, 0); b.writeUInt16LE(2, 1); b.writeUInt16LE(50, 3);
      body = Buffer.concat([b, lstr('Mock Server', 4), lstr('Grand Larceny', 4), lstr('English', 4)]);
    } else if (op === 'd') {
      const mk = (id, name, score, ping) => {
        const t = Buffer.alloc(8); t.writeInt32LE(score, 0); t.writeUInt32LE(ping, 4);
        return Buffer.concat([Buffer.from([id]), lstr(name, 1), t]);
      };
      const c = Buffer.alloc(2); c.writeUInt16LE(2);
      body = Buffer.concat([c, mk(0, 'Juan', 10, 45), mk(3, 'Maria', 5, 80)]);
    } else if (op === 'x') {
      const pwLen = msg.readUInt16LE(11);
      const pw = msg.toString('latin1', 13, 13 + pwLen);
      const cmdLen = msg.readUInt16LE(13 + pwLen);
      const cmd = msg.toString('latin1', 15 + pwLen, 15 + pwLen + cmdLen);
      received.push(cmd);
      const reply = (text) => {
        const t = lstr(text, 4);
        sock.send(Buffer.concat([head, t]), rinfo.port, rinfo.address);
      };
      if (pw !== rconPassword) reply('Invalid RCON password.');
      else if (cmd === 'echo hi') reply('hi');
      else if (cmd === 'cmdlist') { reply('Console Commands:'); reply('  kick, ban, say'); }
      else if (!cmd.startsWith('gmx')) reply(`ok: ${cmd}`);
      return;
    }
    if (body) sock.send(Buffer.concat([head, body]), rinfo.port, rinfo.address);
  });
  return new Promise((res) => sock.bind(0, '127.0.0.1', () => res({
    port: sock.address().port, received, close: () => new Promise((r) => sock.close(r)),
  })));
}

module.exports = { boot, mockSamp };
