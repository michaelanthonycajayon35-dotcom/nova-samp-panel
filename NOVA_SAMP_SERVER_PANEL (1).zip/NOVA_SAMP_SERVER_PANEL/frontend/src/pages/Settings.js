// NOVA SAMP SERVER PANEL - by CAJAYON | Settings
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api, getBase, setBase, isNative, normalizeUrl } from '../scripts/api.js';
import { session, hasRole, updateSession, logout } from '../scripts/auth.js';
import { navigate } from '../scripts/navigation.js';
import { notify } from '../scripts/notifications.js';
import { duration } from '../scripts/format.js';
import { PageHead } from '../components/Layout.js';
import { setPanelName } from '../App.js';

export async function mount(root) {
  const [{ settings }, info] = await Promise.all([api.get('/api/settings'), api.get('/api/system/info')]);
  const isAdmin = hasRole('admin');

  // --- Panel settings
  const f = {
    name: h('input', { class: 'input', value: settings.panelName, maxlength: '40', disabled: !isAdmin }),
    keep: h('input', { class: 'input', value: String(settings.backupRetention), inputmode: 'numeric', disabled: !isAdmin }),
    auto: h('select', { class: 'input', disabled: !isAdmin }, [[0, 'Patay'], [6, 'Kada 6 oras'], [12, 'Kada 12 oras'], [24, 'Araw-araw'], [72, 'Kada 3 araw'], [168, 'Lingguhan']].map(([v, l]) => h('option', { value: String(v), selected: Number(settings.autoBackupHours) === v }, l))),
  };
  const saveSettings = h('button', { class: 'btn primary', onclick: async () => {
    saveSettings.classList.add('loading');
    try {
      const r = await api.put('/api/settings', { panelName: f.name.value, backupRetention: Number(f.keep.value), autoBackupHours: Number(f.auto.value) });
      setPanelName(r.settings.panelName);
      notify.ok('Na-save ang settings.');
    } catch (e) { notify.error(e.message); } finally { saveSettings.classList.remove('loading'); }
  } }, 'I-save');

  // --- Password
  const cur = h('input', { class: 'input', type: 'password', autocomplete: 'current-password', placeholder: 'Kasalukuyang password' });
  const next = h('input', { class: 'input', type: 'password', autocomplete: 'new-password', placeholder: 'Bagong password (min. 8)' });
  const pwBtn = h('button', { class: 'btn', onclick: async () => {
    pwBtn.classList.add('loading');
    try {
      const r = await api.post('/api/auth/password', { current: cur.value, next: next.value });
      updateSession(r.token, r.user);
      cur.value = ''; next.value = '';
      notify.ok('Napalitan ang password. Na-logout ang ibang device.');
    } catch (e) { notify.error(e.message); } finally { pwBtn.classList.remove('loading'); }
  } }, icon('key', 18), 'Palitan ang password');

  // --- Connection (APK)
  const url = h('input', { class: 'input', value: getBase(), inputmode: 'url', autocapitalize: 'off', placeholder: 'http://123.45.67.89:3000' });
  const connect = isNative() ? [
    h('div', { class: 'section-title' }, h('h2', null, 'Koneksyon')),
    h('div', { class: 'card form-grid' },
      h('div', { class: 'field' }, h('label', null, 'Server URL ng panel'), url, h('div', { class: 'hint' }, 'Kapag pinalitan, kailangan mag-login ulit.')),
      h('button', { class: 'btn', onclick: () => {
        const v = normalizeUrl(url.value);
        if (!v) { notify.error('Maglagay ng valid na URL.'); return; }
        setBase(v); logout(); navigate('/login');
      } }, icon('globe', 18), 'I-save at mag-login ulit')),
  ] : [];

  const row = (k, v) => h('div', { class: 'row between', style: { padding: '8px 0', borderBottom: '1px solid var(--border)' } }, h('span', { class: 'muted' }, k), h('span', { class: 'mono' }, v));

  root.replaceChildren(
    PageHead('Settings', `Naka-login bilang ${session.user.username} (${session.user.role})`),
    h('div', { class: 'section-title' }, h('h2', null, 'Panel')),
    h('div', { class: 'card form-grid' },
      h('div', { class: 'field' }, h('label', null, 'Pangalan ng panel'), f.name),
      h('div', { class: 'form-grid two' },
        h('div', { class: 'field' }, h('label', null, 'Ilang backup ang itatabi'), f.keep),
        h('div', { class: 'field' }, h('label', null, 'Auto-backup'), f.auto)),
      isAdmin ? saveSettings : h('div', { class: 'hint' }, 'Admin lang ang pwedeng magbago nito.')),
    h('div', { class: 'section-title' }, h('h2', null, 'Account')),
    h('div', { class: 'card form-grid' }, h('div', { class: 'field' }, h('label', null, 'Palitan ang password'), cur, next), pwBtn),
    ...connect,
    h('div', { class: 'section-title' }, h('h2', null, 'Tungkol')),
    h('div', { class: 'card' }, row('Panel', `NOVA SAMP Panel v${info.version}`), row('Gawa ni', info.author), row('Node.js', info.node), row('Platform', info.platform), row('Uptime ng panel', duration(info.uptimeSec))),
    h('div', { style: { marginTop: '16px' } }, h('button', { class: 'btn danger block', onclick: () => { logout(); navigate('/login'); } }, icon('logout', 18), 'Mag-logout')));
  return () => {};
}
