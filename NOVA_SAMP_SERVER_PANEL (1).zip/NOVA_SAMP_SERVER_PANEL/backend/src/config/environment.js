'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Nagbabasa ng .env (walang dependency) at nagbibigay ng config ng panel.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..', '..', '..');

function loadEnvFile(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch { return; }
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = val;
  }
}

loadEnvFile(path.join(ROOT, '.env'));

const env = process.env;
const num = (v, d) => { const n = Number(v); return Number.isFinite(n) && v !== undefined && v !== '' ? n : d; };

const STORAGE_DIR = path.resolve(ROOT, env.STORAGE_DIR || 'storage');
for (const sub of ['database', 'backups', 'logs', 'servers', 'uploads']) {
  fs.mkdirSync(path.join(STORAGE_DIR, sub), { recursive: true });
}

// Ang JWT secret ay nase-save para hindi mag-logout ang lahat tuwing restart.
function resolveJwtSecret() {
  if (env.JWT_SECRET && env.JWT_SECRET.length >= 16) return env.JWT_SECRET;
  const file = path.join(STORAGE_DIR, 'database', 'jwt.secret');
  try {
    const existing = fs.readFileSync(file, 'utf8').trim();
    if (existing.length >= 32) return existing;
  } catch { /* wala pa, gagawa tayo */ }
  const secret = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(file, secret, { mode: 0o600 });
  return secret;
}

module.exports = {
  ROOT,
  VERSION: '1.0.0',
  PORT: num(env.PORT, 3000),
  HOST: env.HOST || '0.0.0.0',
  STORAGE_DIR,
  SERVERS_DIR: path.join(STORAGE_DIR, 'servers'),
  BACKUPS_DIR: path.join(STORAGE_DIR, 'backups'),
  DB_FILE: path.join(STORAGE_DIR, 'database', 'nova.json'),
  LOG_DIR: path.join(STORAGE_DIR, 'logs'),
  FRONTEND_DIR: path.join(ROOT, 'frontend'),
  TEMPLATES_DIR: path.join(ROOT, 'server_templates'),
  JWT_SECRET: resolveJwtSecret(),
  JWT_EXPIRES_HOURS: num(env.JWT_EXPIRES_HOURS, 12),
  CORS_ORIGINS: (env.CORS_ORIGINS || '*').split(',').map((s) => s.trim()).filter(Boolean),
  ADMIN_USER: env.ADMIN_USER || 'admin',
  ADMIN_PASSWORD: env.ADMIN_PASSWORD || '',
  MAX_UPLOAD_MB: num(env.MAX_UPLOAD_MB, 50),
  MAX_IMPORT_MB: num(env.MAX_IMPORT_MB, 500),
  TRUST_PROXY: String(env.TRUST_PROXY || '').toLowerCase() === 'true',
  QUIET: String(env.QUIET || '').toLowerCase() === 'true',
};
