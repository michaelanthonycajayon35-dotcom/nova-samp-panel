# Backup

- Backup = naka-compress na `tar.gz` ng **buong folder ng server**, nasa `storage/backups/<server-id>/`.
- **Manual:** Backups → **Backup**. **Awtomatiko:** Settings → Auto-backup.
- **Retention:** Settings → "Ilang backup ang itatabi" (default 10; pinakaluma ang buburahin).
- **Restore:** admin lang; kailangang **patay** ang server. Gagawa muna ng `pre-restore_...` backup para may balikan ka.
- **Download:** admin lang; nagbubukas ng browser para i-download (maikling-buhay na link).

## I-backup ang mismong panel
Kopyahin ang `storage/` (database, servers, backups) at `.env`.
