'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const db = require('../config/database');
const { JWT_SECRET } = require('../config/environment');
const { verifyToken } = require('../utils/security');
const { HttpError } = require('../utils/helpers');

function authenticate(ctx) {
  const header = ctx.req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const payload = verifyToken(token, JWT_SECRET);
  if (!payload || payload.purpose) throw new HttpError(401, 'Mag-login muna.');
  const user = db.users.find((u) => u.id === payload.sub);
  if (!user || user.disabled || (user.tokenVersion || 0) !== payload.tv) {
    throw new HttpError(401, 'Expired na ang session. Mag-login ulit.');
  }
  ctx.user = user;
}

module.exports = { authenticate };
