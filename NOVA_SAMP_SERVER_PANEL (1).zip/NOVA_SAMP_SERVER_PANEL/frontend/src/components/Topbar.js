// NOVA SAMP SERVER PANEL - by CAJAYON | Topbar (logo + piliin ang server)
import { h, clear } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { state, setCurrent, current, onState } from '../scripts/state.js';
import { hasRole } from '../scripts/auth.js';
import { navigate } from '../scripts/navigation.js';
import { openSheet } from './Modal.js';
import { serverStatus } from './ServerCard.js';

export function Topbar(panelName) {
  const label = h('span', { class: 'ellipsis' });
  const dot = h('i', { class: 'dot' });
  const pick = h('button', { class: 'server-pick', 'aria-label': 'Pumili ng server', onclick: openPicker }, dot, label, icon('chevronDown', 16));
  const nameEl = h('span', null, panelName);
  const el = h('header', { class: 'topbar' },
    h('div', { class: 'brand' }, h('img', { src: 'public/assets/logo-icon.png', alt: '' }), nameEl), pick);

  function paint() {
    const s = current();
    label.textContent = s ? s.name : 'Walang server';
    dot.className = `dot ${s ? serverStatus(s).tone : ''}`;
  }
  function openPicker() {
    openSheet({
      title: 'Piliin ang server',
      content: (close) => {
        const box = h('div', null);
        if (!state.servers.length) box.append(h('p', { class: 'muted' }, 'Wala ka pang server.'));
        for (const s of state.servers) {
          box.append(h('button', { class: 'menu-item', onclick: () => { setCurrent(s.id); close(); } },
            h('i', { class: `dot ${serverStatus(s).tone}` }), h('span', { class: 'grow ellipsis' }, s.name),
            s.id === state.currentId ? icon('check') : null));
        }
        if (hasRole('admin')) box.append(h('button', { class: 'menu-item', onclick: () => { close(); navigate('/servers?new=1'); } }, icon('plus'), h('span', null, 'Magdagdag ng server')));
        return box;
      },
    });
  }
  paint();
  const off = onState(paint);
  el.destroy = off;
  el.setName = (n) => { clear(nameEl); nameEl.append(n); };
  return el;
}
