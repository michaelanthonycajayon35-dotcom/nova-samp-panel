'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const serverService = require('../services/server.service');
const rconService = require('../services/rcon.service');
const v = require('../utils/validation');
const db = require('../config/database');
const { HttpError } = require('../utils/helpers');

async function send(ctx) {
  const s = serverService.get(ctx.params.id);
  const command = v.oneLine(ctx.body.command, 'command', 200);
  let lines;
  try {
    lines = await rconService.rcon(s, command);
  } catch (e) {
    if (e instanceof HttpError) throw e;
    throw new HttpError(502, `Hindi maabot ang server (${s.host}:${s.port}): ${e.message}`);
  }
  db.audit(ctx.user.username, 'rcon', `${s.name}: ${command}`);
  return { lines };
}

module.exports = { send };
