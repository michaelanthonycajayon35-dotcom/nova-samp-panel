'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// SA-MP / open.mp UDP query + RCON protocol (walang dependency).
const dgram = require('dgram');
const dns = require('dns').promises;
const net = require('net');
const { HttpError } = require('../utils/helpers');

async function resolveIp(host) {
  if (net.isIPv4(host)) return host;
  const r = await dns.lookup(host, { family: 4 });
  return r.address;
}

function buildPacket(ip, port, opcode, payload) {
  const head = Buffer.alloc(11);
  head.write('SAMP', 0, 'ascii');
  ip.split('.').forEach((o, i) => { head[4 + i] = Number(o); });
  head.writeUInt16LE(port, 8);
  head[10] = opcode.charCodeAt(0);
  return payload ? Buffer.concat([head, payload]) : head;
}

// Magpadala ng packet at kolektahin ang sagot.
async function exchange({ host, port, opcode, payload, collect = false, timeout = 1200, idle = 500 }) {
  const ip = await resolveIp(host);
  const packet = buildPacket(ip, port, opcode, payload);
  const op = opcode.charCodeAt(0);
  return new Promise((resolve, reject) => {
    const sock = dgram.createSocket('udp4');
    const results = [];
    let done = false;
    let idleTimer = null;
    const finish = (err) => {
      if (done) return;
      done = true;
      clearTimeout(hardTimer);
      clearTimeout(idleTimer);
      try { sock.close(); } catch { /* ignore */ }
      if (err) return reject(err);
      if (!collect && results.length === 0) return reject(new Error('timeout'));
      resolve(results);
    };
    const hardTimer = setTimeout(() => finish(), timeout);
    sock.on('error', finish);
    sock.on('message', (msg) => {
      if (msg.length < 11 || msg.toString('ascii', 0, 4) !== 'SAMP' || msg[10] !== op) return;
      results.push(msg.subarray(11));
      if (!collect) return finish();
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => finish(), idle);
    });
    sock.send(packet, port, ip, (err) => { if (err) finish(err); });
  });
}

async function withRetry(fn, attempts = 2) {
  let last;
  for (let i = 0; i < attempts; i++) {
    try { return await fn(); } catch (e) { last = e; }
  }
  throw last;
}

function readStr(buf, offset, lenBytes) {
  const len = lenBytes === 4 ? buf.readUInt32LE(offset) : buf.readUInt8(offset);
  const start = offset + lenBytes;
  if (len > 512 || start + len > buf.length) throw new Error('bad packet');
  return { value: buf.toString('latin1', start, start + len), next: start + len };
}

function parseInfo(buf) {
  const passworded = buf.readUInt8(0) === 1;
  const players = buf.readUInt16LE(1);
  const maxPlayers = buf.readUInt16LE(3);
  const host = readStr(buf, 5, 4);
  const mode = readStr(buf, host.next, 4);
  const lang = readStr(buf, mode.next, 4);
  return { passworded, players, maxPlayers, hostname: host.value, gamemode: mode.value, language: lang.value };
}

function parseDetailed(buf) {
  const count = buf.readUInt16LE(0);
  const out = [];
  let o = 2;
  for (let i = 0; i < count && o < buf.length; i++) {
    const id = buf.readUInt8(o);
    const name = readStr(buf, o + 1, 1);
    const score = buf.readInt32LE(name.next);
    const ping = buf.readUInt32LE(name.next + 4);
    out.push({ id, name: name.value, score, ping });
    o = name.next + 8;
  }
  return out;
}

function parseBasic(buf) {
  const count = buf.readUInt16LE(0);
  const out = [];
  let o = 2;
  for (let i = 0; i < count && o < buf.length; i++) {
    const name = readStr(buf, o, 1);
    const score = buf.readInt32LE(name.next);
    out.push({ id: null, name: name.value, score, ping: null });
    o = name.next + 4;
  }
  return out;
}

const infoCache = new Map();
async function queryInfo(server) {
  const key = `${server.host}:${server.port}`;
  const hit = infoCache.get(key);
  if (hit && Date.now() - hit.t < 3000) return hit.value;
  let value;
  try {
    const t0 = Date.now();
    const [buf] = await withRetry(() => exchange({ host: server.host, port: server.port, opcode: 'i', timeout: 1000 }));
    value = { online: true, ping: Date.now() - t0, ...parseInfo(buf) };
  } catch {
    value = { online: false, ping: null, players: 0, maxPlayers: 0, hostname: '', gamemode: '', language: '', passworded: false };
  }
  infoCache.set(key, { t: Date.now(), value });
  return value;
}

async function queryPlayers(server) {
  try {
    const [buf] = await withRetry(() => exchange({ host: server.host, port: server.port, opcode: 'd', timeout: 1000 }));
    return { ok: true, players: parseDetailed(buf) };
  } catch { /* subukan ang basic */ }
  try {
    const [buf] = await withRetry(() => exchange({ host: server.host, port: server.port, opcode: 'c', timeout: 1000 }));
    return { ok: true, players: parseBasic(buf) };
  } catch {
    return { ok: false, players: [] };
  }
}

async function rcon(server, command) {
  if (!server.rconPassword) throw new HttpError(400, 'Walang RCON password ang server na ito. I-set ito sa Server Details.');
  const pw = Buffer.from(server.rconPassword, 'latin1');
  const cmd = Buffer.from(command, 'latin1');
  const payload = Buffer.alloc(2 + pw.length + 2 + cmd.length);
  payload.writeUInt16LE(pw.length, 0);
  pw.copy(payload, 2);
  payload.writeUInt16LE(cmd.length, 2 + pw.length);
  cmd.copy(payload, 4 + pw.length);
  const packets = await exchange({ host: server.host, port: server.port, opcode: 'x', payload, collect: true, timeout: 3500, idle: 600 });
  const lines = [];
  for (const p of packets) {
    try {
      const len = p.readUInt32LE(0);
      lines.push(p.toString('latin1', 4, 4 + len));
    } catch { /* skip bad packet */ }
  }
  return lines;
}

module.exports = { queryInfo, queryPlayers, rcon, parseInfo, parseDetailed, buildPacket };
