'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const serverService = require('../services/server.service');
const backupService = require('../services/backup.service');
const { makeLink } = require('./files.controller');
const db = require('../config/database');

const srv = (ctx) => serverService.get(ctx.params.id);

const list = (ctx) => ({ backups: backupService.list(srv(ctx).id) });

async function create(ctx) {
  const s = srv(ctx);
  const backup = await backupService.create(s);
  db.audit(ctx.user.username, 'backup-create', `${s.name}: ${backup.name}`);
  return { backup };
}

function link(ctx) {
  const s = srv(ctx);
  backupService.resolveBackup(s.id, ctx.params.name);
  return makeLink({ kind: 'backup', sid: s.id, p: ctx.params.name });
}

async function restore(ctx) {
  const s = srv(ctx);
  const r = await backupService.restore(s, ctx.params.name);
  db.audit(ctx.user.username, 'backup-restore', `${s.name}: ${ctx.params.name}`);
  return r;
}

function remove(ctx) {
  const s = srv(ctx);
  const r = backupService.remove(s.id, ctx.params.name);
  db.audit(ctx.user.username, 'backup-delete', `${s.name}: ${ctx.params.name}`);
  return r;
}

module.exports = { list, create, link, restore, remove };
