'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const serverService = require('../services/server.service');
const consoleService = require('../services/console.service');
const processService = require('../services/process.service');
const v = require('../utils/validation');
const db = require('../config/database');

function read(ctx) {
  const s = serverService.get(ctx.params.id);
  const since = Number(ctx.query.since) || 0;
  return { ...consoleService.read(s.id, since), running: processService.isRunning(s.id) };
}

const log = (ctx) => consoleService.tailLog(serverService.get(ctx.params.id), Math.min(Number(ctx.query.lines) || 200, 500));

function command(ctx) {
  const s = serverService.get(ctx.params.id);
  const cmd = v.oneLine(ctx.body.command, 'command', 300);
  processService.sendInput(s.id, cmd);
  db.audit(ctx.user.username, 'console-command', `${s.name}: ${cmd}`);
  return { ok: true };
}

function clear(ctx) {
  consoleService.clear(serverService.get(ctx.params.id).id);
  return { ok: true };
}

module.exports = { read, log, command, clear };
