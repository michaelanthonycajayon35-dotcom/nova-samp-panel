// NOVA SAMP SERVER PANEL - by CAJAYON | Dashboard
import { h, clear, poll } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api } from '../scripts/api.js';
import { session, hasRole } from '../scripts/auth.js';
import { navigate } from '../scripts/navigation.js';
import { bytes, duration, ago } from '../scripts/format.js';
import { setCurrent } from '../scripts/state.js';
import { PageHead, Empty } from '../components/Layout.js';
import { StatCard } from '../components/StatCard.js';
import { ServerCard } from '../components/ServerCard.js';
import { Skeleton } from '../components/Loading.js';

const NS = 'http://www.w3.org/2000/svg';

function sparkline(history) {
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', '0 0 300 86');
  svg.setAttribute('preserveAspectRatio', 'none');
  svg.setAttribute('class', 'spark');
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', 'CPU at RAM usage');
  const pts = (key) => {
    const n = history.length;
    return history.map((p, i) => `${n === 1 ? 300 : (i / (n - 1)) * 300},${82 - (p[key] / 100) * 78}`);
  };
  const line = (key, color) => {
    if (!history.length) return '';
    const p = pts(key);
    const area = key === 'cpu' ? `<polygon points="0,86 ${p.join(' ')} 300,86" fill="${color}" opacity="0.14"/>` : '';
    return `${area}<polyline points="${p.join(' ')}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>`;
  };
  svg.innerHTML = '<line x1="0" y1="43" x2="300" y2="43" stroke="rgba(255,255,255,0.07)" stroke-dasharray="3 4"/>' + line('mem', '#8b5cf6') + line('cpu', '#22d3ee');
  return svg;
}

export async function mount(root) {
  const stats = h('div', { class: 'stat-grid' }, Skeleton(0));
  const chart = h('div', { class: 'card' });
  const serversBox = h('div', { class: 'server-grid' });
  const activityBox = h('div', { class: 'card flat' });
  const activityTitle = h('div', { class: 'section-title' }, h('h2', null, 'Huling aktibidad'));
  activityTitle.classList.add('hidden');
  activityBox.classList.add('hidden');
  const hello = `Kumusta, ${session.user.username}`;
  root.replaceChildren(
    PageHead('Dashboard', hello, h('button', { class: 'btn icon ghost', 'aria-label': 'I-refresh', onclick: () => refresh() }, icon('refresh'))),
    stats, h('div', { class: 'section-title' }, h('h2', null, 'Gamit ng makina')), chart,
    h('div', { class: 'section-title' }, h('h2', null, 'Mga server'), hasRole('admin') ? h('button', { class: 'btn sm', onclick: () => navigate('/servers?new=1') }, icon('plus', 16), 'Bago') : null),
    serversBox, activityTitle, activityBox);
  serversBox.append(Skeleton(2, 150));

  let first = true;
  async function refresh() {
    let d;
    try { d = await api.get('/api/dashboard'); } catch (e) {
      if (first) throw e;
      return;
    }
    first = false;
    const { system: sys, totals, servers, activity } = d;
    clear(stats);
    stats.append(
      StatCard({ icon: 'server', label: 'Servers', value: `${totals.online}/${totals.servers}`, sub: 'online ngayon' }),
      StatCard({ icon: 'users', label: 'Players', value: totals.players, unit: `/ ${totals.maxPlayers}`, sub: 'naglalaro' }),
      StatCard({ icon: 'cpu', label: 'CPU', value: sys.cpuPercent, unit: '%', sub: `${sys.cpuCores} cores · load ${sys.load[0]}`, percent: sys.cpuPercent }),
      StatCard({ icon: 'activity', label: 'RAM', value: sys.memory.percent, unit: '%', sub: `${bytes(sys.memory.used)} / ${bytes(sys.memory.total)}`, percent: sys.memory.percent }),
      sys.disk ? StatCard({ icon: 'disk', label: 'Disk', value: sys.disk.percent, unit: '%', sub: `${bytes(sys.disk.used)} / ${bytes(sys.disk.total)}`, percent: sys.disk.percent })
        : StatCard({ icon: 'disk', label: 'Disk', value: '-', sub: 'hindi mabasa' }),
      StatCard({ icon: 'clock', label: 'Uptime', value: duration(sys.uptimeSec), sub: sys.hostname }));
    clear(chart);
    chart.append(h('div', { class: 'row between', style: { marginBottom: '8px' } }, h('strong', null, 'CPU at RAM'),
      h('div', { class: 'legend' }, h('span', null, h('i', { style: { background: '#22d3ee' } }), 'CPU'), h('span', null, h('i', { style: { background: '#8b5cf6' } }), 'RAM'))),
    sys.history.length > 1 ? sparkline(sys.history) : h('div', { class: 'muted', style: { height: '86px', display: 'grid', placeItems: 'center', fontSize: '0.85rem' } }, 'Kumukuha ng data...'),
      h('div', { class: 'muted', style: { fontSize: '0.74rem', marginTop: '4px' } }, `${sys.platform}`));
    clear(serversBox);
    if (!servers.length) {
      serversBox.append(Empty({ icon: 'server', title: 'Wala pang server', text: 'Magdagdag ng unang SA-MP o open.mp server.',
        action: hasRole('admin') ? h('div', { class: 'row', style: { justifyContent: 'center' } }, h('button', { class: 'btn primary', onclick: () => navigate('/servers?import=1') }, icon('upload', 18), 'I-import'), h('button', { class: 'btn', onclick: () => navigate('/servers?new=1') }, icon('plus', 18), 'Bago')) : null }));
    }
    for (const s of servers) serversBox.append(ServerCard(s, { onOpen: () => { setCurrent(s.id); navigate(`/servers/${s.id}`); } }));
    const showAct = activity && activity.length > 0;
    activityTitle.classList.toggle('hidden', !showAct);
    activityBox.classList.toggle('hidden', !showAct);
    clear(activityBox);
    for (const a of activity || []) {
      activityBox.append(h('div', { class: 'list-item activity' },
        h('div', { class: 'avatar', style: { width: '32px', height: '32px', fontSize: '0.8rem' } }, a.user.slice(0, 1).toUpperCase()),
        h('div', { class: 'grow' }, h('div', { class: 'ellipsis' }, h('b', null, a.user), ' · ', a.action), a.detail ? h('div', { class: 'meta ellipsis' }, a.detail) : null),
        h('div', { class: 'when' }, ago(a.t))));
    }
  }

  await refresh();
  return poll(refresh, 5000);
}
