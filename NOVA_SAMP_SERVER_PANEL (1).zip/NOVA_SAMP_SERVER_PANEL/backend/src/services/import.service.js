'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Import ng server: i-upload ang .zip/.tar.gz, i-extract, tapos i-detect ang uri, executable, port at RCON.
const fs = require('fs');
const path = require('path');
const { SERVERS_DIR, STORAGE_DIR, MAX_IMPORT_MB } = require('../config/environment');
const { HttpError, newId, slug } = require('../utils/helpers');
const { extract, flatten } = require('../utils/archive');
const serverService = require('./server.service');

const ALLOWED = /\.(zip|tar\.gz|tgz|tar)$/i;

function saveUpload(req, dest, maxBytes) {
  return new Promise((resolve, reject) => {
    const out = fs.createWriteStream(dest);
    let size = 0;
    let failed = false;
    const fail = (err) => {
      if (failed) return;
      failed = true;
      out.destroy();
      req.unpipe(out);
      req.resume();
      fs.rm(dest, { force: true }, () => reject(err));
    };
    req.on('data', (c) => { size += c.length; if (size > maxBytes) fail(new HttpError(413, `Masyadong malaki ang archive (max ${Math.round(maxBytes / 1048576)} MB).`)); });
    req.on('error', fail);
    out.on('error', fail);
    out.on('finish', () => { if (!failed) resolve(size); });
    req.pipe(out);
  });
}

async function importArchive({ req, filename, name, type, host, port }) {
  if (!ALLOWED.test(filename)) throw new HttpError(400, 'Suportado lang ang .zip, .tar.gz, .tgz at .tar.');
  const maxBytes = MAX_IMPORT_MB * 1024 * 1024;
  const id = newId();
  const tmp = path.join(STORAGE_DIR, 'uploads', `${id}-import${path.extname(filename) || '.bin'}`);
  const dir = path.join(SERVERS_DIR, `${id}-${slug(name)}`);
  try {
    await saveUpload(req, tmp, maxBytes);
    await extract(tmp, filename, dir, maxBytes * 4);
    flatten(dir);
    return serverService.registerImported({ id, name, type, host, port }, dir);
  } catch (e) {
    fs.rmSync(dir, { recursive: true, force: true });
    throw e;
  } finally {
    fs.rmSync(tmp, { force: true });
  }
}

module.exports = { importArchive };
