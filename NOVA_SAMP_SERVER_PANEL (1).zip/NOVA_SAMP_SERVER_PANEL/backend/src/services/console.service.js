'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Ring buffer ng output ng server para sa live console.
const fs = require('fs');
const path = require('path');

const MAX_LINES = 1000;
const buffers = new Map();
// eslint-disable-next-line no-control-regex
const ANSI = /\x1b\[[0-9;?]*[ -/]*[@-~]/g;

function buf(id) {
  let b = buffers.get(id);
  if (!b) { b = { seq: 0, lines: [] }; buffers.set(id, b); }
  return b;
}

function append(id, text) {
  const b = buf(id);
  for (const raw of String(text).split(/\r?\n/)) {
    const line = raw.replace(ANSI, '').replace(/[\0-\x08\x0b\x0c\x0e-\x1f]/g, '');
    if (line === '') continue;
    b.lines.push({ n: ++b.seq, t: Date.now(), text: line.slice(0, 2000) });
  }
  if (b.lines.length > MAX_LINES) b.lines.splice(0, b.lines.length - MAX_LINES);
}

function read(id, since = 0, limit = 300) {
  const b = buf(id);
  const lines = b.lines.filter((l) => l.n > since);
  return { lines: lines.slice(-limit), last: b.seq };
}

function clear(id) { buf(id).lines = []; }
function drop(id) { buffers.delete(id); }

// Basahin ang dulo ng server_log.txt (o log.txt sa open.mp)
function tailLog(server, maxLines = 200) {
  for (const name of ['server_log.txt', 'log.txt']) {
    const file = path.join(server.path, name);
    try {
      const st = fs.statSync(file);
      if (!st.isFile()) continue;
      const size = Math.min(st.size, 128 * 1024);
      const fd = fs.openSync(file, 'r');
      const b = Buffer.alloc(size);
      fs.readSync(fd, b, 0, size, st.size - size);
      fs.closeSync(fd);
      const lines = b.toString('latin1').split(/\r?\n/).filter(Boolean).slice(-maxLines);
      return { file: name, lines };
    } catch { /* subukan ang susunod */ }
  }
  return { file: null, lines: [] };
}

module.exports = { append, read, clear, drop, tailLog };
