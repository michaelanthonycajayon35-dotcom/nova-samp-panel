'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Pang-extract ng .zip (pure Node, walang unzip na kailangan) at .tar.gz (gamit ang tar).
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { spawn } = require('child_process');
const { safeJoin } = require('./security');
const { HttpError } = require('./helpers');

const MAX_ENTRIES = 50_000;

function readAt(fd, length, position) {
  const buf = Buffer.alloc(length);
  let off = 0;
  while (off < length) {
    const n = fs.readSync(fd, buf, off, length - off, position + off);
    if (n === 0) break;
    off += n;
  }
  return off === length ? buf : buf.subarray(0, off);
}

function listZip(fd, size) {
  const tailLen = Math.min(size, 65557);
  const tail = readAt(fd, tailLen, size - tailLen);
  let eocd = -1;
  for (let i = tail.length - 22; i >= 0; i--) {
    if (tail.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new HttpError(400, 'Sira o hindi valid na .zip ang file.');
  const total = tail.readUInt16LE(eocd + 10);
  const cdSize = tail.readUInt32LE(eocd + 12);
  const cdOffset = tail.readUInt32LE(eocd + 16);
  if (total === 0xffff || cdSize === 0xffffffff || cdOffset === 0xffffffff) throw new HttpError(400, 'Hindi suportado ang ZIP64 (sobrang laking zip). Gumamit ng .tar.gz.');
  if (total > MAX_ENTRIES) throw new HttpError(400, 'Masyadong maraming file sa zip.');
  const cd = readAt(fd, cdSize, cdOffset);
  const entries = [];
  let o = 0;
  for (let i = 0; i < total; i++) {
    if (o + 46 > cd.length || cd.readUInt32LE(o) !== 0x02014b50) throw new HttpError(400, 'Sira ang listahan ng file sa zip.');
    const flags = cd.readUInt16LE(o + 8);
    const method = cd.readUInt16LE(o + 10);
    const csize = cd.readUInt32LE(o + 20);
    const usize = cd.readUInt32LE(o + 24);
    const nlen = cd.readUInt16LE(o + 28);
    const elen = cd.readUInt16LE(o + 30);
    const clen = cd.readUInt16LE(o + 32);
    const ext = cd.readUInt32LE(o + 38);
    const lho = cd.readUInt32LE(o + 42);
    const name = cd.toString('utf8', o + 46, o + 46 + nlen);
    entries.push({ name, method, csize, usize, mode: (ext >>> 16) & 0o7777, unixType: (ext >>> 16) & 0o170000, encrypted: Boolean(flags & 1), lho });
    o += 46 + nlen + elen + clen;
  }
  return entries;
}

function extractZip(file, dest, maxBytes) {
  const fd = fs.openSync(file, 'r');
  try {
    const size = fs.fstatSync(fd).size;
    const entries = listZip(fd, size);
    const declared = entries.reduce((n, e) => n + e.usize, 0);
    if (declared > maxBytes) throw new HttpError(413, `Masyadong malaki kapag na-extract (max ${Math.round(maxBytes / 1048576)} MB).`);
    let count = 0;
    for (const e of entries) {
      if (e.name.startsWith('__MACOSX/') || e.name.endsWith('.DS_Store')) continue;
      if (e.encrypted) throw new HttpError(400, 'May password ang zip. Tanggalin ang password at subukan ulit.');
      if (e.unixType === 0o120000) continue; // symlink: laktawan
      const target = safeJoin(dest, e.name); // zip-slip protection
      if (e.name.endsWith('/') || e.name.endsWith('\\')) { fs.mkdirSync(target, { recursive: true }); continue; }
      const lh = readAt(fd, 30, e.lho);
      if (lh.length < 30 || lh.readUInt32LE(0) !== 0x04034b50) throw new HttpError(400, 'Sira ang zip (local header).');
      const dataStart = e.lho + 30 + lh.readUInt16LE(26) + lh.readUInt16LE(28);
      const raw = readAt(fd, e.csize, dataStart);
      let out;
      if (e.method === 0) out = raw;
      else if (e.method === 8) out = zlib.inflateRawSync(raw, { maxOutputLength: Math.max(e.usize, 1) }); // hindi pwedeng lumampas sa idineklarang laki (zip bomb)
      else throw new HttpError(400, `Hindi suportado ang compression method ${e.method} sa "${e.name}".`);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, out, { mode: e.mode ? (e.mode & 0o777) | 0o600 : 0o644 });
      count++;
    }
    if (!count) throw new HttpError(400, 'Walang laman ang zip.');
    return count;
  } catch (e) {
    if (e instanceof HttpError) throw e;
    throw new HttpError(400, `Hindi ma-extract ang zip: ${e.message}`);
  } finally {
    fs.closeSync(fd);
  }
}

function runTar(args) {
  return new Promise((resolve, reject) => {
    const p = spawn('tar', args, { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    p.stderr.on('data', (d) => { err += d.toString(); });
    p.on('error', (e) => reject(new HttpError(500, `Hindi mapatakbo ang tar: ${e.message}`)));
    p.on('close', (code) => (code === 0 ? resolve() : reject(new HttpError(400, `Hindi ma-extract ang archive: ${err.trim().slice(0, 200)}`))));
  });
}

// Tanggalin ang symlink na tumuturo sa labas ng folder
function stripUnsafeLinks(dir, root = dir) {
  for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, d.name);
    if (d.isSymbolicLink()) {
      let ok = false;
      try { const real = fs.realpathSync(p); ok = real === root || real.startsWith(root + path.sep); } catch { /* sira ang link */ }
      if (!ok) fs.rmSync(p, { force: true });
    } else if (d.isDirectory()) stripUnsafeLinks(p, root);
  }
}

async function extract(file, originalName, dest, maxBytes) {
  const lower = String(originalName).toLowerCase();
  fs.mkdirSync(dest, { recursive: true });
  if (lower.endsWith('.zip')) return extractZip(file, dest, maxBytes);
  if (lower.endsWith('.tar.gz') || lower.endsWith('.tgz')) await runTar(['-xzf', file, '-C', dest, '--no-same-owner']);
  else if (lower.endsWith('.tar')) await runTar(['-xf', file, '-C', dest, '--no-same-owner']);
  else throw new HttpError(400, 'Suportado lang ang .zip, .tar.gz, .tgz at .tar.');
  stripUnsafeLinks(fs.realpathSync(dest));
  return 1;
}

// Kapag iisang folder lang ang laman ng archive (hal. "myserver/..."), iangat ang laman.
function flatten(dest) {
  const items = fs.readdirSync(dest).filter((n) => n !== '__MACOSX');
  if (items.length === 1 && fs.statSync(path.join(dest, items[0])).isDirectory()) {
    const tmp = path.join(dest, '.__nova_inner');
    fs.renameSync(path.join(dest, items[0]), tmp);
    for (const n of fs.readdirSync(tmp)) fs.renameSync(path.join(tmp, n), path.join(dest, n));
    fs.rmdirSync(tmp);
  }
  fs.rmSync(path.join(dest, '__MACOSX'), { recursive: true, force: true });
}

module.exports = { extract, flatten };
