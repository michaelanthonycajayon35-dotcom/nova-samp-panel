// NOVA SAMP SERVER PANEL - by CAJAYON | API client
const URL_KEY = 'nova_api_url';
const TOKEN_KEY = 'nova_token';
const TIMEOUT_MS = 20000;

const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { if (v) localStorage.setItem(k, v); else localStorage.removeItem(k); } catch { /* ok */ } },
};

export class ApiError extends Error {
  constructor(message, status, network = false) { super(message); this.status = status; this.network = network; }
}

export const isNative = () => Boolean(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform()) || location.protocol === 'file:';

export function normalizeUrl(input) {
  let u = String(input || '').trim();
  if (!u) return '';
  if (!/^https?:\/\//i.test(u)) u = 'http://' + u;
  return u.replace(/\/+$/, '').replace(/\/api$/i, '');
}

export const getBase = () => store.get(URL_KEY) || (isNative() ? '' : location.origin);
export const setBase = (url) => store.set(URL_KEY, normalizeUrl(url));
export const needsServerUrl = () => !getBase();
export const getToken = () => store.get(TOKEN_KEY);
export const setToken = (t) => store.set(TOKEN_KEY, t);

let onUnauthorized = () => {};
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn; };

async function request(method, path, { body, raw, base, auth = true, timeout = TIMEOUT_MS } = {}) {
  const root = base !== undefined ? base : getBase();
  if (!root) throw new ApiError('Ilagay muna ang Server URL ng panel mo.', 0, true);
  const headers = {};
  const token = getToken();
  if (auth && token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (raw !== undefined) { payload = raw; headers['Content-Type'] = 'application/octet-stream'; }
  else if (body !== undefined) { payload = JSON.stringify(body); headers['Content-Type'] = 'application/json'; }
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeout);
  let res;
  try {
    res = await fetch(root + path, { method, headers, body: payload, signal: ctl.signal });
  } catch (e) {
    throw new ApiError(e.name === 'AbortError' ? 'Natagalan ang sagot ng panel server.' : 'Hindi maabot ang panel server. Check ang Server URL at ang internet.', 0, true);
  } finally { clearTimeout(timer); }
  if (res.status === 204) return {};
  let data = null;
  try { data = await res.json(); } catch { /* hindi JSON */ }
  if (!res.ok) {
    if (res.status === 401 && auth && path !== '/api/auth/login') onUnauthorized();
    throw new ApiError((data && data.error) || `May error (${res.status}).`, res.status);
  }
  return data;
}

export const api = {
  get: (p, o) => request('GET', p, o),
  post: (p, body, o) => request('POST', p, { ...o, body: body || {} }),
  put: (p, body, o) => request('PUT', p, { ...o, body: body || {} }),
  patch: (p, body, o) => request('PATCH', p, { ...o, body: body || {} }),
  del: (p, o) => request('DELETE', p, o),
  // Upload na may progress (XHR) para sa malalaking file (.amx, plugins)
  upload(path, file, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('PUT', getBase() + path);
      const token = getToken();
      if (token) xhr.setRequestHeader('Authorization', `Bearer ${token}`);
      xhr.setRequestHeader('Content-Type', 'application/octet-stream');
      xhr.upload.onprogress = (e) => { if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total); };
      xhr.onerror = () => reject(new ApiError('Pumalya ang upload. Check ang internet.', 0, true));
      xhr.onload = () => {
        let data = {};
        try { data = JSON.parse(xhr.responseText); } catch { /* ok */ }
        if (xhr.status >= 200 && xhr.status < 300) resolve(data);
        else {
          if (xhr.status === 401) onUnauthorized();
          reject(new ApiError(data.error || `Pumalya ang upload (${xhr.status}).`, xhr.status));
        }
      };
      xhr.send(file);
    });
  },
  // Buong URL para sa download link
  url: (p) => getBase() + p,
};

// Para sa login screen: tingnan kung panel server nga ang URL na nilagay.
export async function probe(url) {
  const data = await request('GET', '/api/system/public', { base: normalizeUrl(url), auth: false, timeout: 8000 });
  if (!data || data.app !== 'nova-samp-panel') throw new ApiError('Hindi NOVA SAMP Panel ang nasa URL na iyan.', 0, true);
  return data;
}
