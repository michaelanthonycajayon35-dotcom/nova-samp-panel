'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const serverService = require('../services/server.service');
const playerService = require('../services/player.service');
const v = require('../utils/validation');
const db = require('../config/database');
const { HttpError } = require('../utils/helpers');

const list = (ctx) => playerService.list(serverService.get(ctx.params.id));

async function wrap(fn) {
  try { return await fn(); } catch (e) {
    if (e instanceof HttpError) throw e;
    throw new HttpError(502, `Hindi maabot ang server: ${e.message}`);
  }
}

async function kick(ctx) {
  const s = serverService.get(ctx.params.id);
  const r = await wrap(() => playerService.kick(s, ctx.params.pid));
  db.audit(ctx.user.username, 'player-kick', `${s.name}: #${ctx.params.pid}`);
  return r;
}

async function ban(ctx) {
  const s = serverService.get(ctx.params.id);
  const r = await wrap(() => playerService.ban(s, ctx.params.pid));
  db.audit(ctx.user.username, 'player-ban', `${s.name}: #${ctx.params.pid}`);
  return r;
}

async function say(ctx) {
  const s = serverService.get(ctx.params.id);
  const message = v.oneLine(ctx.body.message, 'message', 150);
  const r = await wrap(() => playerService.say(s, message));
  db.audit(ctx.user.username, 'say', `${s.name}: ${message}`);
  return r;
}

module.exports = { list, kick, ban, say };
