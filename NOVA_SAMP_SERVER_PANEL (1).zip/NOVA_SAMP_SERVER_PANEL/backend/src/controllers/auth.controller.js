'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const db = require('../config/database');
const { JWT_SECRET, JWT_EXPIRES_HOURS } = require('../config/environment');
const { signToken, verifyPassword, hashPassword } = require('../utils/security');
const { failureTracker } = require('../middleware/rate-limit.middleware');
const { HttpError } = require('../utils/helpers');
const v = require('../utils/validation');

const publicUser = (u) => ({
  id: u.id, username: u.username, role: u.role, disabled: Boolean(u.disabled),
  mustChangePassword: Boolean(u.mustChangePassword), createdAt: u.createdAt,
});

const issue = (u) => signToken({ sub: u.id, tv: u.tokenVersion || 0 }, JWT_SECRET, JWT_EXPIRES_HOURS * 3600);

function login(ctx) {
  const username = typeof ctx.body.username === 'string' ? ctx.body.username.trim() : '';
  const password = typeof ctx.body.password === 'string' ? ctx.body.password : '';
  if (!username || !password) throw new HttpError(400, 'Ilagay ang username at password.');
  failureTracker.check(ctx.ip, username);
  const user = db.users.find((u) => u.username.toLowerCase() === username.toLowerCase());
  const ok = user ? verifyPassword(password, user.passwordHash) : (verifyPassword(password, 'scrypt$00$00'), false);
  if (!ok || user.disabled) {
    failureTracker.fail(ctx.ip, username);
    throw new HttpError(401, user && user.disabled ? 'Naka-disable ang account na ito.' : 'Mali ang username o password.');
  }
  failureTracker.reset(ctx.ip, username);
  db.audit(user.username, 'login', ctx.ip);
  return { token: issue(user), user: publicUser(user) };
}

const me = (ctx) => ({ user: publicUser(ctx.user) });

function changePassword(ctx) {
  const { current, next } = ctx.body;
  if (typeof current !== 'string' || !verifyPassword(current, ctx.user.passwordHash)) {
    throw new HttpError(400, 'Mali ang kasalukuyang password.');
  }
  v.password(next);
  if (next === current) throw new HttpError(400, 'Dapat iba ang bagong password.');
  ctx.user.passwordHash = hashPassword(next);
  ctx.user.tokenVersion = (ctx.user.tokenVersion || 0) + 1; // i-logout ang ibang device
  ctx.user.mustChangePassword = false;
  db.save();
  db.audit(ctx.user.username, 'password-change');
  return { token: issue(ctx.user), user: publicUser(ctx.user) };
}

module.exports = { login, me, changePassword, publicUser };
