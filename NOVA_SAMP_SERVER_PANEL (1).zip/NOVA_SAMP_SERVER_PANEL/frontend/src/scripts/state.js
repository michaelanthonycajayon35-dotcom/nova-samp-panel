// NOVA SAMP SERVER PANEL - by CAJAYON | maliit na global state (kasalukuyang server)
import { api } from './api.js';

const KEY = 'nova_server';
const listeners = new Set();
export const state = { servers: [], currentId: safeGet(KEY) };

function safeGet(k) { try { return localStorage.getItem(k); } catch { return null; } }
function safeSet(k, v) { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch { /* ok */ } }

export const onState = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach((fn) => fn(state));

export async function refreshServers() {
  const { servers } = await api.get('/api/servers');
  state.servers = servers;
  if (!servers.some((s) => s.id === state.currentId)) state.currentId = servers[0] ? servers[0].id : null;
  safeSet(KEY, state.currentId);
  emit();
  return servers;
}

export function setCurrent(id) {
  state.currentId = id;
  safeSet(KEY, id);
  emit();
}

export const current = () => state.servers.find((s) => s.id === state.currentId) || null;
export function resetState() { state.servers = []; state.currentId = null; emit(); }

export async function ensureServers() {
  if (!state.servers.length) await refreshServers();
  return state.servers;
}
