'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const rcon = require('./rcon.service');
const { HttpError } = require('../utils/helpers');

function playerId(value) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 0 || n > 999) throw new HttpError(400, 'Mali ang player ID.');
  return n;
}

const list = (server) => rcon.queryPlayers(server);

async function kick(server, id) {
  const lines = await rcon.rcon(server, `kick ${playerId(id)}`);
  return { lines };
}

async function ban(server, id) {
  const pid = playerId(id);
  const lines = await rcon.rcon(server, `ban ${pid}`);
  return { lines };
}

async function say(server, message) {
  const lines = await rcon.rcon(server, `say ${message}`);
  return { lines };
}

module.exports = { list, kick, ban, say, playerId };
