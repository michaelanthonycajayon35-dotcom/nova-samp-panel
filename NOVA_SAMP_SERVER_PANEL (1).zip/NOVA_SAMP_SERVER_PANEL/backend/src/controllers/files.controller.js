'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const fs = require('fs');
const serverService = require('../services/server.service');
const fileService = require('../services/file.service');
const backupService = require('../services/backup.service');
const { JWT_SECRET, MAX_UPLOAD_MB } = require('../config/environment');
const { signToken, verifyToken } = require('../utils/security');
const { HttpError } = require('../utils/helpers');
const v = require('../utils/validation');
const db = require('../config/database');

const srv = (ctx) => serverService.get(ctx.params.id);
const p = (ctx) => (typeof ctx.query.path === 'string' ? ctx.query.path : '');

const list = (ctx) => fileService.list(srv(ctx), p(ctx));
const read = (ctx) => fileService.readText(srv(ctx), p(ctx));

function write(ctx) {
  const s = srv(ctx);
  const r = fileService.writeText(s, ctx.body.path, ctx.body.content);
  db.audit(ctx.user.username, 'file-save', `${s.name}: ${r.path}`);
  return r;
}

const mkdir = (ctx) => fileService.mkdir(srv(ctx), ctx.body.path || '', ctx.body.name);

function remove(ctx) {
  const s = srv(ctx);
  const r = fileService.remove(s, p(ctx));
  db.audit(ctx.user.username, 'file-delete', `${s.name}: ${r.removed}`);
  return r;
}

const rename = (ctx) => fileService.rename(srv(ctx), ctx.body.path, ctx.body.name);

async function upload(ctx) {
  const s = srv(ctx);
  const name = v.oneLine(ctx.query.name, 'name', 200);
  const r = await fileService.upload(s, p(ctx), name, ctx.req, MAX_UPLOAD_MB * 1024 * 1024);
  db.audit(ctx.user.username, 'file-upload', `${s.name}: ${r.path}`);
  return r;
}

// Maikling-buhay na link para sa download (kailangan ito sa APK/browser dahil walang Authorization header).
const makeLink = (payload) => ({ url: `/api/download?token=${signToken({ purpose: 'download', ...payload }, JWT_SECRET, 60)}` });

function link(ctx) {
  const s = srv(ctx);
  fileService.resolveFile(s, p(ctx));
  return makeLink({ kind: 'file', sid: s.id, p: p(ctx) });
}

function download(ctx) {
  const payload = verifyToken(ctx.query.token, JWT_SECRET);
  if (!payload || payload.purpose !== 'download') throw new HttpError(401, 'Expired na ang download link.');
  const s = serverService.get(payload.sid);
  const info = payload.kind === 'backup' ? backupService.resolveBackup(s.id, payload.p) : fileService.resolveFile(s, payload.p);
  const safe = info.name.replace(/[^\w.-]+/g, '_');
  ctx.res.writeHead(200, {
    'Content-Type': 'application/octet-stream',
    'Content-Length': info.size,
    'Content-Disposition': `attachment; filename="${safe}"; filename*=UTF-8''${encodeURIComponent(info.name)}`,
    'Cache-Control': 'no-store',
  });
  fs.createReadStream(info.file).on('error', () => ctx.res.destroy()).pipe(ctx.res);
}

module.exports = { list, read, write, mkdir, remove, rename, upload, link, download, makeLink };
