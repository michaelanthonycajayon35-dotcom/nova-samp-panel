'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const test = require('node:test');
const assert = require('node:assert/strict');
const { boot } = require('./support');

test('auth at users', async (t) => {
  const app = await boot();
  t.after(() => app.close());
  const { api } = app;

  await t.test('health at public ay walang login', async () => {
    assert.equal((await api('GET', '/api/system/health')).json.ok, true);
    assert.equal((await api('GET', '/api/system/public')).json.app, 'nova-samp-panel');
  });

  await t.test('kailangan ng login sa protected routes', async () => {
    assert.equal((await api('GET', '/api/servers')).status, 401);
    assert.equal((await api('GET', '/api/servers', { token: 'mali.mali.mali' })).status, 401);
  });

  await t.test('mali ang password', async () => {
    const r = await api('POST', '/api/auth/login', { body: { username: 'admin', password: 'mali' } });
    assert.equal(r.status, 401);
  });

  let token;
  await t.test('tamang login', async () => {
    const r = await api('POST', '/api/auth/login', { body: { username: 'ADMIN', password: 'TestPass123' } });
    assert.equal(r.status, 200);
    assert.equal(r.json.user.role, 'admin');
    assert.ok(!('passwordHash' in r.json.user));
    token = r.json.token;
    assert.equal((await api('GET', '/api/auth/me', { token })).json.user.username, 'admin');
  });

  await t.test('roles: viewer hindi makakapasok sa admin routes', async () => {
    const c = await api('POST', '/api/users', { token, body: { username: 'bantay', password: 'bantay1234', role: 'viewer' } });
    assert.equal(c.status, 200);
    const vt = await app.login('bantay', 'bantay1234');
    assert.equal((await api('GET', '/api/servers', { token: vt })).status, 200);
    assert.equal((await api('GET', '/api/users', { token: vt })).status, 403);
    assert.equal((await api('POST', '/api/servers', { token: vt, body: { name: 'xxx' } })).status, 403);
  });

  await t.test('hindi pwedeng alisin ang huling admin', async () => {
    const me = (await api('GET', '/api/auth/me', { token })).json.user;
    assert.equal((await api('PATCH', `/api/users/${me.id}`, { token, body: { role: 'viewer' } })).status, 400);
    assert.equal((await api('DELETE', `/api/users/${me.id}`, { token })).status, 400);
  });

  await t.test('palit password: luma ay hindi na gagana', async () => {
    const r = await api('POST', '/api/auth/password', { token, body: { current: 'TestPass123', next: 'BagoNaPass99' } });
    assert.equal(r.status, 200);
    assert.equal((await api('GET', '/api/auth/me', { token })).status, 401); // luma na ang token
    assert.equal((await api('GET', '/api/auth/me', { token: r.json.token })).status, 200);
    assert.equal(await app.login('admin', 'TestPass123'), undefined);
    assert.ok(await app.login('admin', 'BagoNaPass99'));
  });

  await t.test('lockout pagkatapos ng maraming maling login', async () => {
    require('../src/middleware/rate-limit.middleware').failureTracker.clearAll();
    let last;
    for (let i = 0; i < 9; i++) last = await api('POST', '/api/auth/login', { body: { username: 'bantay', password: 'mali-mali' } });
    assert.equal(last.status, 429);
  });
});
