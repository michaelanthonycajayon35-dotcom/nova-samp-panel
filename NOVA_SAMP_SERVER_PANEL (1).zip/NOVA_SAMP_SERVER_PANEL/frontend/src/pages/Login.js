// NOVA SAMP SERVER PANEL - by CAJAYON | Login
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api, getBase, needsServerUrl, probe, normalizeUrl, isNative } from '../scripts/api.js';
import { login } from '../scripts/auth.js';
import { setPanelName } from '../App.js';

export async function mount(root) {
  const urlInput = h('input', { class: 'input', type: 'text', inputmode: 'url', placeholder: 'http://123.45.67.89:3000', autocapitalize: 'off', autocomplete: 'off', spellcheck: 'false', value: isNative() ? getBase() : (getBase() === location.origin ? '' : getBase()) });
  const user = h('input', { class: 'input', type: 'text', placeholder: 'Username', autocomplete: 'username', autocapitalize: 'off', spellcheck: 'false' });
  const pass = h('input', { class: 'input', type: 'password', placeholder: 'Password', autocomplete: 'current-password' });
  const eye = h('button', { class: 'btn icon sm ghost', type: 'button', 'aria-label': 'Ipakita ang password', onclick: () => {
    const show = pass.type === 'password';
    pass.type = show ? 'text' : 'password';
    eye.replaceChildren(icon(show ? 'eyeOff' : 'eye'));
  } }, icon('eye'));
  const err = h('div', { class: 'banner danger hidden', role: 'alert' });
  const btn = h('button', { class: 'btn primary block', type: 'submit' }, 'Mag-login');
  const title = h('h1', null, 'NOVA SAMP Panel');
  const details = h('details', null,
    h('summary', null, icon('globe', 16), 'Server URL ng panel', icon('chevronDown', 14)),
    h('div', { class: 'field', style: { marginTop: '10px' } }, urlInput,
      h('div', { class: 'hint' }, isNative() ? 'Ilagay ang address ng VPS/PC na nagpapatakbo ng panel (kasama ang port).' : 'Iwanang blangko para gamitin ang kasalukuyang site.')));
  if (needsServerUrl() || isNative()) details.open = true;

  const showError = (m) => { err.classList.remove('hidden'); err.replaceChildren(icon('warning'), h('div', null, m)); };

  const form = h('form', { class: 'stack', novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    err.classList.add('hidden');
    if (!user.value.trim() || !pass.value) { showError('Ilagay ang username at password.'); return; }
    btn.classList.add('loading');
    try {
      const base = normalizeUrl(urlInput.value) || (isNative() ? '' : location.origin);
      if (!base) { details.open = true; urlInput.focus(); throw new Error('Ilagay muna ang Server URL ng panel mo.'); }
      const info = await probe(base);
      setPanelName(info.name);
      await login(urlInput.value ? base : '', user.value.trim(), pass.value);
      window.dispatchEvent(new CustomEvent('nova:login'));
    } catch (ex) {
      details.open = details.open || Boolean(ex.network);
      showError(ex.message);
    } finally { btn.classList.remove('loading'); }
  } },
  details,
  h('div', { class: 'field' }, h('label', null, 'Username'), user),
  h('div', { class: 'field' }, h('label', null, 'Password'), h('div', { class: 'input-wrap' }, pass, eye)),
  err, btn);

  root.append(h('div', { class: 'login-wrap' }, h('div', { class: 'login-card' },
    h('img', { class: 'logo', src: 'public/assets/logo-icon.png', alt: 'NOVA' }), title,
    h('p', { class: 'sub' }, 'Pamahalaan ang SA-MP / open.mp server mo mula sa phone.'), form)));

  // Kunin ang pangalan ng panel (kung abot ang server)
  if (getBase()) {
    api.get('/api/system/public', { auth: false, timeout: 5000 }).then((d) => { if (d && d.name) title.textContent = d.name; }).catch(() => {});
  }
  return () => {};
}
