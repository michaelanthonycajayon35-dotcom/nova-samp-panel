'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const c = require('../controllers/servers.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');

const viewer = requireRole('viewer');
const mod = requireRole('moderator');
const admin = requireRole('admin');

module.exports = (router) => {
  router.get('/api/servers', authenticate, viewer, c.list);
  router.post('/api/servers', authenticate, admin, c.create);
  router.put('/api/servers/import', { raw: true }, authenticate, admin, c.importServer);
  router.get('/api/servers/:id', authenticate, viewer, c.details);
  router.patch('/api/servers/:id', authenticate, admin, c.update);
  router.delete('/api/servers/:id', authenticate, admin, c.remove);
  router.post('/api/servers/:id/start', authenticate, mod, c.start);
  router.post('/api/servers/:id/stop', authenticate, mod, c.stop);
  router.post('/api/servers/:id/restart', authenticate, mod, c.restart);
  router.get('/api/servers/:id/config', authenticate, admin, c.getConfig);
  router.put('/api/servers/:id/config', authenticate, admin, c.putConfig);
};
