// NOVA SAMP SERVER PANEL - by CAJAYON | formatting helpers
export function bytes(n) {
  if (n === null || n === undefined || Number.isNaN(n)) return '-';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  let v = Number(n);
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v >= 100 || i === 0 ? Math.round(v) : v.toFixed(1)} ${u[i]}`;
}

export function duration(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const d = Math.floor(sec / 86400);
  const hr = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (d) return `${d}d ${hr}h`;
  if (hr) return `${hr}h ${m}m`;
  if (m) return `${m}m ${sec % 60}s`;
  return `${sec}s`;
}

export function date(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function ago(iso) {
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 10) return 'ngayon lang';
  if (s < 60) return `${s}s ang nakalipas`;
  if (s < 3600) return `${Math.floor(s / 60)}m ang nakalipas`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ang nakalipas`;
  return `${Math.floor(s / 86400)}d ang nakalipas`;
}

export const clock = (ms) => new Date(ms).toLocaleTimeString([], { hour12: false });
export const typeLabel = (t) => (t === 'openmp' ? 'open.mp' : 'SA-MP');
