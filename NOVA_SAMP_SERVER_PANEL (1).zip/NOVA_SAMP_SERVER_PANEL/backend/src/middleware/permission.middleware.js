'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// viewer < moderator < admin
const { HttpError } = require('../utils/helpers');

const RANK = { viewer: 1, moderator: 2, admin: 3 };

function requireRole(minRole) {
  return (ctx) => {
    if (!ctx.user) throw new HttpError(401, 'Mag-login muna.');
    if ((RANK[ctx.user.role] || 0) < RANK[minRole]) {
      throw new HttpError(403, `Kailangan ng "${minRole}" na role para dito.`);
    }
  };
}

module.exports = { requireRole, RANK };
