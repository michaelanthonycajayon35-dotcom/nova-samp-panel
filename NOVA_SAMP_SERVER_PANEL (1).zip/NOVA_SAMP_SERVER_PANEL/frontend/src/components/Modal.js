// NOVA SAMP SERVER PANEL - by CAJAYON | Modal / bottom sheet
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';

let locks = 0;
const lock = () => { if (locks++ === 0) document.body.style.overflow = 'hidden'; };
const unlock = () => { if (--locks <= 0) { locks = 0; document.body.style.overflow = ''; } };

/**
 * Bubuksan ang sheet. Ibabalik ang { close, body, sheet }.
 * `content` ay Node o function(close) => Node.
 */
export function openSheet({ title, content, full = false, dismissible = true, onClose } = {}) {
  const prevFocus = document.activeElement;
  let closed = false;
  const body = h('div', { class: full ? 'grow' : null, style: full ? { display: 'flex', flexDirection: 'column', minHeight: '0' } : null });
  const close = (value) => {
    if (closed) return;
    closed = true;
    document.removeEventListener('keydown', onKey);
    overlay.remove();
    unlock();
    if (prevFocus && prevFocus.focus) { try { prevFocus.focus(); } catch { /* ok */ } }
    if (onClose) onClose(value);
  };
  const closeBtn = dismissible ? h('button', { class: 'btn icon sm ghost', 'aria-label': 'Isara', onclick: () => close() }, icon('x')) : null;
  const sheet = h('div', { class: `sheet${full ? ' full' : ''}`, role: 'dialog', 'aria-modal': 'true', 'aria-label': title || 'Dialog' },
    h('div', { class: 'grab' }),
    title ? h('div', { class: 'sheet-head' }, h('h2', null, title), closeBtn) : null,
    body);
  const overlay = h('div', { class: 'overlay', onclick: (e) => { if (dismissible && e.target === overlay) close(); } }, sheet);
  function onKey(e) { if (e.key === 'Escape' && dismissible) close(); }
  document.addEventListener('keydown', onKey);
  const node = typeof content === 'function' ? content(close) : content;
  if (node) body.append(node);
  document.body.append(overlay);
  lock();
  const focusable = sheet.querySelector('input, textarea, select');
  if (focusable && !full) setTimeout(() => { try { focusable.focus(); } catch { /* ok */ } }, 60);
  return { close, body, sheet };
}

export function sheetActions(...buttons) { return h('div', { class: 'sheet-actions' }, ...buttons); }

// Listahan ng actions (bottom menu)
export function openMenu(title, items) {
  return openSheet({
    title,
    content: (close) => h('div', null, items.filter(Boolean).map((it) =>
      h('button', { class: `menu-item${it.danger ? ' danger' : ''}`, onclick: () => { close(); it.onClick(); } }, icon(it.icon || 'dots'), h('span', null, it.label)))),
  });
}
