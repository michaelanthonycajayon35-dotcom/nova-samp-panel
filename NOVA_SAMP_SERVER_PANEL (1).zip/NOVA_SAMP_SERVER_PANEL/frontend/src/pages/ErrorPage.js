// NOVA SAMP SERVER PANEL - by CAJAYON | ErrorPage
import { h, clear } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { navigate, resolve } from '../scripts/navigation.js';

export function renderError(root, err, notFound = false) {
  clear(root);
  const msg = notFound ? 'Hindi nahanap ang page na hinahanap mo.' : (err && err.message) || 'May hindi inaasahang error.';
  root.append(h('div', { class: 'error-page' },
    h('div', { class: 'big' }, notFound ? '404' : 'Oops'),
    h('p', { class: 'muted', style: { margin: '8px 0 20px' } }, msg),
    h('div', { class: 'row', style: { justifyContent: 'center' } },
      notFound ? null : h('button', { class: 'btn', onclick: () => resolve() }, icon('refresh'), 'Subukan ulit'),
      h('button', { class: 'btn primary', onclick: () => navigate('/') }, icon('dashboard'), 'Dashboard'))));
}
