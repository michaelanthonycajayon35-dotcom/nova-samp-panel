'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Simpleng JSON database (walang kailangang i-install). Atomic ang pag-save.
const fs = require('fs');
const { DB_FILE } = require('./environment');
const { nowIso } = require('../utils/helpers');
const logger = require('../utils/logger');

let data = { users: [], servers: [], settings: {}, audit: [] };

function load() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    data = { users: [], servers: [], settings: {}, audit: [], ...parsed };
  } catch (e) {
    if (e.code !== 'ENOENT') {
      // sira ang file: i-backup para hindi mawala ang data
      try { fs.copyFileSync(DB_FILE, DB_FILE + '.corrupt-' + Date.now()); } catch { /* ignore */ }
      logger.error('Hindi mabasa ang database, gagawa ng bago:', e.message);
    }
  }
}

function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
}

function audit(username, action, detail = '') {
  data.audit.unshift({ t: nowIso(), user: username || 'system', action, detail: String(detail).slice(0, 200) });
  if (data.audit.length > 200) data.audit.length = 200;
  save();
}

load();

module.exports = {
  get users() { return data.users; },
  get servers() { return data.servers; },
  get settings() { return data.settings; },
  set settings(v) { data.settings = v; },
  get auditLog() { return data.audit; },
  save,
  audit,
  reload: load,
};
