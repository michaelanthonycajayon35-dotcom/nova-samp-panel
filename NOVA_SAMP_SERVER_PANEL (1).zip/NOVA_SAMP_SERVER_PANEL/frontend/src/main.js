// NOVA SAMP SERVER PANEL - by CAJAYON | entry point
import { boot } from './App.js';

boot().catch((e) => {
  console.error(e);
  document.getElementById('app').textContent = 'May error sa pag-start ng app: ' + e.message;
});
