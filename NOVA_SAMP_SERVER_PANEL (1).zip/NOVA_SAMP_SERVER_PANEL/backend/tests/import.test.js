'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { boot } = require('./support');

const have = (cmd) => spawnSync('which', [cmd]).status === 0;

test('import ng server', async (t) => {
  const app = await boot();
  t.after(() => app.close());
  const { api } = app;
  const token = await app.login();
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-imp-'));
  t.after(() => fs.rmSync(work, { recursive: true, force: true }));

  // gumawa ng "server" na may nested na folder
  const src = path.join(work, 'src', 'myserver');
  fs.mkdirSync(path.join(src, 'gamemodes'), { recursive: true });
  fs.writeFileSync(path.join(src, 'server.cfg'), 'rcon_password abc123\nport 7950\nhostname Imported\n');
  fs.writeFileSync(path.join(src, 'gamemodes', 'main.amx'), 'AMX');
  fs.writeFileSync(path.join(src, 'samp03svr'), '#!/bin/sh\necho "Imported server up"\nwhile read l; do :; done\n', { mode: 0o755 });

  const zip = path.join(work, 'myserver.zip');
  const tgz = path.join(work, 'myserver.tar.gz');
  const hasZip = have('zip');
  if (hasZip) spawnSync('zip', ['-r', '-q', zip, 'myserver'], { cwd: path.join(work, 'src') });
  spawnSync('tar', ['-czf', tgz, '-C', path.join(work, 'src'), 'myserver']);
  const serversDir = path.join(app.dir, 'servers');
  let imported;

  await t.test('zip: auto-detect port, rcon, executable', { skip: !hasZip }, async () => {
    const r = await api('PUT', '/api/servers/import?filename=myserver.zip&name=Imported%20Zip', { token, raw: fs.readFileSync(zip) });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.server.port, 7950);
    assert.equal(r.json.server.hasRcon, true);
    assert.equal(r.json.server.executable, 'samp03svr');
    assert.ok(fs.existsSync(path.join(r.json.server.path, 'gamemodes', 'main.amx')), 'na-flatten ang folder');
    const mode = fs.statSync(path.join(r.json.server.path, 'samp03svr')).mode & 0o111;
    assert.ok(mode, 'executable bit ay napreserba');
    await api('DELETE', `/api/servers/${r.json.server.id}?deleteFiles=true`, { token });
  });

  await t.test('tar.gz: auto-detect', async () => {
    const r = await api('PUT', '/api/servers/import?filename=myserver.tar.gz&name=Imported%20Tar', { token, raw: fs.readFileSync(tgz) });
    assert.equal(r.status, 200, r.text);
    imported = r.json.server;
    assert.equal(imported.port, 7950);
    assert.equal(imported.hasRcon, true);
    assert.equal(imported.executable, 'samp03svr');
    assert.equal(imported.type, 'samp');
    assert.equal(r.json.found.executable, true);
    assert.ok(!('rconPassword' in imported));
    // na-flatten ang "myserver/" folder
    assert.ok(fs.existsSync(path.join(imported.path, 'server.cfg')));
    assert.ok(fs.existsSync(path.join(imported.path, 'gamemodes', 'main.amx')));
  });

  await t.test('mapapatakbo ang na-import na server', { skip: process.platform === 'win32' }, async () => {
    let r = await api('POST', `/api/servers/${imported.id}/start`, { token });
    assert.equal(r.status, 200, r.text);
    await new Promise((res) => setTimeout(res, 300));
    r = await api('GET', `/api/servers/${imported.id}/console`, { token });
    assert.ok(r.json.lines.some((l) => l.text === 'Imported server up'));
    r = await api('POST', `/api/servers/${imported.id}/stop`, { token });
    assert.equal(r.json.server.process.running, false);
  });

  await t.test('conflict sa port: 409 at walang naiwang folder', async () => {
    const before = fs.readdirSync(serversDir).length;
    const r = await api('PUT', '/api/servers/import?filename=myserver.tar.gz&name=Duplicate', { token, raw: fs.readFileSync(tgz) });
    assert.equal(r.status, 409);
    assert.match(r.json.error, /7950/);
    assert.equal(fs.readdirSync(serversDir).length, before);
    assert.equal(fs.readdirSync(path.join(app.dir, 'uploads')).filter((n) => n.includes('import')).length, 0);
  });

  await t.test('port override ay isinusulat sa server.cfg', async () => {
    const r = await api('PUT', '/api/servers/import?filename=myserver.tar.gz&name=Override&port=7960', { token, raw: fs.readFileSync(tgz) });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.server.port, 7960);
    assert.match(fs.readFileSync(path.join(r.json.server.path, 'server.cfg'), 'utf8'), /^port 7960$/m);
  });

  await t.test('maling extension at admin lang', async () => {
    assert.equal((await api('PUT', '/api/servers/import?filename=virus.exe', { token, raw: Buffer.from('x') })).status, 400);
    await api('POST', '/api/users', { token, body: { username: 'mod2', password: 'moderator2', role: 'moderator' } });
    const mt = await app.login('mod2', 'moderator2');
    assert.equal((await api('PUT', '/api/servers/import?filename=a.zip', { token: mt, raw: Buffer.from('x') })).status, 403);
  });

  await t.test('sirang zip', async () => {
    const r = await api('PUT', '/api/servers/import?filename=broken.zip&name=Broken', { token, raw: Buffer.from('hindi ito zip, sira') });
    assert.equal(r.status, 400);
  });

  await t.test('zip-slip: bawal lumabas sa folder', { skip: !have('python3') }, async () => {
    const evil = path.join(work, 'evil.zip');
    const py = `import zipfile\nz=zipfile.ZipFile(${JSON.stringify(evil)},'w')\nz.writestr('server.cfg','port 7970\\n')\nz.writestr('../../zipslip.txt','pwned')\nz.writestr('..\\\\..\\\\zipslip2.txt','pwned')\nz.close()`;
    assert.equal(spawnSync('python3', ['-c', py]).status, 0);
    const r = await api('PUT', '/api/servers/import?filename=evil.zip&name=Evil', { token, raw: fs.readFileSync(evil) });
    assert.ok([400, 403].includes(r.status), String(r.status));
    assert.equal(fs.existsSync(path.join(app.dir, 'zipslip.txt')), false);
    assert.equal(fs.existsSync(path.join(app.dir, 'servers', 'zipslip.txt')), false);
    assert.equal(fs.existsSync(path.join(os.tmpdir(), 'zipslip.txt')), false);
  });
});
