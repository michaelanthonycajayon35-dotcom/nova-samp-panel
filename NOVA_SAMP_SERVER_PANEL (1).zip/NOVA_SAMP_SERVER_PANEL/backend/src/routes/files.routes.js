'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Admin lang ang may access sa File Manager (nandoon ang server.cfg na may RCON password).
const c = require('../controllers/files.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');

const admin = requireRole('admin');

module.exports = (router) => {
  router.get('/api/servers/:id/files', authenticate, admin, c.list);
  router.get('/api/servers/:id/files/read', authenticate, admin, c.read);
  router.put('/api/servers/:id/files/write', { limit: 2 * 1024 * 1024 }, authenticate, admin, c.write);
  router.post('/api/servers/:id/files/mkdir', authenticate, admin, c.mkdir);
  router.post('/api/servers/:id/files/rename', authenticate, admin, c.rename);
  router.delete('/api/servers/:id/files', authenticate, admin, c.remove);
  router.put('/api/servers/:id/files/upload', { raw: true }, authenticate, admin, c.upload);
  router.get('/api/servers/:id/files/link', authenticate, admin, c.link);
  router.get('/api/download', c.download); // may sariling signed token
};
