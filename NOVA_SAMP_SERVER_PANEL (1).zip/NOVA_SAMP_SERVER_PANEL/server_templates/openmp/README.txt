Ilagay dito (gamit ang File Manager ng panel) ang:
  - omp-server (Linux) o omp-server.exe (Windows) at ang components/
  - mga .amx sa gamemodes/ at filterscripts/
Tapos pindutin ang Start sa panel.
