'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Password hashing (scrypt), JWT (HS256), at proteksyon sa path traversal.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { HttpError } = require('./helpers');

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

function verifyPassword(password, stored) {
  try {
    const [algo, saltHex, hashHex] = String(stored).split('$');
    if (algo !== 'scrypt') return false;
    const expected = Buffer.from(hashHex, 'hex');
    const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length);
    return crypto.timingSafeEqual(actual, expected);
  } catch { return false; }
}

const b64u = (buf) => Buffer.from(buf).toString('base64url');

function signToken(payload, secret, expiresSec) {
  const body = { ...payload, iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + expiresSec };
  const head = b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const data = `${head}.${b64u(JSON.stringify(body))}`;
  const sig = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  return `${data}.${sig}`;
}

function verifyToken(token, secret) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) return null;
  const expected = crypto.createHmac('sha256', secret).update(`${parts[0]}.${parts[1]}`).digest();
  let given;
  try { given = Buffer.from(parts[2], 'base64url'); } catch { return null; }
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) return null;
  try {
    const body = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    if (!body.exp || body.exp < Date.now() / 1000) return null;
    return body;
  } catch { return null; }
}

// Siguraduhing nasa loob ng base folder ang path (kasama ang symlink check).
function safeJoin(base, rel = '') {
  const cleaned = String(rel || '').replace(/\0/g, '').replace(/\\/g, '/');
  const baseResolved = path.resolve(base);
  const target = path.resolve(baseResolved, '.' + path.sep + cleaned);
  const inside = (p, b) => p === b || p.startsWith(b + path.sep);
  if (!inside(target, baseResolved)) throw new HttpError(403, 'Bawal ang path na ito.');
  // i-check ang pinakamalapit na existing na parent gamit realpath
  let probe = target;
  while (!fs.existsSync(probe) && probe !== baseResolved) probe = path.dirname(probe);
  try {
    const realBase = fs.realpathSync(baseResolved);
    const realProbe = fs.realpathSync(probe);
    if (!inside(realProbe, realBase)) throw new HttpError(403, 'Bawal ang path na ito.');
  } catch (e) {
    if (e instanceof HttpError) throw e;
  }
  return target;
}

function safeName(name) {
  const n = String(name || '').trim();
  if (!n || n === '.' || n === '..' || /[\\/\0]/.test(n) || n.length > 200) {
    throw new HttpError(400, 'Hindi valid ang pangalan ng file/folder.');
  }
  return n;
}

module.exports = { hashPassword, verifyPassword, signToken, verifyToken, safeJoin, safeName };
