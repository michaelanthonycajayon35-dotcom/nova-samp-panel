'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// In-memory na rate limit + login lockout.
const { HttpError } = require('../utils/helpers');

const buckets = new Map();

function limiter({ windowMs = 60_000, max = 300, name = 'api' } = {}) {
  return (ctx) => {
    const key = `${name}:${ctx.ip}`;
    const now = Date.now();
    let b = buckets.get(key);
    if (!b || b.reset < now) { b = { count: 0, reset: now + windowMs }; buckets.set(key, b); }
    b.count++;
    if (b.count > max) {
      const wait = Math.ceil((b.reset - now) / 1000);
      throw new HttpError(429, `Masyadong maraming request. Subukan ulit sa ${wait}s.`);
    }
  };
}

// Pag 8 sunod-sunod na maling login, locked ng 10 minuto (bawat IP + username).
const failures = new Map();
const LOCK_AFTER = 8;
const LOCK_MS = 10 * 60_000;
const failureTracker = {
  check(ip, username) {
    const f = failures.get(`${ip}|${String(username).toLowerCase()}`);
    if (f && f.count >= LOCK_AFTER && f.until > Date.now()) {
      throw new HttpError(429, `Masyadong maraming maling login. Subukan ulit sa ${Math.ceil((f.until - Date.now()) / 60000)} minuto.`);
    }
  },
  fail(ip, username) {
    const key = `${ip}|${String(username).toLowerCase()}`;
    const f = failures.get(key) || { count: 0, until: 0 };
    if (f.until && f.until < Date.now()) { f.count = 0; }
    f.count++;
    f.until = Date.now() + LOCK_MS;
    failures.set(key, f);
  },
  reset(ip, username) { failures.delete(`${ip}|${String(username).toLowerCase()}`); },
  clearAll() { failures.clear(); buckets.clear(); },
};

const timer = setInterval(() => {
  const now = Date.now();
  for (const [k, b] of buckets) if (b.reset < now) buckets.delete(k);
  for (const [k, f] of failures) if (f.until < now) failures.delete(k);
}, 60_000);
timer.unref();

module.exports = { limiter, failureTracker };
