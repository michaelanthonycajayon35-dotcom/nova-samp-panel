'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const c = require('../controllers/players.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');

const mod = requireRole('moderator');

module.exports = (router) => {
  router.get('/api/servers/:id/players', authenticate, requireRole('viewer'), c.list);
  router.post('/api/servers/:id/players/:pid/kick', authenticate, mod, c.kick);
  router.post('/api/servers/:id/players/:pid/ban', authenticate, mod, c.ban);
  router.post('/api/servers/:id/say', authenticate, mod, c.say);
};
