// NOVA SAMP SERVER PANEL - by CAJAYON | Backups
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api } from '../scripts/api.js';
import { hasRole } from '../scripts/auth.js';
import { notify } from '../scripts/notifications.js';
import { ensureServers, current } from '../scripts/state.js';
import { bytes, date } from '../scripts/format.js';
import { PageHead, NoServer, Empty } from '../components/Layout.js';
import { Loading } from '../components/Loading.js';
import { Banner } from '../components/Notification.js';
import { openMenu } from '../components/Modal.js';
import { confirmDialog } from '../components/ConfirmDialog.js';

export async function mount(root) {
  await ensureServers();
  const s = current();
  if (!s) { root.replaceChildren(PageHead('Backups'), NoServer()); return; }
  const base = `/api/servers/${s.id}`;
  const isAdmin = hasRole('admin');
  const box = h('div', { class: 'card flat' }, Loading());
  const createBtn = h('button', { class: 'btn primary', onclick: create }, icon('plus'), 'Backup');

  async function load() {
    try {
      const { backups } = await api.get(`${base}/backups`);
      box.replaceChildren();
      if (!backups.length) { box.append(Empty({ icon: 'backup', title: 'Wala pang backup', text: 'Pindutin ang "Backup" para i-save ang kasalukuyang estado ng server.' })); return; }
      for (const b of backups) {
        const tag = b.name.startsWith('auto_') ? 'Auto' : b.name.startsWith('pre-restore_') ? 'Pre-restore' : null;
        box.append(h('div', { class: `list-item${isAdmin ? ' clickable' : ''}`, onclick: isAdmin ? () => menu(b) : null },
          h('div', { class: 'avatar' }, icon('backup')),
          h('div', { class: 'grow' }, h('div', { class: 'title ellipsis' }, b.name), h('div', { class: 'meta' }, `${bytes(b.size)} · ${date(b.createdAt)}`)),
          tag ? h('span', { class: 'chip info' }, tag) : null, isAdmin ? icon('dots', 18) : null));
      }
    } catch (e) { box.replaceChildren(Empty({ icon: 'warning', title: 'Hindi ma-load', text: e.message })); }
  }

  async function create() {
    createBtn.classList.add('loading');
    try { const { backup } = await api.post(`${base}/backups`); notify.ok(`Tapos na ang backup (${bytes(backup.size)}).`); await load(); } catch (e) { notify.error(e.message); } finally { createBtn.classList.remove('loading'); }
  }

  function menu(b) {
    openMenu(b.name, [
      { label: 'I-download', icon: 'download', onClick: async () => {
        try { const r = await api.get(`${base}/backups/${encodeURIComponent(b.name)}/link`); window.open(api.url(r.url), '_blank', 'noopener'); notify.info('Sinisimulan ang download...'); } catch (e) { notify.error(e.message); }
      } },
      { label: 'I-restore', icon: 'restart', onClick: async () => {
        const ok = await confirmDialog({ title: 'I-restore ang backup?', message: 'Papalitan ang mga file ng server ng laman ng backup na ito. Gagawa muna ng "pre-restore" backup para may balikan ka.\nKailangang patay ang server.', danger: true, confirmText: 'I-restore' });
        if (!ok) return;
        try { await api.post(`${base}/backups/${encodeURIComponent(b.name)}/restore`); notify.ok('Na-restore na.'); load(); } catch (e) { notify.error(e.message); }
      } },
      { label: 'Burahin', icon: 'trash', danger: true, onClick: async () => {
        const ok = await confirmDialog({ title: 'Burahin ang backup?', message: b.name, danger: true, confirmText: 'Burahin' });
        if (!ok) return;
        try { await api.del(`${base}/backups/${encodeURIComponent(b.name)}`); notify.ok('Nabura.'); load(); } catch (e) { notify.error(e.message); }
      } },
    ]);
  }

  root.replaceChildren(
    PageHead('Backups', s.name, createBtn),
    h('div', { style: { marginBottom: '12px' } }, Banner('info', 'Naka-compress (tar.gz) ang buong folder ng server. Pwedeng i-set ang auto-backup at ilan ang itatabi sa Settings.')),
    box);
  await load();
  return () => {};
}
