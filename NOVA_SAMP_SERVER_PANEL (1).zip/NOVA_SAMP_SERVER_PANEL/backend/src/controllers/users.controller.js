'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const db = require('../config/database');
const env = require('../config/environment');
const v = require('../utils/validation');
const { hashPassword } = require('../utils/security');
const { HttpError, newId, nowIso, randomPassword } = require('../utils/helpers');
const { publicUser } = require('./auth.controller');
const logger = require('../utils/logger');

const activeAdmins = (except) => db.users.filter((u) => u.role === 'admin' && !u.disabled && u.id !== except).length;

const list = () => ({ users: db.users.map(publicUser) });

function create(ctx) {
  const username = v.username(ctx.body.username);
  const password = v.password(ctx.body.password);
  const role = v.role(ctx.body.role || 'viewer');
  if (db.users.some((u) => u.username.toLowerCase() === username.toLowerCase())) throw new HttpError(409, 'May gumagamit na ng username na iyan.');
  const user = { id: newId(), username, passwordHash: hashPassword(password), role, disabled: false, tokenVersion: 0, mustChangePassword: false, createdAt: nowIso() };
  db.users.push(user);
  db.save();
  db.audit(ctx.user.username, 'user-create', `${username} (${role})`);
  return { user: publicUser(user) };
}

function update(ctx) {
  const u = db.users.find((x) => x.id === ctx.params.id);
  if (!u) throw new HttpError(404, 'Walang ganyang user.');
  const b = ctx.body;
  if (b.role !== undefined) {
    v.role(b.role);
    if (u.role === 'admin' && b.role !== 'admin' && activeAdmins(u.id) === 0) throw new HttpError(400, 'Hindi pwedeng ibaba ang huling admin.');
    u.role = b.role;
  }
  if (b.disabled !== undefined) {
    const dis = v.bool(b.disabled);
    if (dis && u.id === ctx.user.id) throw new HttpError(400, 'Hindi mo pwedeng i-disable ang sarili mo.');
    if (dis && u.role === 'admin' && activeAdmins(u.id) === 0) throw new HttpError(400, 'Hindi pwedeng i-disable ang huling admin.');
    u.disabled = dis;
  }
  if (b.password) {
    u.passwordHash = hashPassword(v.password(b.password));
    u.mustChangePassword = false;
  }
  if (b.password || b.role !== undefined || b.disabled !== undefined) u.tokenVersion = (u.tokenVersion || 0) + 1;
  db.save();
  db.audit(ctx.user.username, 'user-update', u.username);
  return { user: publicUser(u) };
}

function remove(ctx) {
  const u = db.users.find((x) => x.id === ctx.params.id);
  if (!u) throw new HttpError(404, 'Walang ganyang user.');
  if (u.id === ctx.user.id) throw new HttpError(400, 'Hindi mo pwedeng burahin ang sarili mo.');
  if (u.role === 'admin' && activeAdmins(u.id) === 0) throw new HttpError(400, 'Hindi pwedeng burahin ang huling admin.');
  db.users.splice(db.users.indexOf(u), 1);
  db.save();
  db.audit(ctx.user.username, 'user-delete', u.username);
  return { removed: u.username };
}

// Unang takbo: gumawa ng admin. Random ang password kung walang ADMIN_PASSWORD sa .env
function seedAdmin() {
  if (db.users.length) return;
  const generated = !env.ADMIN_PASSWORD;
  const password = env.ADMIN_PASSWORD || randomPassword(14);
  db.users.push({
    id: newId(), username: env.ADMIN_USER, passwordHash: hashPassword(password), role: 'admin',
    disabled: false, tokenVersion: 0, mustChangePassword: generated, createdAt: nowIso(),
  });
  db.save();
  const line = '='.repeat(52);
  logger.info(`\n${line}\n  UNANG ADMIN ACCOUNT NA GINAWA\n  Username : ${env.ADMIN_USER}\n  Password : ${generated ? password : '(galing sa ADMIN_PASSWORD sa .env)'}\n${generated ? '  Papalitan ito pag unang login.\n' : ''}${line}`);
}

module.exports = { list, create, update, remove, seedAdmin };
