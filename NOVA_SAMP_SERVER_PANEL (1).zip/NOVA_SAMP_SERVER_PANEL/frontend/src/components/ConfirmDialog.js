// NOVA SAMP SERVER PANEL - by CAJAYON | confirm + prompt dialogs (Promise based)
import { h } from '../scripts/dom.js';
import { openSheet, sheetActions } from './Modal.js';

export function confirmDialog({ title = 'Sigurado ka ba?', message = '', confirmText = 'Oo', cancelText = 'Cancel', danger = false } = {}) {
  return new Promise((resolve) => {
    let answer = false;
    openSheet({
      title,
      onClose: () => resolve(answer),
      content: (close) => h('div', null,
        h('p', { class: 'muted', style: { whiteSpace: 'pre-line' } }, message),
        sheetActions(
          h('button', { class: 'btn', onclick: () => close() }, cancelText),
          h('button', { class: `btn ${danger ? 'danger' : 'primary'}`, onclick: () => { answer = true; close(); } }, confirmText))),
    });
  });
}

export function promptDialog({ title, label = '', value = '', placeholder = '', confirmText = 'OK', type = 'text', hint = '' } = {}) {
  return new Promise((resolve) => {
    let answer = null;
    openSheet({
      title,
      onClose: () => resolve(answer),
      content: (close) => {
        const input = h('input', { class: 'input', type, value, placeholder, autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
        const submit = () => { const v = input.value.trim(); if (!v) { input.focus(); return; } answer = v; close(); };
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
        return h('div', null,
          h('div', { class: 'field' }, label ? h('label', null, label) : null, input, hint ? h('div', { class: 'hint' }, hint) : null),
          sheetActions(h('button', { class: 'btn', onclick: () => close() }, 'Cancel'), h('button', { class: 'btn primary', onclick: submit }, confirmText)));
      },
    });
  });
}
