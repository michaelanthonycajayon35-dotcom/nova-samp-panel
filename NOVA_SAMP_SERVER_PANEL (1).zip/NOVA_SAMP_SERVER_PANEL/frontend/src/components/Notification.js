// NOVA SAMP SERVER PANEL - by CAJAYON | Banner (inline na paalala; ang toast ay nasa scripts/notifications.js)
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';

export function Banner(type, ...children) {
  const name = type === 'danger' || type === 'warn' ? 'warning' : 'info';
  return h('div', { class: `banner ${type}`, role: type === 'danger' ? 'alert' : null }, icon(name), h('div', { class: 'grow' }, ...children));
}
