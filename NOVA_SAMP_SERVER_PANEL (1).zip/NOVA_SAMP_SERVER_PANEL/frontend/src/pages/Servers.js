// NOVA SAMP SERVER PANEL - by CAJAYON | Servers
import { h, poll } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api } from '../scripts/api.js';
import { hasRole } from '../scripts/auth.js';
import { navigate } from '../scripts/navigation.js';
import { notify } from '../scripts/notifications.js';
import { refreshServers, setCurrent } from '../scripts/state.js';
import { PageHead, Empty } from '../components/Layout.js';
import { ServerCard } from '../components/ServerCard.js';
import { openSheet, sheetActions } from '../components/Modal.js';

function openCreateForm() {
  openSheet({
    title: 'Bagong server',
    content: (close) => {
      const f = {
        name: h('input', { class: 'input', placeholder: 'Hal. Nova Roleplay', maxlength: '40' }),
        type: h('select', { class: 'input' }, h('option', { value: 'samp' }, 'SA-MP (samp03svr)'), h('option', { value: 'openmp' }, 'open.mp (omp-server)')),
        host: h('input', { class: 'input', value: '127.0.0.1', autocapitalize: 'off', inputmode: 'url' }),
        port: h('input', { class: 'input', value: '7777', inputmode: 'numeric' }),
        rcon: h('input', { class: 'input', placeholder: 'Iwanang blangko = gagawa ng random', autocapitalize: 'off' }),
        path: h('input', { class: 'input', placeholder: 'Hal. /home/samp (iwanang blangko = bagong folder)', autocapitalize: 'off' }),
        exe: h('input', { class: 'input', placeholder: 'samp03svr', autocapitalize: 'off' }),
      };
      const err = h('div', { class: 'banner danger hidden' });
      const btn = h('button', { class: 'btn primary', onclick: async () => {
        err.classList.add('hidden');
        btn.classList.add('loading');
        try {
          const body = { name: f.name.value, type: f.type.value, host: f.host.value, port: f.port.value };
          if (f.rcon.value) body.rconPassword = f.rcon.value;
          if (f.path.value.trim()) body.path = f.path.value.trim();
          if (f.exe.value.trim()) body.executable = f.exe.value.trim();
          const { server } = await api.post('/api/servers', body);
          notify.ok('Nagawa na ang server.');
          await refreshServers();
          setCurrent(server.id);
          close();
          navigate(`/servers/${server.id}`);
        } catch (e) { err.classList.remove('hidden'); err.textContent = e.message; } finally { btn.classList.remove('loading'); }
      } }, 'Gumawa');
      f.type.addEventListener('change', () => { f.exe.placeholder = f.type.value === 'openmp' ? 'omp-server' : 'samp03svr'; });
      return h('div', { class: 'form-grid' },
        h('div', { class: 'field' }, h('label', null, 'Pangalan'), f.name),
        h('div', { class: 'field' }, h('label', null, 'Uri'), f.type),
        h('div', { class: 'form-grid two' },
          h('div', { class: 'field' }, h('label', null, 'Host / IP'), f.host),
          h('div', { class: 'field' }, h('label', null, 'Port'), f.port)),
        h('div', { class: 'field' }, h('label', null, 'RCON password'), f.rcon),
        h('details', null, h('summary', { class: 'muted', style: { cursor: 'pointer', padding: '6px 0' } }, 'Advanced'),
          h('div', { class: 'form-grid', style: { marginTop: '10px' } },
            h('div', { class: 'field' }, h('label', null, 'Existing na folder (optional)'), f.path,
              h('div', { class: 'hint' }, 'Kung may server ka na sa makinang ito, ilagay ang folder niya. Kung wala, gagawa ang panel ng bagong folder na may template.')),
            h('div', { class: 'field' }, h('label', null, 'Executable'), f.exe))),
        err, sheetActions(h('button', { class: 'btn', onclick: () => close() }, 'Cancel'), btn));
    },
  });
}


function openImportForm() {
  openSheet({
    title: 'I-import ang server mo',
    content: (close) => {
      const file = h('input', { class: 'input', type: 'file', accept: '.zip,.tar.gz,.tgz,.tar', style: { paddingTop: '10px' } });
      const name = h('input', { class: 'input', placeholder: 'Pangalan (optional)', maxlength: '40' });
      const type = h('select', { class: 'input' }, h('option', { value: '' }, 'Auto-detect'), h('option', { value: 'samp' }, 'SA-MP'), h('option', { value: 'openmp' }, 'open.mp'));
      const port = h('input', { class: 'input', placeholder: 'Iwanang blangko = gamitin ang nasa server.cfg', inputmode: 'numeric' });
      const bar = h('div', { class: 'bar hidden' }, h('i', { style: { width: '0%' } }));
      const err = h('div', { class: 'banner danger hidden' });
      const status = h('div', { class: 'muted hidden', style: { fontSize: '0.84rem' } });
      const btn = h('button', { class: 'btn primary', onclick: async () => {
        const f = file.files[0];
        err.classList.add('hidden');
        if (!f) { err.classList.remove('hidden'); err.textContent = 'Pumili muna ng .zip o .tar.gz na file.'; return; }
        btn.classList.add('loading');
        bar.classList.remove('hidden');
        status.classList.remove('hidden');
        status.textContent = 'Ina-upload...';
        try {
          const q = new URLSearchParams({ filename: f.name });
          if (name.value.trim()) q.set('name', name.value.trim());
          if (type.value) q.set('type', type.value);
          if (port.value.trim()) q.set('port', port.value.trim());
          const r = await api.upload(`/api/servers/import?${q}`, f, (p) => {
            bar.firstChild.style.width = Math.round(p * 100) + '%';
            if (p >= 1) status.textContent = 'Ine-extract at dine-detect ang server...';
          });
          await refreshServers();
          setCurrent(r.server.id);
          notify.ok('Na-import na ang server!');
          if (!r.found.executable) notify.info('Walang executable sa archive. I-upload ang samp03svr/omp-server sa Files.');
          close();
          navigate(`/servers/${r.server.id}`);
        } catch (e) { err.classList.remove('hidden'); err.textContent = e.message; bar.classList.add('hidden'); status.classList.add('hidden'); } finally { btn.classList.remove('loading'); }
      } }, icon('upload', 18), 'I-import');
      return h('div', { class: 'form-grid' },
        h('p', { class: 'muted', style: { fontSize: '0.88rem' } }, 'I-zip ang buong folder ng server mo (kasama ang samp03svr, server.cfg, gamemodes, plugins) at i-upload dito. Awtomatikong made-detect ang uri, executable, port at RCON password.'),
        h('div', { class: 'field' }, h('label', null, 'Archive (.zip, .tar.gz)'), file),
        h('div', { class: 'form-grid two' }, h('div', { class: 'field' }, h('label', null, 'Pangalan'), name), h('div', { class: 'field' }, h('label', null, 'Uri'), type)),
        h('div', { class: 'field' }, h('label', null, 'Palitan ang port (optional)'), port),
        bar, status, err, sheetActions(h('button', { class: 'btn', onclick: () => close() }, 'Cancel'), btn));
    },
  });
}

export async function mount(root, { query }) {
  const list = h('div', { class: 'server-grid' });
  root.replaceChildren(
    PageHead('Servers', 'Lahat ng server na hawak ng panel', hasRole('admin') ? h('div', { class: 'row' }, h('button', { class: 'btn', onclick: openImportForm }, icon('upload', 18), 'Import'), h('button', { class: 'btn primary', onclick: openCreateForm }, icon('plus'), 'Bago')) : null), list);

  let first = true;
  async function refresh() {
    let d;
    try { d = await api.get('/api/dashboard'); } catch (e) { if (first) throw e; return; }
    first = false;
    list.replaceChildren();
    if (!d.servers.length) {
      list.append(Empty({ icon: 'server', title: 'Wala pang server', text: 'I-import ang dati mong server (zip), o gumawa ng bago.', action: hasRole('admin') ? h('div', { class: 'row', style: { justifyContent: 'center' } }, h('button', { class: 'btn primary', onclick: openImportForm }, icon('upload', 18), 'Import'), h('button', { class: 'btn', onclick: openCreateForm }, icon('plus', 18), 'Bago')) : null }));
      return;
    }
    for (const s of d.servers) list.append(ServerCard(s, { onOpen: () => { setCurrent(s.id); navigate(`/servers/${s.id}`); } }));
  }
  await refresh();
  if (query.import === '1' && hasRole('admin')) { history.replaceState(null, '', '#/servers'); openImportForm(); }
  if (query.new === '1' && hasRole('admin')) { history.replaceState(null, '', '#/servers'); openCreateForm(); }
  return poll(refresh, 6000);
}
