// NOVA SAMP SERVER PANEL - by CAJAYON | session / login
import { api, setToken, getToken, setBase, setUnauthorizedHandler } from './api.js';
import { resetState } from './state.js';

export const session = { user: null };
const RANK = { viewer: 1, moderator: 2, admin: 3 };

export const hasRole = (min) => Boolean(session.user) && RANK[session.user.role] >= RANK[min];
export const isLoggedIn = () => Boolean(session.user);

export async function login(serverUrl, username, password) {
  if (serverUrl) setBase(serverUrl);
  const data = await api.post('/api/auth/login', { username, password }, { auth: false });
  setToken(data.token);
  session.user = data.user;
  return data.user;
}

export async function restore() {
  if (!getToken()) return null;
  try {
    const { user } = await api.get('/api/auth/me');
    session.user = user;
    return user;
  } catch (e) {
    if (e.status === 401) setToken(null);
    return null;
  }
}

export function updateSession(token, user) {
  if (token) setToken(token);
  session.user = user;
}

export function logout() {
  setToken(null);
  session.user = null;
  resetState();
}

export function onSessionExpired(fn) {
  setUnauthorizedHandler(() => {
    if (!session.user) return;
    logout();
    fn();
  });
}
