// NOVA SAMP SERVER PANEL - by CAJAYON | Loading
import { h } from '../scripts/dom.js';

export const Loading = (text = 'Naglo-load...') => h('div', { class: 'loading' }, h('div', { class: 'spinner' }), h('div', null, text));

export const Skeleton = (count = 3, height = 110) =>
  h('div', { class: 'stack' }, Array.from({ length: count }, () => h('div', { class: 'skeleton', style: { height: height + 'px' } })));
