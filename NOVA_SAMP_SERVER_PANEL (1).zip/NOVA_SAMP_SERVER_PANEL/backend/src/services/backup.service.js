'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Backup (tar.gz) ng folder ng server.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const db = require('../config/database');
const settings = require('../config/settings');
const { BACKUPS_DIR } = require('../config/environment');
const { HttpError, slug } = require('../utils/helpers');
const processService = require('./process.service');
const logger = require('../utils/logger');

const busy = new Set();
const NAME_RE = /^[A-Za-z0-9._-]+\.tar\.gz$/;

function dirFor(serverId) {
  const d = path.join(BACKUPS_DIR, serverId);
  fs.mkdirSync(d, { recursive: true });
  return d;
}

function list(serverId) {
  const dir = dirFor(serverId);
  return fs.readdirSync(dir)
    .filter((n) => NAME_RE.test(n))
    .map((name) => {
      const st = fs.statSync(path.join(dir, name));
      return { name, size: st.size, createdAt: st.mtime.toISOString() };
    })
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    p.stderr.on('data', (d) => { err += d.toString(); });
    p.on('error', (e) => reject(new HttpError(500, `Hindi mapatakbo ang "${cmd}": ${e.message}`)));
    p.on('close', (code) => resolve({ code, err }));
  });
}

const stamp = () => new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');

async function create(server, prefix = '') {
  if (!fs.existsSync(server.path)) throw new HttpError(400, 'Wala ang folder ng server.');
  if (busy.has(server.id)) throw new HttpError(409, 'May backup/restore na tumatakbo para sa server na ito.');
  busy.add(server.id);
  try {
    const name = `${prefix}${slug(server.name)}_${stamp()}.tar.gz`;
    const out = path.join(dirFor(server.id), name);
    const { code, err } = await run('tar', ['-czf', out, '-C', server.path, '.']);
    // code 1 = "file changed as we read it": ok lang kapag buhay ang server
    const ok = (code === 0 || code === 1) && fs.existsSync(out) && fs.statSync(out).size > 0;
    if (!ok) {
      fs.rmSync(out, { force: true });
      throw new HttpError(500, `Pumalya ang backup: ${err.trim().slice(0, 200) || 'code ' + code}`);
    }
    prune(server.id);
    const st = fs.statSync(out);
    return { name, size: st.size, createdAt: st.mtime.toISOString() };
  } finally {
    busy.delete(server.id);
  }
}

function prune(serverId) {
  const keep = settings.get().backupRetention;
  for (const old of list(serverId).slice(keep)) fs.rmSync(path.join(dirFor(serverId), old.name), { force: true });
}

function resolveBackup(serverId, name) {
  if (!NAME_RE.test(String(name))) throw new HttpError(400, 'Mali ang pangalan ng backup.');
  const file = path.join(dirFor(serverId), name);
  if (!fs.existsSync(file)) throw new HttpError(404, 'Walang ganyang backup.');
  return { file, size: fs.statSync(file).size, name };
}

function remove(serverId, name) {
  fs.rmSync(resolveBackup(serverId, name).file);
  return { removed: name };
}

async function restore(server, name) {
  const { file } = resolveBackup(server.id, name);
  if (processService.isRunning(server.id)) throw new HttpError(409, 'Patayin muna ang server bago mag-restore.');
  await create(server, 'pre-restore_'); // safety backup bago i-overwrite
  if (busy.has(server.id)) throw new HttpError(409, 'May ibang operasyon na tumatakbo.');
  busy.add(server.id);
  try {
    const { code, err } = await run('tar', ['-xzf', file, '-C', server.path, '--no-same-owner']);
    if (code !== 0) throw new HttpError(500, `Pumalya ang restore: ${err.trim().slice(0, 200)}`);
  } finally {
    busy.delete(server.id);
  }
  return { restored: name };
}

// Auto backup: tinitingnan kada oras kung kailangan na.
function startScheduler() {
  const timer = setInterval(async () => {
    const hours = settings.get().autoBackupHours;
    if (!hours) return;
    for (const server of db.servers) {
      try {
        const newest = list(server.id)[0];
        const age = newest ? Date.now() - new Date(newest.createdAt).getTime() : Infinity;
        if (age >= hours * 3_600_000) {
          await create(server, 'auto_');
          logger.info(`Auto backup done: ${server.name}`);
        }
      } catch (e) { logger.warn(`Auto backup failed for ${server.name}: ${e.message}`); }
    }
  }, 3_600_000);
  timer.unref();
}

module.exports = { list, create, remove, restore, resolveBackup, startScheduler };
