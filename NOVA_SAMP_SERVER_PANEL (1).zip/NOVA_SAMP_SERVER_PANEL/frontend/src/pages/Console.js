// NOVA SAMP SERVER PANEL - by CAJAYON | Console
import { h, poll } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api } from '../scripts/api.js';
import { hasRole } from '../scripts/auth.js';
import { notify } from '../scripts/notifications.js';
import { ensureServers, current } from '../scripts/state.js';
import { clock } from '../scripts/format.js';
import { PageHead, NoServer } from '../components/Layout.js';

const MAX_NODES = 600;

function lineClass(text) {
  if (text.startsWith('[panel]')) return 'sys';
  if (text.startsWith('> ')) return 'cmd';
  if (/error|fail|cannot|crash|fatal|invalid/i.test(text)) return 'err';
  if (/warn/i.test(text)) return 'warn';
  return '';
}

export async function mount(root) {
  await ensureServers();
  const s = current();
  if (!s) { root.replaceChildren(PageHead('Console'), NoServer()); return; }
  const base = `/api/servers/${s.id}`;
  const canSend = hasRole('moderator');

  let mode = 'live';
  let since = 0;
  const term = h('div', { class: 'terminal', role: 'log', 'aria-live': 'off', tabindex: '0' });
  const statusBox = h('span', null);
  const liveTab = h('button', { class: 'tab active', onclick: () => setMode('live') }, 'Live');
  const logTab = h('button', { class: 'tab', onclick: () => setMode('log') }, 'server_log.txt');
  const input = h('input', { class: 'input', placeholder: 'Mag-type ng command...', autocapitalize: 'off', autocomplete: 'off', spellcheck: 'false', enterkeyhint: 'send' });
  const sendBtn = h('button', { class: 'btn primary icon', 'aria-label': 'Ipadala', onclick: send }, icon('send'));
  const cmdRow = h('div', { class: 'cmd-row' }, input, sendBtn);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });

  const atBottom = () => term.scrollHeight - term.scrollTop - term.clientHeight < 60;
  const toBottom = () => { term.scrollTop = term.scrollHeight; };

  function addLine(text, t) {
    const cls = lineClass(text);
    term.append(h('span', { class: `ln ${cls}` }, t ? h('span', { class: 't' }, clock(t)) : null, text));
  }

  async function pollLive() {
    const stick = atBottom();
    const r = await api.get(`${base}/console?since=${since}`);
    since = r.last;
    for (const l of r.lines) addLine(l.text, l.t);
    while (term.childElementCount > MAX_NODES) term.firstElementChild.remove();
    if (r.lines.length && stick) toBottom();
    statusBox.replaceChildren(h('span', { class: `chip ${r.running ? 'ok' : ''}` }, h('i', { class: `dot ${r.running ? 'ok' : ''}` }), r.running ? 'Tumatakbo' : 'Hindi pinapatakbo ng panel'));
    cmdRow.classList.toggle('hidden', !canSend || mode !== 'live');
  }

  async function pollLog() {
    const r = await api.get(`${base}/console/log?lines=300`);
    const stick = atBottom();
    term.replaceChildren();
    if (!r.file) addLine('[panel] Wala pang server_log.txt sa folder ng server.');
    for (const l of r.lines) addLine(l);
    if (stick) toBottom();
  }

  let stop = () => {};
  function setMode(m) {
    mode = m;
    liveTab.classList.toggle('active', m === 'live');
    logTab.classList.toggle('active', m === 'log');
    term.replaceChildren();
    since = 0;
    cmdRow.classList.toggle('hidden', !canSend || m !== 'live');
    stop();
    stop = m === 'live' ? poll(pollLive, 1500) : poll(pollLog, 4000);
    setTimeout(toBottom, 150);
  }

  async function send() {
    const cmd = input.value.trim();
    if (!cmd) return;
    sendBtn.classList.add('loading');
    try {
      await api.post(`${base}/console/command`, { command: cmd });
      input.value = '';
      await pollLive();
      toBottom();
    } catch (e) { notify.error(e.message); } finally { sendBtn.classList.remove('loading'); }
  }

  async function clearConsole() {
    try { await api.post(`${base}/console/clear`); term.replaceChildren(); } catch (e) { notify.error(e.message); }
  }

  root.replaceChildren(
    PageHead('Console', s.name, statusBox, canSend ? h('button', { class: 'btn icon ghost', 'aria-label': 'Linisin', onclick: clearConsole }, icon('trash')) : null),
    h('div', { class: 'tabs', style: { marginBottom: '12px' } }, liveTab, logTab),
    term, cmdRow);
  setMode('live');
  return () => stop();
}
