'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// CPU / RAM / disk ng makina kung saan tumatakbo ang panel.
const os = require('os');
const fs = require('fs');
const { STORAGE_DIR } = require('../config/environment');

const history = [];
const MAX_POINTS = 60;

function cpuTimes() {
  let idle = 0;
  let total = 0;
  for (const c of os.cpus()) {
    for (const k of Object.keys(c.times)) total += c.times[k];
    idle += c.times.idle;
  }
  return { idle, total };
}

let prev = cpuTimes();

function sample() {
  const cur = cpuTimes();
  const dTotal = cur.total - prev.total;
  const dIdle = cur.idle - prev.idle;
  prev = cur;
  const cpu = dTotal > 0 ? Math.round((1 - dIdle / dTotal) * 100) : 0;
  const mem = Math.round((1 - os.freemem() / os.totalmem()) * 100);
  history.push({ t: Date.now(), cpu: Math.max(0, Math.min(100, cpu)), mem });
  if (history.length > MAX_POINTS) history.shift();
}

function start() {
  setTimeout(sample, 1000).unref();
  setInterval(sample, 5000).unref();
}

function disk() {
  try {
    const s = fs.statfsSync(STORAGE_DIR);
    const total = s.blocks * s.bsize;
    const free = s.bavail * s.bsize;
    return { total, used: total - free, percent: total ? Math.round(((total - free) / total) * 100) : 0 };
  } catch { return null; }
}

function snapshot() {
  const last = history[history.length - 1];
  const total = os.totalmem();
  const free = os.freemem();
  return {
    hostname: os.hostname(),
    platform: `${os.type()} ${os.release()}`,
    cpuCores: os.cpus().length,
    cpuPercent: last ? last.cpu : 0,
    load: os.loadavg().map((n) => Math.round(n * 100) / 100),
    memory: { total, used: total - free, percent: Math.round(((total - free) / total) * 100) },
    disk: disk(),
    uptimeSec: Math.floor(os.uptime()),
    history: history.slice(),
  };
}

module.exports = { start, snapshot, sample };
