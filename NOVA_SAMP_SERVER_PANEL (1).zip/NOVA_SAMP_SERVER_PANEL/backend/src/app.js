'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Maliit na HTTP framework (router + static + CORS). Walang express na kailangan.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { FRONTEND_DIR, CORS_ORIGINS, TRUST_PROXY } = require('./config/environment');
const { handleError } = require('./middleware/error.middleware');
const { limiter } = require('./middleware/rate-limit.middleware');
const { HttpError } = require('./utils/helpers');
const { safeJoin } = require('./utils/security');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8', '.woff2': 'font/woff2',
};

function createRouter() {
  const routes = [];
  const add = (method) => (pattern, ...handlers) => {
    let opts = {};
    if (handlers.length && typeof handlers[0] !== 'function') opts = handlers.shift();
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([A-Za-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
    routes.push({ method, re, keys, handlers, opts });
  };
  return {
    routes,
    get: add('GET'), post: add('POST'), put: add('PUT'), patch: add('PATCH'), delete: add('DELETE'),
    match(method, pathname) {
      let pathMatched = false;
      for (const r of routes) {
        const m = r.re.exec(pathname);
        if (!m) continue;
        pathMatched = true;
        if (r.method !== method) continue;
        const params = {};
        r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
        return { route: r, params };
      }
      return { route: null, pathMatched };
    },
  };
}

function readJson(req, limit) {
  return new Promise((resolve, reject) => {
    const type = req.headers['content-type'] || '';
    if (!type.includes('json')) { req.resume(); return resolve({}); }
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'Masyadong malaki ang request.')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!size) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(new HttpError(400, 'Hindi valid na JSON.')); }
    });
    req.on('error', reject);
  });
}

function clientIp(req) {
  if (TRUST_PROXY && req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',')[0].trim();
  return (req.socket.remoteAddress || '').replace('::ffff:', '');
}

function setCors(req, res) {
  const origin = req.headers.origin;
  if (CORS_ORIGINS.includes('*')) res.setHeader('Access-Control-Allow-Origin', '*');
  else if (origin && CORS_ORIGINS.includes(origin)) { res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Vary', 'Origin'); }
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization,Content-Type');
  res.setHeader('Access-Control-Max-Age', '600');
}

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel.endsWith('/')) rel += 'index.html';
  let file;
  try { file = safeJoin(FRONTEND_DIR, rel); } catch { res.writeHead(403); return res.end('Forbidden'); }
  let st;
  try { st = fs.statSync(file); } catch { st = null; }
  if (!st || !st.isFile()) {
    if (path.extname(rel)) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    file = path.join(FRONTEND_DIR, 'index.html');
    try { st = fs.statSync(file); } catch { res.writeHead(404); return res.end('Walang frontend'); }
  }
  res.writeHead(200, {
    'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
    'Content-Length': st.size,
    'Cache-Control': 'no-cache',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src *; base-uri 'none'; form-action 'self'",
  });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

function createApp(registerRoutes) {
  const router = createRouter();
  registerRoutes(router);
  const globalLimit = limiter({ windowMs: 60_000, max: 600, name: 'global' });

  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const ctx = {
      req, res, params: {}, query: Object.fromEntries(url.searchParams), body: {}, user: null, ip: clientIp(req),
      send(status, data) {
        const body = JSON.stringify(data);
        res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store' });
        res.end(body);
      },
    };
    setCors(req, res);
    try {
      if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
      if (!url.pathname.startsWith('/api/')) {
        if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Method not allowed');
        return serveStatic(req, res, url.pathname);
      }
      globalLimit(ctx);
      const { route, params, pathMatched } = router.match(req.method, url.pathname);
      if (!route) throw new HttpError(pathMatched ? 405 : 404, pathMatched ? 'Method not allowed' : 'Walang ganyang endpoint.');
      ctx.params = params;
      if (!route.opts.raw && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
        ctx.body = await readJson(req, route.opts.limit || 1024 * 1024);
      }
      let result;
      for (const h of route.handlers) result = await h(ctx);
      if (res.headersSent || res.writableEnded) return;
      if (result === undefined) { res.writeHead(204); return res.end(); }
      ctx.send(200, result);
    } catch (err) {
      handleError(err, ctx);
    }
  });
}

module.exports = { createApp, createRouter };
