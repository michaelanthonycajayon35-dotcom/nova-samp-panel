'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const settings = require('../config/settings');
const update = require('../services/update.service');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');
const { VERSION } = require('../config/environment');

module.exports = (router) => {
  router.get('/api/system/health', () => ({ ok: true }));
  // Walang login: para sa login screen (pangalan ng panel) at pag-check ng URL sa APK.
  router.get('/api/system/public', () => ({ name: settings.get().panelName, version: VERSION, app: 'nova-samp-panel' }));
  router.get('/api/system/info', authenticate, requireRole('viewer'), () => update.info());
};
