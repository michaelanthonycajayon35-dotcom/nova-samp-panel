'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const db = require('../config/database');
const serverService = require('../services/server.service');
const processService = require('../services/process.service');
const rconService = require('../services/rcon.service');
const importService = require('../services/import.service');
const v = require('../utils/validation');

const withStatus = (s) => ({ ...serverService.publicServer(s), process: processService.status(s.id) });

const list = () => ({ servers: serverService.list().map(withStatus) });

async function details(ctx) {
  const s = serverService.get(ctx.params.id);
  const query = await rconService.queryInfo(s);
  return { server: withStatus(s), query, executableFound: Boolean(processService.exePath(s)) };
}

function create(ctx) {
  const s = serverService.create(ctx.body);
  db.audit(ctx.user.username, 'server-create', s.name);
  return { server: withStatus(s) };
}

function update(ctx) {
  const s = serverService.update(ctx.params.id, ctx.body);
  db.audit(ctx.user.username, 'server-update', s.name);
  return { server: withStatus(s) };
}

async function remove(ctx) {
  const s = serverService.get(ctx.params.id);
  const result = await serverService.remove(s.id, ctx.query.deleteFiles === 'true');
  db.audit(ctx.user.username, 'server-delete', s.name);
  return result;
}

async function start(ctx) {
  const s = serverService.get(ctx.params.id);
  await processService.start(s);
  db.audit(ctx.user.username, 'server-start', s.name);
  return { server: withStatus(s) };
}

async function stop(ctx) {
  const s = serverService.get(ctx.params.id);
  await processService.stop(s);
  db.audit(ctx.user.username, 'server-stop', s.name);
  return { server: withStatus(s) };
}

async function restart(ctx) {
  const s = serverService.get(ctx.params.id);
  await processService.restart(s);
  db.audit(ctx.user.username, 'server-restart', s.name);
  return { server: withStatus(s) };
}

const getConfig = (ctx) => serverService.readConfig(serverService.get(ctx.params.id));

function putConfig(ctx) {
  const s = serverService.get(ctx.params.id);
  const result = serverService.saveConfig(s, ctx.body.content);
  db.audit(ctx.user.username, 'config-save', s.name);
  return result;
}

async function importServer(ctx) {
  const filename = v.oneLine(ctx.query.filename, 'filename', 200);
  const name = v.oneLine(ctx.query.name || filename.replace(/\.(zip|tar\.gz|tgz|tar)$/i, ''), 'name', 40);
  const { server, found } = await importService.importArchive({
    req: ctx.req, filename, name, type: ctx.query.type || undefined, host: ctx.query.host || undefined, port: ctx.query.port || undefined,
  });
  db.audit(ctx.user.username, 'server-import', server.name);
  return { server: withStatus(server), found };
}

module.exports = { importServer, list, details, create, update, remove, start, stop, restart, getConfig, putConfig, withStatus };
