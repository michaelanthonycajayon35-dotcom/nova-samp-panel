// NOVA SAMP SERVER PANEL - by CAJAYON | toast notifications
import { h } from './dom.js';
import { icon } from './icons.js';

let host = null;
function container() {
  if (!host || !host.isConnected) {
    host = h('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' });
    document.body.append(host);
  }
  return host;
}

function show(message, type = 'info', ms = 3800) {
  const el = h('div', { class: `toast ${type}` }, icon(type === 'ok' ? 'check' : type === 'error' ? 'warning' : 'info'), h('div', { class: 'grow' }, String(message)));
  container().append(el);
  const close = () => { el.classList.add('leaving'); setTimeout(() => el.remove(), 260); };
  el.addEventListener('click', close);
  setTimeout(close, type === 'error' ? Math.max(ms, 5500) : ms);
  while (host.children.length > 3) host.firstChild.remove();
}

export const notify = {
  ok: (m) => show(m, 'ok'),
  error: (m) => show(m, 'error'),
  info: (m) => show(m, 'info'),
};
