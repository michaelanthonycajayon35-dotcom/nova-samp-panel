'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// File manager na nakakulong sa folder ng server.
const fs = require('fs');
const path = require('path');
const { safeJoin, safeName } = require('../utils/security');
const { HttpError } = require('../utils/helpers');

const MAX_TEXT = 1024 * 1024; // 1 MB ang pinakamalaking text na pwedeng i-edit

const rel = (root, target) => path.relative(root, target).split(path.sep).join('/');

function statOrThrow(p) {
  try { return fs.statSync(p); } catch { throw new HttpError(404, 'Hindi nahanap ang file/folder.'); }
}

function list(server, relPath = '') {
  const root = path.resolve(server.path);
  const dir = safeJoin(root, relPath);
  if (!statOrThrow(dir).isDirectory()) throw new HttpError(400, 'Hindi ito folder.');
  const entries = [];
  for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
    let st;
    try { st = fs.statSync(path.join(dir, d.name)); } catch { continue; }
    entries.push({ name: d.name, type: st.isDirectory() ? 'dir' : 'file', size: st.isDirectory() ? null : st.size, mtime: st.mtime.toISOString() });
  }
  entries.sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'dir' ? -1 : 1));
  const here = rel(root, dir);
  return { path: here, parent: here ? rel(root, path.dirname(dir)) : null, entries };
}

function readText(server, relPath) {
  const root = path.resolve(server.path);
  const file = safeJoin(root, relPath);
  const st = statOrThrow(file);
  if (!st.isFile()) throw new HttpError(400, 'Hindi ito file.');
  if (st.size > MAX_TEXT) throw new HttpError(413, 'Masyadong malaki para i-edit (max 1 MB). I-download na lang.');
  const buf = fs.readFileSync(file);
  if (buf.includes(0)) throw new HttpError(415, 'Binary file ito (hindi pwedeng i-edit bilang text).');
  return { path: rel(root, file), content: buf.toString('utf8'), size: st.size, mtime: st.mtime.toISOString() };
}

function writeText(server, relPath, content) {
  if (typeof content !== 'string' || Buffer.byteLength(content) > MAX_TEXT) throw new HttpError(400, 'Masyadong malaki ang content (max 1 MB).');
  const root = path.resolve(server.path);
  const file = safeJoin(root, relPath);
  if (file === root) throw new HttpError(400, 'Mali ang path.');
  if (fs.existsSync(file) && fs.statSync(file).isDirectory()) throw new HttpError(400, 'Folder ito, hindi file.');
  if (!fs.existsSync(path.dirname(file))) throw new HttpError(400, 'Walang parent folder.');
  fs.writeFileSync(file, content);
  return { path: rel(root, file) };
}

function mkdir(server, relPath, name) {
  const root = path.resolve(server.path);
  const parent = safeJoin(root, relPath);
  const target = safeJoin(root, rel(root, path.join(parent, safeName(name))));
  if (fs.existsSync(target)) throw new HttpError(409, 'May ganyang pangalan na.');
  fs.mkdirSync(target);
  return { path: rel(root, target) };
}

function remove(server, relPath) {
  const root = path.resolve(server.path);
  const target = safeJoin(root, relPath);
  if (target === root) throw new HttpError(400, 'Bawal burahin ang mismong folder ng server.');
  statOrThrow(target);
  fs.rmSync(target, { recursive: true, force: true });
  return { removed: rel(root, target) };
}

function rename(server, relPath, newName) {
  const root = path.resolve(server.path);
  const from = safeJoin(root, relPath);
  if (from === root) throw new HttpError(400, 'Bawal i-rename ang mismong folder ng server.');
  statOrThrow(from);
  const to = safeJoin(root, rel(root, path.join(path.dirname(from), safeName(newName))));
  if (fs.existsSync(to)) throw new HttpError(409, 'May ganyang pangalan na.');
  fs.renameSync(from, to);
  return { path: rel(root, to) };
}

// Raw upload (stream) para hindi mapuno ang memory sa malalaking file.
function upload(server, dirRel, name, req, maxBytes) {
  const root = path.resolve(server.path);
  const dir = safeJoin(root, dirRel);
  if (!statOrThrow(dir).isDirectory()) throw new HttpError(400, 'Hindi folder ang destination.');
  const target = safeJoin(root, rel(root, path.join(dir, safeName(name))));
  const tmp = `${target}.upload-${process.pid}`;
  return new Promise((resolve, reject) => {
    const out = fs.createWriteStream(tmp);
    let size = 0;
    let failed = false;
    const fail = (err) => {
      if (failed) return;
      failed = true;
      out.destroy();
      fs.rm(tmp, { force: true }, () => reject(err));
    };
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > maxBytes) { fail(new HttpError(413, `Masyadong malaki ang file (max ${Math.round(maxBytes / 1048576)} MB).`)); req.unpipe(out); req.resume(); }
    });
    req.on('error', fail);
    out.on('error', fail);
    out.on('finish', () => {
      if (failed) return;
      try { fs.renameSync(tmp, target); } catch (e) { return fail(e); }
      resolve({ path: rel(root, target), size });
    });
    req.pipe(out);
  });
}

function resolveFile(server, relPath) {
  const root = path.resolve(server.path);
  const file = safeJoin(root, relPath);
  const st = statOrThrow(file);
  if (!st.isFile()) throw new HttpError(400, 'Hindi ito file.');
  return { file, size: st.size, name: path.basename(file) };
}

module.exports = { list, readText, writeText, mkdir, remove, rename, upload, resolveFile };
