// NOVA SAMP SERVER PANEL - by CAJAYON | hash router
const routes = [];
let cleanup = null;
let token = 0;
let hooks = { before: () => true, render: () => {}, error: () => {} };

export function defineRoute(pattern, loader, meta = {}) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([A-Za-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ re, keys, loader, meta });
}

export function setHooks(h) { hooks = { ...hooks, ...h }; }

export function parseHash() {
  const raw = location.hash.replace(/^#/, '') || '/';
  const [path, qs] = raw.split('?');
  return { path: path.startsWith('/') ? path : '/' + path, query: Object.fromEntries(new URLSearchParams(qs || '')) };
}

export const navigate = (path) => { if (location.hash === '#' + path) resolve(); else location.hash = path; };
export const replace = (path) => { history.replaceState(null, '', '#' + path); resolve(); };

export async function resolve() {
  const my = ++token;
  const { path, query } = parseHash();
  if (typeof cleanup === 'function') { try { cleanup(); } catch { /* ignore */ } }
  cleanup = null;
  let found = null;
  for (const r of routes) {
    const m = r.re.exec(path);
    if (m) { found = { r, params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) }; break; }
  }
  const redirect = hooks.before(found ? found.r.meta : { notFound: true }, path);
  if (redirect !== true) { if (typeof redirect === 'string') replace(redirect); return; }
  const route = found ? found.r : null;
  try {
    const root = hooks.render(route ? route.meta : { notFound: true }, path);
    if (!route) { hooks.error(root, new Error('404'), true); return; }
    const mod = await route.loader();
    if (my !== token) return;
    const result = await mod.mount(root, { params: found.params, query, path });
    if (my !== token) { if (typeof result === 'function') result(); return; }
    cleanup = result;
  } catch (e) {
    if (my !== token) return;
    hooks.error(hooks.render(route ? route.meta : {}, path), e, false);
  }
}

export function start() {
  window.addEventListener('hashchange', resolve);
  resolve();
}
