// NOVA SAMP SERVER PANEL - by CAJAYON | app shell, routes, session
import { h, clear } from './scripts/dom.js';
import { api } from './scripts/api.js';
import { session, restore, logout, hasRole, updateSession, onSessionExpired } from './scripts/auth.js';
import { state, refreshServers, onState } from './scripts/state.js';
import { defineRoute, setHooks, start, navigate, resolve, parseHash } from './scripts/navigation.js';
import { notify } from './scripts/notifications.js';
import { Topbar } from './components/Topbar.js';
import { Sidebar } from './components/Sidebar.js';
import { openSheet, sheetActions } from './components/Modal.js';
import { Loading } from './components/Loading.js';
import { renderError } from './pages/ErrorPage.js';

const root = document.getElementById('app');
let shell = null; // { el, main, nav, top }
let panelName = 'NOVA Panel';
let lastServer = null;

// Mga route: lazy-load ang bawat page
defineRoute('/login', () => import('./pages/Login.js'), { public: true, title: 'Login' });
defineRoute('/', () => import('./pages/Dashboard.js'), { title: 'Dashboard' });
defineRoute('/servers', () => import('./pages/Servers.js'), { title: 'Servers' });
defineRoute('/servers/:id', () => import('./pages/ServerDetails.js'), { title: 'Server' });
defineRoute('/console', () => import('./pages/Console.js'), { title: 'Console', scoped: true });
defineRoute('/rcon', () => import('./pages/RCON.js'), { title: 'RCON', scoped: true, role: 'moderator' });
defineRoute('/players', () => import('./pages/Players.js'), { title: 'Players', scoped: true });
defineRoute('/files', () => import('./pages/FileManager.js'), { title: 'Files', scoped: true, role: 'admin' });
defineRoute('/backups', () => import('./pages/Backups.js'), { title: 'Backups', scoped: true, role: 'moderator' });
defineRoute('/users', () => import('./pages/Users.js'), { title: 'Users', role: 'admin' });
defineRoute('/settings', () => import('./pages/Settings.js'), { title: 'Settings' });

function destroyShell() {
  if (shell) { if (shell.top.destroy) shell.top.destroy(); shell.el.remove(); shell = null; }
}

function buildShell() {
  const top = Topbar(panelName);
  const nav = Sidebar({ panelName, onLogout: doLogout });
  const main = h('main', { class: 'main', id: 'main' });
  const el = h('div', { class: 'shell' }, top, main, nav);
  clear(root);
  root.append(el);
  shell = { el, main, nav, top };
}

function doLogout() {
  logout();
  destroyShell();
  navigate('/login');
}

export function setPanelName(name) {
  panelName = name || panelName;
  if (shell) shell.top.setName(panelName);
}

setHooks({
  before(meta) {
    if (meta.public) return session.user ? '/' : true;
    if (meta.notFound && !session.user) return '/login';
    if (!session.user) return '/login';
    if (meta.role && !hasRole(meta.role)) { notify.error('Wala kang permiso sa page na iyan.'); return '/'; }
    return true;
  },
  render(meta, path) {
    document.title = `${meta.title ? meta.title + ' · ' : ''}${panelName}`;
    if (meta.public) { destroyShell(); clear(root); return root; }
    if (!shell) buildShell();
    clear(shell.main);
    shell.main.append(Loading());
    shell.nav.update(path);
    window.scrollTo(0, 0);
    return shell.main;
  },
  error(target, err, notFound) { renderError(target, err, notFound); },
});

// Kapag nagpalit ng server, i-reload ang mga page na nakadepende dito
onState((s) => {
  if (s.currentId === lastServer) return;
  lastServer = s.currentId;
  const { path } = parseHash();
  if (session.user && ['/console', '/rcon', '/players', '/files', '/backups'].includes(path)) resolve();
});

onSessionExpired(() => {
  notify.error('Expired na ang session. Mag-login ulit.');
  destroyShell();
  navigate('/login');
});

function forcePasswordChange() {
  return new Promise((resolveDone) => {
    openSheet({
      title: 'Palitan ang password',
      dismissible: false,
      content: (close) => {
        const cur = h('input', { class: 'input', type: 'password', autocomplete: 'current-password', placeholder: 'Kasalukuyang password' });
        const next = h('input', { class: 'input', type: 'password', autocomplete: 'new-password', placeholder: 'Bagong password (min. 8)' });
        const err = h('div', { class: 'hint', style: { color: 'var(--danger)', minHeight: '18px' } });
        const btn = h('button', { class: 'btn primary', onclick: async () => {
          btn.classList.add('loading');
          try {
            const r = await api.post('/api/auth/password', { current: cur.value, next: next.value });
            updateSession(r.token, r.user);
            notify.ok('Napalitan na ang password.');
            close();
            resolveDone();
          } catch (e) { err.textContent = e.message; } finally { btn.classList.remove('loading'); }
        } }, 'I-save');
        return h('div', { class: 'stack' },
          h('p', { class: 'muted' }, 'Random lang ang password na ginawa ng system. Maglagay ng sarili mo bago magpatuloy.'),
          h('div', { class: 'field' }, h('label', null, 'Kasalukuyang password'), cur),
          h('div', { class: 'field' }, h('label', null, 'Bagong password'), next), err, sheetActions(btn));
      },
    });
  });
}

async function afterLogin() {
  if (session.user && session.user.mustChangePassword) await forcePasswordChange();
  try { const pub = await api.get('/api/system/public', { auth: false }); setPanelName(pub.name); } catch { /* ok */ }
  try { await refreshServers(); } catch { /* ok lang; babalik sa page */ }
  lastServer = state.currentId;
  navigate('/');
}

window.addEventListener('nova:login', afterLogin);

export async function boot() {
  clear(root);
  root.append(Loading('Sinisimulan ang NOVA...'));
  const user = await restore();
  if (user) {
    try { const pub = await api.get('/api/system/public', { auth: false }); panelName = pub.name || panelName; } catch { /* ok */ }
    if (user.mustChangePassword) await forcePasswordChange();
    try { await refreshServers(); } catch { /* ok */ }
    lastServer = state.currentId;
  }
  if (!location.hash || location.hash === '#') history.replaceState(null, '', user ? '#/' : '#/login');
  start();
}

