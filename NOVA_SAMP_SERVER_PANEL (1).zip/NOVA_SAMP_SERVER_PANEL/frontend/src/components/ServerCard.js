// NOVA SAMP SERVER PANEL - by CAJAYON | ServerCard
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { typeLabel } from '../scripts/format.js';

export function serverStatus(s) {
  if (s.query && s.query.online) return { label: 'Online', tone: 'ok' };
  if (s.process && s.process.running) return { label: 'Nagsisimula...', tone: 'warn' };
  return { label: 'Offline', tone: 'danger' };
}

export function StatusChip(s) {
  const st = serverStatus(s);
  return h('span', { class: `chip ${st.tone}` }, h('i', { class: `dot ${st.tone}` }), st.label);
}

export function ServerCard(s, { onOpen, actions } = {}) {
  const q = s.query || {};
  const pct = q.maxPlayers ? Math.round((q.players / q.maxPlayers) * 100) : 0;
  return h('div', { class: 'card clickable server-card', role: 'button', tabindex: '0', onclick: () => onOpen && onOpen(s),
    onkeydown: (e) => { if (e.key === 'Enter') onOpen && onOpen(s); } },
    h('div', { class: 'row between' },
      h('div', { class: 'grow' }, h('div', { class: 'name ellipsis' }, s.name), h('div', { class: 'addr' }, `${s.host}:${s.port}`)),
      StatusChip(s)),
    h('div', { class: 'nums' },
      h('div', null, h('b', null, `${q.players ?? 0}`), ` / ${q.maxPlayers ?? 0} players`),
      h('div', null, h('b', null, q.online && q.ping != null ? `${q.ping}` : '-'), ' ms'),
      h('span', { class: 'chip primary' }, typeLabel(s.type))),
    h('div', { class: 'bar' }, h('i', { style: { width: Math.max(2, pct) + '%' } })),
    actions ? h('div', { class: 'row', onclick: (e) => e.stopPropagation() }, actions) : null,
    q.online && q.hostname ? h('div', { class: 'muted ellipsis', style: { fontSize: '0.8rem' } }, icon('globe', 14), ' ', q.hostname) : null);
}
