'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const c = require('../controllers/backups.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');

const mod = requireRole('moderator');
const admin = requireRole('admin');

module.exports = (router) => {
  router.get('/api/servers/:id/backups', authenticate, mod, c.list);
  router.post('/api/servers/:id/backups', authenticate, mod, c.create);
  router.get('/api/servers/:id/backups/:name/link', authenticate, admin, c.link);
  router.post('/api/servers/:id/backups/:name/restore', authenticate, admin, c.restore);
  router.delete('/api/servers/:id/backups/:name', authenticate, admin, c.remove);
};
