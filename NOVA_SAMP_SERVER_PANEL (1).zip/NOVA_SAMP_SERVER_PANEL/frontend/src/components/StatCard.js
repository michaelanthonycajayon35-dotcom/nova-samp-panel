// NOVA SAMP SERVER PANEL - by CAJAYON | StatCard
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';

export function StatCard({ icon: ic, label, value, unit, sub, percent }) {
  const tone = percent >= 90 ? 'danger' : percent >= 75 ? 'warn' : '';
  return h('div', { class: 'stat' },
    h('div', { class: 'label' }, icon(ic), label),
    h('div', { class: 'value' }, String(value), unit ? h('small', null, unit) : null),
    sub ? h('div', { class: 'sub' }, sub) : null,
    percent !== undefined && percent !== null ? h('div', { class: `bar ${tone}` }, h('i', { style: { width: Math.max(2, Math.min(100, percent)) + '%' } })) : null);
}
