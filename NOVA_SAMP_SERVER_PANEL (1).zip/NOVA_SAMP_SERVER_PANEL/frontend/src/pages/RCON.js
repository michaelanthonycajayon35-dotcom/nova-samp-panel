// NOVA SAMP SERVER PANEL - by CAJAYON | RCON
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { api } from '../scripts/api.js';
import { notify } from '../scripts/notifications.js';
import { ensureServers, current } from '../scripts/state.js';
import { clock } from '../scripts/format.js';
import { PageHead, NoServer } from '../components/Layout.js';
import { Banner } from '../components/Notification.js';
import { confirmDialog } from '../components/ConfirmDialog.js';

// [label, command, kailangan ng argument?, delikado?]
const QUICK = [
  ['players', 'players'], ['cmdlist', 'cmdlist'], ['varlist', 'varlist'], ['say…', 'say ', true], ['kick…', 'kick ', true], ['ban…', 'ban ', true],
  ['unbanip…', 'unbanip ', true], ['reloadbans', 'reloadbans'], ['reloadlog', 'reloadlog'], ['loadfs…', 'loadfs ', true], ['reloadfs…', 'reloadfs ', true],
  ['unloadfs…', 'unloadfs ', true], ['hostname…', 'hostname ', true], ['mapname…', 'mapname ', true], ['weburl…', 'weburl ', true],
  ['gmx (restart GM)', 'gmx', false, true], ['exit (patayin)', 'exit', false, true],
];

const hKey = (id) => `nova_rcon_hist_${id}`;
const loadHist = (id) => { try { return JSON.parse(localStorage.getItem(hKey(id)) || '[]'); } catch { return []; } };
const saveHist = (id, a) => { try { localStorage.setItem(hKey(id), JSON.stringify(a.slice(0, 30))); } catch { /* ok */ } };

export async function mount(root) {
  await ensureServers();
  const s = current();
  if (!s) { root.replaceChildren(PageHead('RCON'), NoServer()); return; }
  let history = loadHist(s.id);
  let hIdx = -1;

  const out = h('div', { class: 'terminal', style: { height: 'min(46vh, 420px)' }, role: 'log' });
  const input = h('input', { class: 'input', placeholder: 'Hal. say Hello sa lahat', autocapitalize: 'off', autocomplete: 'off', spellcheck: 'false', enterkeyhint: 'send' });
  const sendBtn = h('button', { class: 'btn primary icon', 'aria-label': 'Ipadala', onclick: () => run() }, icon('send'));
  const line = (cls, text) => { out.append(h('span', { class: `ln ${cls}` }, h('span', { class: 't' }, clock(Date.now())), text)); out.scrollTop = out.scrollHeight; };

  async function run(cmdArg, dangerous) {
    const cmd = (cmdArg ?? input.value).trim();
    if (!cmd) return;
    if (dangerous || /^(exit|gmx)\b/i.test(cmd)) {
      const ok = await confirmDialog({ title: `Ipadala ang "${cmd}"?`, message: /^exit/i.test(cmd) ? 'Papatayin nito ang server.' : 'Ire-restart nito ang gamemode at madidiskonekta ang mga player.', danger: true, confirmText: 'Ipadala' });
      if (!ok) return;
    }
    line('in', `> ${cmd}`);
    input.value = '';
    history = [cmd, ...history.filter((x) => x !== cmd)];
    saveHist(s.id, history);
    hIdx = -1;
    sendBtn.classList.add('loading');
    try {
      const r = await api.post(`/api/servers/${s.id}/rcon`, { command: cmd });
      if (!r.lines.length) line('sys', '(walang sagot — normal ito sa ibang command)');
      for (const l of r.lines) line(/invalid rcon/i.test(l) ? 'err' : '', l);
    } catch (e) { line('err', e.message); notify.error(e.message); } finally { sendBtn.classList.remove('loading'); }
  }

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') run();
    else if (e.key === 'ArrowUp' && history.length) { hIdx = Math.min(hIdx + 1, history.length - 1); input.value = history[hIdx]; e.preventDefault(); }
    else if (e.key === 'ArrowDown') { hIdx = Math.max(hIdx - 1, -1); input.value = hIdx < 0 ? '' : history[hIdx]; e.preventDefault(); }
  });

  const chips = h('div', { class: 'quick' }, QUICK.map(([label, cmd, needsArg, danger]) =>
    h('button', { class: `chip${danger ? ' danger' : ''}`, onclick: () => { if (needsArg) { input.value = cmd; input.focus(); } else run(cmd, danger); } }, label)));

  root.replaceChildren(
    PageHead('RCON', `${s.name} · ${s.host}:${s.port}`),
    s.hasRcon ? null : h('div', { style: { marginBottom: '12px' } }, Banner('warn', 'Walang RCON password ang server na ito. I-set ito sa Server Details.')),
    chips, out, h('div', { class: 'cmd-row' }, input, sendBtn),
    history.length ? h('div', { class: 'muted', style: { fontSize: '0.76rem', marginTop: '10px' } }, 'Tip: gamitin ang ↑ / ↓ para sa dating mga command.') : null);
  line('sys', `Handa na. Ang mga command ay ipinapadala sa ${s.host}:${s.port} gamit ang RCON.`);
  return () => {};
}
