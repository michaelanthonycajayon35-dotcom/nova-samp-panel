'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const c = require('../controllers/rcon.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');
const { limiter } = require('../middleware/rate-limit.middleware');

module.exports = (router) => {
  router.post('/api/servers/:id/rcon', authenticate, requireRole('moderator'), limiter({ windowMs: 60_000, max: 60, name: 'rcon' }), c.send);
};
