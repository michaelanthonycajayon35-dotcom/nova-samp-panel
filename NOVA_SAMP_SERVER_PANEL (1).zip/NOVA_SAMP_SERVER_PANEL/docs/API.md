# API

Lahat ay JSON. Maliban sa login at `/api/system/*`, kailangan ng header `Authorization: Bearer <token>`.
Error: `{ "error": "mensahe" }` kasama ang tamang HTTP status (400, 401, 403, 404, 409, 429...).

| Method | Path | Role | Paliwanag |
|---|---|---|---|
| GET | `/api/system/health` | — | `{ok:true}` |
| GET | `/api/system/public` | — | pangalan ng panel, bersyon |
| GET | `/api/system/info` | viewer | impormasyon ng panel |
| POST | `/api/auth/login` | — | `{username,password}` → `{token,user}` |
| GET | `/api/auth/me` | any | kasalukuyang user |
| POST | `/api/auth/password` | any | `{current,next}` → bagong token |
| GET | `/api/dashboard` | viewer | system stats + servers + query |
| GET | `/api/servers` | viewer | listahan |
| POST | `/api/servers` | admin | `{name,type,host,port,rconPassword,path?,executable?}` |
| PUT | `/api/servers/import?filename=&name=&type=&port=` | admin | raw body (.zip/.tar.gz) |
| GET/PATCH/DELETE | `/api/servers/:id` | viewer/admin/admin | detalye / baguhin / burahin (`?deleteFiles=true`) |
| POST | `/api/servers/:id/{start,stop,restart}` | moderator | |
| GET/PUT | `/api/servers/:id/config` | admin | server.cfg / config.json |
| GET | `/api/servers/:id/console?since=N` | viewer | bagong linya |
| GET | `/api/servers/:id/console/log?lines=` | viewer | dulo ng server_log.txt |
| POST | `/api/servers/:id/console/command` | moderator | `{command}` sa stdin |
| POST | `/api/servers/:id/rcon` | moderator | `{command}` → `{lines}` |
| GET | `/api/servers/:id/players` | viewer | `{ok,players:[{id,name,score,ping}]}` |
| POST | `/api/servers/:id/players/:pid/{kick,ban}` | moderator | |
| POST | `/api/servers/:id/say` | moderator | `{message}` |
| GET | `/api/servers/:id/files?path=` | admin | listahan |
| GET | `/api/servers/:id/files/read?path=` | admin | text content |
| PUT | `/api/servers/:id/files/write` | admin | `{path,content}` |
| PUT | `/api/servers/:id/files/upload?path=&name=` | admin | raw body |
| POST | `/api/servers/:id/files/{mkdir,rename}` | admin | |
| DELETE | `/api/servers/:id/files?path=` | admin | |
| GET | `/api/servers/:id/files/link?path=` | admin | `{url}` download (60s) |
| GET/POST | `/api/servers/:id/backups` | moderator | listahan / gumawa |
| GET | `/api/servers/:id/backups/:name/link` | admin | download link |
| POST/DELETE | `/api/servers/:id/backups/:name[/restore]` | admin | |
| GET/POST/PATCH/DELETE | `/api/users[/:id]` | admin | |
| GET/PUT | `/api/settings` | viewer/admin | |
