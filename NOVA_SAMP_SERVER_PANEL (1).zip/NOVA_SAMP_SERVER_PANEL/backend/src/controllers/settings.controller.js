'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const settings = require('../config/settings');
const db = require('../config/database');

const get = () => ({ settings: settings.get() });

function update(ctx) {
  const next = settings.update(ctx.body);
  db.audit(ctx.user.username, 'settings-update');
  return { settings: next };
}

module.exports = { get, update };
