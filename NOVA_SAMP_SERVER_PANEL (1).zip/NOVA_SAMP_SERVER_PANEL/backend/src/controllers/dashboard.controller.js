'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const db = require('../config/database');
const monitoring = require('../services/monitoring.service');
const rconService = require('../services/rcon.service');
const { withStatus } = require('./servers.controller');
const { RANK } = require('../middleware/permission.middleware');

async function overview(ctx) {
  const queries = await Promise.all(db.servers.map((s) => rconService.queryInfo(s)));
  const servers = db.servers.map((s, i) => ({ ...withStatus(s), query: queries[i] }));
  const totals = {
    servers: servers.length,
    running: servers.filter((s) => s.process.running).length,
    online: servers.filter((s) => s.query.online).length,
    players: servers.reduce((n, s) => n + (s.query.players || 0), 0),
    maxPlayers: servers.reduce((n, s) => n + (s.query.maxPlayers || 0), 0),
  };
  const canSeeActivity = RANK[ctx.user.role] >= RANK.moderator;
  return { system: monitoring.snapshot(), servers, totals, activity: canSeeActivity ? db.auditLog.slice(0, 15) : [] };
}

module.exports = { overview };
