'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
// Mga setting ng panel na pwedeng baguhin sa app (Settings page).
const db = require('./database');
const v = require('../utils/validation');
const { HttpError } = require('../utils/helpers');

const DEFAULTS = {
  panelName: 'NOVA SAMP Panel',
  backupRetention: 10, // ilang backup ang itatabi bawat server
  autoBackupHours: 0, // 0 = patay ang auto backup
};

function get() { return { ...DEFAULTS, ...db.settings }; }

function update(input) {
  const next = { ...get() };
  if (input.panelName !== undefined) next.panelName = v.oneLine(input.panelName, 'panelName', 40);
  if (input.backupRetention !== undefined) {
    const n = Number(input.backupRetention);
    if (!Number.isInteger(n) || n < 1 || n > 100) throw new HttpError(400, 'backupRetention: 1-100.');
    next.backupRetention = n;
  }
  if (input.autoBackupHours !== undefined) {
    const n = Number(input.autoBackupHours);
    if (!Number.isInteger(n) || n < 0 || n > 168) throw new HttpError(400, 'autoBackupHours: 0-168.');
    next.autoBackupHours = n;
  }
  db.settings = next;
  db.save();
  return next;
}

module.exports = { get, update, DEFAULTS };
