'use strict';
// NOVA SAMP SERVER PANEL - by CAJAYON
const c = require('../controllers/settings.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/permission.middleware');

module.exports = (router) => {
  router.get('/api/settings', authenticate, requireRole('viewer'), c.get);
  router.put('/api/settings', authenticate, requireRole('admin'), c.update);
};
