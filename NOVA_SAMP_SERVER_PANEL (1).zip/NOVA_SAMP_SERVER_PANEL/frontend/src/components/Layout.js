// NOVA SAMP SERVER PANEL - by CAJAYON | PageHead, Empty, NoServer
import { h } from '../scripts/dom.js';
import { icon } from '../scripts/icons.js';
import { navigate } from '../scripts/navigation.js';
import { hasRole } from '../scripts/auth.js';

export const PageHead = (title, sub, ...actions) =>
  h('div', { class: 'page-head' }, h('div', { class: 'grow' }, h('h1', null, title), sub ? h('p', null, sub) : null), actions.length ? h('div', { class: 'row' }, ...actions) : null);

export const Empty = ({ icon: ic = 'info', title, text, action }) =>
  h('div', { class: 'empty card' }, icon(ic), h('h3', null, title), text ? h('p', null, text) : null, action ? h('div', { style: { marginTop: '14px' } }, action) : null);

export const NoServer = () => Empty({
  icon: 'server', title: 'Wala pang server',
  text: hasRole('admin') ? 'Magdagdag ng unang server para magamit ang page na ito.' : 'Walang server na naka-set up. Magpasabi sa admin.',
  action: hasRole('admin') ? h('div', { class: 'row', style: { justifyContent: 'center' } }, h('button', { class: 'btn primary', onclick: () => navigate('/servers?import=1') }, icon('upload', 18), 'I-import'), h('button', { class: 'btn', onclick: () => navigate('/servers?new=1') }, icon('plus', 18), 'Bago')) : null,
});
